"""Literal E0T05 archive preparation: metadata and argv only, never transfer."""
import ast
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import time
from unittest.mock import patch

ROOT=Path('/home/josh/projects/chess');STATE=Path(__file__).resolve().parent
OLD=STATE.with_name('G50T05_cold_archive_v1')
SOURCE=ROOT/'data/nnue_derived/armB/qtemp_0.0005_hist_20m_bt4_toptie_t050'
READINESS=ROOT/'scratchpad/storage_scaling_20260908/top_tie_readiness_v1/receipt.json'
REPLACE=[('qtemp_0.0005_hist_20m_bt4_global_G50T05',SOURCE.name),('G50T05','E0T05')]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pin(p):p=Path(p);return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def save(p,d):
    with p.open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def replace(text):
    for old,new in REPLACE:text=text.replace(old,new)
    return text

def load(name,p):
    spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

started=time.time()
assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and os.sched_getaffinity(0)=={0,1}
readiness=json.loads(READINESS.read_text());assert sha(READINESS)=='70d79feb6c08dbd8af55358d36b5354604bdfd1cba72573ed64ce1f528392f1f'
assert readiness['candidate']['source']==str(SOURCE)
for path,h in readiness['input_metadata_and_source_pins'].items():assert sha(path)==h,path
for oldname,newname in [('archive_G50T05.py','archive_E0T05.py'),('run_registered.py','run_registered.py')]:
    original=(OLD/oldname).read_text();new=replace(original);normalized=new
    for old,replacement in reversed(REPLACE):normalized=normalized.replace(replacement,old)
    assert ast.dump(ast.parse(normalized))==ast.dump(ast.parse(original))
    with (STATE/newname).open('x') as f:f.write(new)
    with (STATE/(newname+'.binding.patch')).open('x') as f:f.write(''.join(difflib.unified_diff(original.splitlines(True),new.splitlines(True),fromfile=str(OLD/oldname),tofile=str(STATE/newname))))
helper=load('e0_archive',STATE/'archive_E0T05.py');wrapper=load('e0_wrapper',STATE/'run_registered.py')
oldplan=json.loads((OLD/'plan.json').read_text());plan=json.loads(replace(json.dumps(oldplan)))
source_stat=helper.stamp(SOURCE)
assert all(source_stat[k]==v for k,v in readiness['candidate']['source_root_stat'].items())
plan['pools'][0]['source_root_stat']=source_stat
plan['source_scope']['recipe']=readiness['candidate']['recipe']
plan['input_pins']=[pin(STATE/'archive_E0T05.py'),pin(STATE/'run_registered.py')]+[pin(SOURCE/n) for n in ['derive_targets_summary.json','bt4_policy_mix_summary.json']]
for p in oldplan['input_pins']:
    if p['path'].startswith('/usr/bin/'):
        assert sha(p['path'])==p['sha256'];plan['input_pins'].append(p)
verified=OLD/'staging/qtemp_0.0005_hist_20m_bt4_global_G50T05/verified.json';v=json.loads(verified.read_text())
assert v['status']=='COPY_AND_CONTENT_VERIFICATION_COMPLETE' and v['source_deleted'] is False and v['tar_sha256']==v['external_tar_sha256']
plan['reuse_evidence']={'qualified_helper':pin(OLD/'archive_G50T05.py'),'qualified_wrapper':pin(OLD/'run_registered.py'),'preparation_review':pin(OLD/'independent_preparation_review.json'),'completed_predecessor_receipt':pin(verified),'completed_predecessor_review':pin(OLD/'independent_completion_review.json'),'delta':'Only literal state/profile/pool/destination/helper-name changes. Full helper/wrapper AST equality after exact inverse substitutions. Original ownership/STOP/deadline fixtures reused, not repeated.'}
base=ROOT/'scratchpad/bt4_joint20'
plan['candidate_basis']={'selection':'Completed unselected E0T05 sharpened top-tie corpus; distinct older _toptie_a100 remains untouched.','readiness_review':pin(READINESS),'training_completion':pin(base/'sharpened_ties_run01/experiment/training.complete.json'),'completed_seed0_package':pin(base/'sharpened_ties_run01/experiment/complete.json'),'independent_seed0_review':pin(base/'sharpened_ties_run01/completed_screen_independent_review.json'),'completed_seed1_package':pin(base/'confirmation_seed1_E0T05_vs_C20T05_v1/complete.json'),'preserve':readiness['retain_locally']+oldplan['candidate_basis']['preserve'],'future_reclamation':'Only after separately qualified archive/current-source review. Retain both source top-level summaries, both E0T05 checkpoints/runs/schedules and all arena evidence; this helper never deletes source.'}
plan['estimated_cost_note']=f"Completed G50T05 predecessor archived {v['tar_bytes']} bytes in {v['finished_unix']-v['started_unix']:.6f}seconds; this is a scheduling reference only. E0T05 full bytes/time not measured; same24GiB/4h ceilings, no source sizing traversal."
plan['launch_timing']='After active V50 CPU preparation releases shared lock, in a parent-selected window, preferably GPU training. No queue/automatic retry or active job changes.'
mount=helper.mount_check(plan);resources=helper.resources(24*1024**3+24*1024**3//10)
assert shutil.disk_usage('/mnt/e').free>=48*1024**3
assert not (STATE/'run').exists() and not (STATE/'staging').exists() and not helper.DEST.exists()
visibility=helper.references(SOURCE)
save(STATE/'plan.json',plan)
operator=json.loads(replace((OLD/'operator_command.json').read_text()));operator['plan']=pin(STATE/'plan.json');operator['argv_template'][7]=sha(STATE/'plan.json');save(STATE/'operator_command.json',operator)
with patch.object(wrapper.time,'time',return_value=1000000):command=wrapper.build_command(plan,1014400)
assert command[:4]==['/usr/bin/timeout','--signal=TERM','--kill-after=30s','14370.000000s']
assert command[4:8]==['/usr/bin/flock','--exclusive','--nonblock','--no-fork']
assert command[-5:]==['--pool',SOURCE.name,'--execute','--deadline','1014400']
assert str(STATE/'archive_E0T05.py') in command and '0,1' in command
assert operator['argv_template'][:4]==['/usr/bin/timeout','--signal=TERM','--kill-after=30s','14370s']
assert operator['argv_template'][5]==str(STATE/'run_registered.py') and operator['argv_template'][7]==sha(STATE/'plan.json')
checks={'schema':1,'status':'PASS_METADATA_BINDING_ONLY_NOT_LAUNCHED','elapsed_seconds':time.time()-started,'readiness':pin(READINESS),'all_readiness_metadata_and_source_pins_rechecked':len(readiness['input_metadata_and_source_pins']),'source_root_stat':source_stat,'source_summaries_match_completed_training':True,'recipe':plan['source_scope']['recipe'],'mount':mount,'resources':resources,'external_free_bytes':shutil.disk_usage('/mnt/e').free,'source_process_visibility':visibility,'fresh_run_staging_destination_absent':True,'literal_binding_only_AST_equality':True,'effective_inner_argv_example':command,'outer_argv_template':operator['argv_template'],'all_tool_pins_unchanged_from_predecessor':True,'source_payload_scans_or_hashes':0,'process_fixtures_repeated':False,'launch_resource_checks_required_again':True,'checkpoint_validation':'Existing completed identities retained in source-readiness review; no checkpoint payload hash/read.','scope':'Whole source retained. No reclamation claim or live process visibility guarantee; inaccessible PIDs disclosed. Future actual launch inventories source and rechecks mount/resources/processes.'}
save(STATE/'preparation_checks.json',checks)
print(json.dumps({'status':checks['status'],'seconds':checks['elapsed_seconds'],'plan_sha256':sha(STATE/'plan.json'),'helper_sha256':sha(STATE/'archive_E0T05.py'),'wrapper_sha256':sha(STATE/'run_registered.py')}))
