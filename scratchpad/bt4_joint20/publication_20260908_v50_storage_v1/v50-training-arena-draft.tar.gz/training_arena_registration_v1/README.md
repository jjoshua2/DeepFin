# V50 original-epoch training and arena draft

This prepares the already selected B100V50 comparison against B100. No V50
corpus, schedule, model, training or arena was processed here. `preregistration.md`
is byte-identical to the parent's prospective `TRAINING_COMPARISON.md`.
The alpha coordinator stays pinned at commit 5afc1e2f0923704b2bb8f1aa7ffe45cc15141757;
its original trainer/control/runtime and canonical epoch remain unchanged.

Both `.draft.json` manifests have explicit DRAFT envelopes. They are deliberately
not accepted by the actual launchers; the inner training proposal also fails
admission while its real summary pins are absent. `None` and the symbolic command
arguments identify missing evidence, never valid launcher hashes. No executable
training/arena manifest or prospective `plan.json` exists yet.

`finalize.py` performs only bounded metadata reads and exclusive file writes:

1. `schedule --qualification-sha256 ACTUAL_SHA` requires the genuine completed
   V50 qualification, exact published derive and value-rewrite hashes, real V50
   recipe admission and original source/runtime pins. It binds the existing
   prospective `run_once.py` and its outer command. It does not run them.
2. `training --qualification-sha256 ACTUAL_SHA --prospective-sha256 ACTUAL_SHA
   --prospective-completion-sha256 ACTUAL_SHA` additionally verifies the completed
   original prospective report, completion and plan/qualification linkage through
   the existing coordinator. It emits the real schema3 training-only manifest.
3. `arena-preparation --training-completion-sha256 ACTUAL_SHA
   --training-manifest-sha256 ACTUAL_SHA` binds the actual completion and its
   checkpoint identity into the existing matched-original-epoch preparation
   manifest. This is receipt binding, not fresh checkpoint/book qualification;
   the later single existing CPU `--prepare` performs those actual checks.

The finalizer pins drafts and coordinator sources, rejects changed/missing
prerequisites and rechecks read metadata before publication. It performs no
model/book payload hashing or loading, recipe rewriting or process launch except
read-only Git identity queries. It cannot create the missing dataset qualification;
that must come from actual completed rewrite/current-metadata evidence, with a
real `rewrite_summary` rather than a fabricated BT4 policy-mix receipt.

The prospective command is a profile-only adaptation of the completed SoftSF
runner: original Python3.10 verifier, CPUs0,1,2 workers/numeric threads2 (the
verifier explicitly sets Blosc1), 1800s inclusive outer timeout,150GiB reserve,
32MiB sampled output, STOP and owned-child cleanup. Its source-role checks change
from SoftSF10 to B100V50; supervision does not change. No verifier ran here.
`commands.draft.json` records the actual consumer-generated training argv;
only corpus and run paths differ from the completed SoftSF command. The original
training stays16 planner/16 loader workers and needs a current resource check.

Training has a16200s GPU-stage cap. The separate low100 SPRT and protected400
fixed128-pair arenas each retain5400s, totaling27000s new GPU stages. CPU schedule
checks,300s arena probe (305s outer preparation allocation), qualification and
rewrite costs are separate, not a7.5-hour end-to-end claim. Actual arena launch
waits for the qualified preparation, and every execution remains unlaunched.
Preserve all frozen V10/SoftSF files and active jobs.

`metadata_checks.json` records only draft refusal, argument/path/thread budget
checks, source identity and the unchanged original training command. The finalizer
was exercised once with an explicitly invalid pending hash and refused before
accessing any corpus metadata. No prerequisite success is fabricated.
