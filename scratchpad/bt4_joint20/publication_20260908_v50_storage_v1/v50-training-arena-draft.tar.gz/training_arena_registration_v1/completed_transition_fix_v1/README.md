# Completed-training transition correction

The original preparation receipt is retained unchanged. Its finalizer hash is
superseded by this correction; the original file is preserved as inert data.
The original checks did not exercise completed output directories and therefore
missed launch-only freshness validation in arena-preparation.

The corrected branch compares the entire finalized manifest with its immutable
draft, allowing only four pending SHA bindings (two summaries, qualification,
prospective schedule), and requires exact equality with the saved training
manifest. Existing completion role, input, canonical schedule and checkpoint
identity checks remain. The existing `verify_candidate_training` consumer checks
completion, run, summary and realized schedule metadata pins. No launch freshness
validation is used after training. Checkpoint content and model/book qualification
remain the later existing CPU preparation's responsibility.

Two unittest methods exercised seven cases: successful completed-state transition
plus altered profile, completion input, checkpoint path, summary hash, training
budget and saved-manifest refusals. These invoke the actual finalizer branch and
actual existing completion consumer against temporary JSON files; no checkpoint,
corpus or model file is created/read. Launch validation is a raising sentinel,
so success demonstrates that freshness admission is not called. Existing runtime
source pins and Git identity are checked normally. No schedule/training/arena
execution occurred. Both tests passed in 0.843s with two CPU threads on CPUs 2,3.

No other draft, binding, preregistration, runner or runtime was changed.
