# G20T05 cold archive preparation

Prepared, not launched. This is the next completed unselected policy corpus after G20T1. The copied helper differs only in its fixed state/pool/destination strings; its wrapper only changes the helper filename. Original operations and evidence remain unchanged.

Use operator_command.json exactly, substituting one outer-start-plus-14,400 deadline. Capture the outer process exit and actual argv. A parent-selected compatible window is required; the shared preparation lock is nonblocking and no watcher is created. The helper checks source root and summary pins, source references, mount, free disk and RAM before useful copying.

The 24 GiB logical staging/tar cap,150 GiB physical free-space reserve,4-hour inclusive deadline, CPUs0,1,two numerical threads,low priority,GPU hidden and owned descendant cleanup are unchanged. These are failure bounds, not promised resource peaks or duration. G20T1 took49.63minutes and produced13.53GB; G20T05 is not sized by that analogy.

All original source entries, summaries and shard metadata are archived and verified. No source deletion or automatic retry. Only the verified temporary local tar is removed. Successful copying alone reclaims no source bytes. After verification, review current source stamps/membership and consumers before removing exact archived shard directories; keep derive_targets_summary.json and bt4_policy_mix_summary.json locally alongside all external training/checkpoint evidence. Keep SF,B100,value banks,active jobs and generators unchanged.
