"""Metadata-only source-selection contract shared by preflight and consumers."""

from pathlib import Path
from typing import Any


def validate_selection_metadata(
    selection: Any,
    *,
    source_dir: Path,
    source_config_sha256: Any,
    source_manifest_sha256: str,
) -> None:
    """Check the exact header before any selected raw payload is opened.

    Inventory membership, row claims and raw payload hashes remain the consuming
    deriver's responsibility. This does not qualify a selected corpus by itself.
    """
    required = {
        "schema", "source_dir", "source_config_sha256",
        "source_manifest_sha256", "shards",
    }
    if (not isinstance(selection, dict) or set(selection) != required
            or selection["schema"] != 1):
        raise ValueError("invalid source-shards schema")
    if (selection["source_dir"] != str(source_dir.resolve())
            or selection["source_config_sha256"] != source_config_sha256
            or selection["source_manifest_sha256"] != source_manifest_sha256):
        raise ValueError("source-shards source binding mismatch")
