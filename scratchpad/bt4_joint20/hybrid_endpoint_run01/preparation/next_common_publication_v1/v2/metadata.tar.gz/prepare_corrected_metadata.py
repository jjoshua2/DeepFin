"""Correct metadata binding only; retain every v1 selected raw identity and semantics."""
import copy,datetime,hashlib,importlib.util,json,pathlib,shutil,sys
P=pathlib.Path
PREP=P('/home/josh/projects/chess/scratchpad/bt4_joint20/hybrid_endpoint_run01/preparation')
OLD=PREP/'G10_common_parallel_next_v1';OUT=PREP/'G10_common_parallel_next_v2';assert not OUT.exists();OUT.mkdir()
def sha(p):return hashlib.sha256(P(p).read_bytes()).hexdigest()
def pin(p):return {'path':str(p),'sha256':sha(p)}
def read(p):return json.loads(P(p).read_text())
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def replace_paths(v):
 if isinstance(v,str):return v.replace(str(OLD),str(OUT))
 if isinstance(v,list):return [replace_paths(x) for x in v]
 if isinstance(v,dict):return {k:replace_paths(x) for k,x in v.items()}
 return v
old=read(OLD/'runner_manifest.json');snap=read(OLD/'metadata_snapshot.json')
for e in snap['files']:
 source=P(e['path']);assert sha(source)==e['sha256'];dest=OUT/source.relative_to(OLD);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest)
sources=replace_paths(copy.deepcopy(old['sources']))
for s in sources:
 parent=OUT/s['source_id'];sel=read(parent/'source_shards.json');sel['source_config_sha256']=read(parent/'source_manifest.json')['config_sha256'];write(parent/'source_shards.json',sel)
 meta=replace_paths(read(parent/'source_metadata.json'));write(parent/'source_metadata.json',meta)
 for k in ['manifest_snapshot','selection','closed_source_progress','closed_bt4_receipts','source_metadata']:s[k]=pin(P(s[k]['path']))
 assert read(OLD/s['source_id']/'source_shards.json')['shards']==sel['shards']
write(OUT/'correction.json',{'status':'CORRECTED_PROPOSAL_NOT_LAUNCHED','failed_attempt_manifest':pin(OLD/'runner_manifest.json'),'failed_receipt':pin(OLD/'failed.json'),'cause':'Author collector omitted source_config_sha256; runner preliminary schema check did not enforce the consumer exact header. Both real derivers rejected before processing.','change':'Add actual source manifest config_sha256 to each selection and rebind dependent metadata; identical source set, raw SHA, original storage identities, target semantics, omission/resource limits and qualified runtime.','shared_validation_patch':'/tmp/deepfin-selection-admission; metadata-only helper proof is preparation evidence, not runtime adoption.','no_raw_hashing_now':'select_corpus_record performs payload hashing, so it was not called under a metadata-only label. Ordinary actual consumers retain that check during the bounded pipeline.'})
files=[pin(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
write(OUT/'metadata_snapshot.json',{'schema':1,'status':'PREPARED_NOT_LAUNCHED','captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'physical_rows':1061905,'shards':128,'selected_window':'w00-00128..w00-00191 per source','scope':'copied frozen v1 metadata with corrected source-config binding; no raw/sidecar payload reads','files':files})
text=(OLD/'preregistration.md').read_text()+'\n## Corrected second attempt\n\nThe first attempt failed during selected-source admission because both selection manifests omitted `source_config_sha256`. No completed common inputs were produced. This fresh v2 state adds the exact static source-config hashes and rebinds the affected metadata. It preserves all 128 selected raw shard identities, counts, source-qualified games, target semantics, exclusion ceilings and resource limits. The old failed state remains untouched. The shared consumer header check and the existing runner metadata admission must both pass before root reviews a new launch; this registration does not launch or resume anything.\n'
(OUT/'preregistration.md').write_text(text)
r=replace_paths(read(OLD/'registration.json'));r.update(registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),metadata_snapshot=pin(OUT/'metadata_snapshot.json'),metadata_snapshot_sha256=sha(OUT/'metadata_snapshot.json'),preregistration_sha256=sha(OUT/'preregistration.md'),correction=pin(OUT/'correction.json'));write(OUT/'registration.json',r)
runtime=read(old['runtime_qualification']['path']);plan=copy.deepcopy(old);plan.update(state=str(OUT),sources=sources,preregistration=pin(OUT/'preregistration.md'),pins=dict(runtime['pins']))
for name in ['/usr/bin/time','/usr/bin/timeout']:plan['pins'][name]=old['pins'][name]
for p in sorted(OUT.rglob('*')):
 if p.is_file():plan['pins'][str(p)]=sha(p)
plan['pins'][plan['runtime_qualification']['path']]=plan['runtime_qualification']['sha256'];write(OUT/'runner_manifest.json',plan)
l=replace_paths(read(OLD/'launch_preparation.json'));l.update(manifest=pin(OUT/'runner_manifest.json'),preregistration=pin(OUT/'preregistration.md'),registration=pin(OUT/'registration.json'));a=l['argv_template'];a[a.index('--manifest')+1]=str(OUT/'runner_manifest.json');a[a.index('--expected-manifest-sha256')+1]=sha(OUT/'runner_manifest.json');write(OUT/'launch_preparation.json',l)
# Use the extracted exact metadata contract, without importing Torch or deriver/raw data.
helper=P('/tmp/deepfin-selection-admission/scripts/corpus_selection_schema.py')
spec=importlib.util.spec_from_file_location('selection_header',helper);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
for s in sources:
 h.validate_selection_metadata(read(s['selection']['path']),source_dir=P(s['source_dir']),source_config_sha256=read(s['source_manifest']['path'])['config_sha256'],source_manifest_sha256=s['source_manifest']['sha256'])
 # Initial failed files are rejected by this same extracted contract.
 try:h.validate_selection_metadata(read(OLD/s['source_id']/'source_shards.json'),source_dir=P(s['source_dir']),source_config_sha256=read(s['source_manifest']['path'])['config_sha256'],source_manifest_sha256=s['source_manifest']['sha256'])
 except ValueError as e:assert str(e)=='invalid source-shards schema'
 else:raise AssertionError('v1 unexpectedly admitted')
spec=importlib.util.spec_from_file_location('batch_metadata',P(plan['checkout'])/'scripts/common_input_batch.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.validate_manifest(plan);b.fresh_outputs(plan)
write(OUT/'metadata_admission.json',{'status':'PASS_METADATA_ONLY_NOT_LAUNCHED','manifest':pin(OUT/'runner_manifest.json'),'actual_consumer_source':pin(P(plan['checkout'])/'scripts/derive_corpus_targets.py'),'shared_extracted_header_validator':pin(helper),'old_runner':pin(P(plan['checkout'])/'scripts/common_input_batch.py'),'checks':['Both corrected selections pass exact extracted header and original source/config/manifest binding','Both failed v1 selections rejected by same helper','Existing frozen runner validate_manifest and fresh_outputs pass','All original selected shard entries unchanged from v1'],'limitations':['Full select_corpus_record not called: it hashes raw payloads.','Draft main shared-helper code is not adopted by the frozen old runtime; ordinary old deriver validates full schema and source content during actual execution.','Reused native/library pins are not rehashed here; root and bounded execution verify them.']})
shutil.copyfile(__file__,OUT/'prepare_corrected_metadata.py')
write(OUT/'prepared.json',{'status':'PREPARED_NOT_LAUNCHED','manifest':pin(OUT/'runner_manifest.json'),'registration':pin(OUT/'registration.json'),'preregistration':pin(OUT/'preregistration.md'),'metadata':pin(OUT/'metadata_snapshot.json'),'admission':pin(OUT/'metadata_admission.json'),'launch':pin(OUT/'launch_preparation.json'),'preparer':pin(OUT/'prepare_corrected_metadata.py'),'rows':1061905,'shards':128})
print(json.dumps(read(OUT/'prepared.json'),indent=2))
