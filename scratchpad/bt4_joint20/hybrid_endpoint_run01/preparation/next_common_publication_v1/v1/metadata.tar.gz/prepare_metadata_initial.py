"""Fixed metadata-only next batch; never opens raw or Zarr payloads."""
import copy, datetime, hashlib, importlib.util, json, math, os, pathlib, shutil, stat
P=pathlib.Path
ROOT=P('/home/josh/projects/chess')
PREP=ROOT/'scratchpad/bt4_joint20/hybrid_endpoint_run01/preparation'
OLD=PREP/'G10_common_parallel_v1'
OUT=PREP/'G10_common_parallel_next_v1'
assert not OUT.exists(), 'exclusive preparation'
OUT.mkdir()
def sha(p): return hashlib.sha256(P(p).read_bytes()).hexdigest()
def pin(p): return {'path':str(p),'sha256':sha(p)}
def write(p,v):
 with p.open('x') as f: json.dump(v,f,indent=2);f.write('\n')
def read(p): return json.loads(P(p).read_text())
def stable_bytes(p):
 a=p.stat();b=p.read_bytes();z=p.stat();assert a==z;return b
def records(p,key,wanted):
 found={}
 with p.open() as f:
  for line in f:
   if not line.endswith('\n'): break # growing final record is not closed evidence
   o=json.loads(line);n=key(o)
   if n not in wanted:continue
   assert n not in found, (p,n,'duplicate closed receipt')
   found[n]=(o,line)
 return found
names=[f'w00-{i:05d}.jsonl.zst' for i in range(128,192)]
prior=[f'w00-{i:05d}.jsonl.zst' for i in range(128)]
prospective=[f'w00-{i:05d}.jsonl.zst' for i in range(128,256)]
oldplan=read(OLD/'runner_manifest_v2.json');runtime=read(OLD/'runtime_qualification_v2.json')
sources=[];availability={};game_proofs={}
for lane,oldsource in enumerate(oldplan['sources']):
 sid=oldsource['source_id'];src=P(oldsource['source_dir']);bt=P(oldsource['sidecar_dir']);dest=OUT/sid;dest.mkdir();(dest/'sidecar_attrs').mkdir()
 manifest_bytes=stable_bytes(src/'manifest.json');manifest=json.loads(manifest_bytes)
 assert hashlib.sha256(manifest_bytes).hexdigest()==oldsource['source_manifest']['sha256']
 (dest/'source_manifest.json').write_bytes(manifest_bytes)
 raw=records(src/'w00.progress.jsonl',lambda o:P(o.get('path','')).name,set(prior+prospective))
 teachers=records(bt/'bt4_raw_sidecar.progress.jsonl',lambda o:o.get('source_shard'),set(prospective))
 assert set(prior+names)<=set(raw) and set(names)<=set(teachers)
 availability[sid]={'requested128_labelled':len(teachers),'missing_teacher_receipts':sorted(set(prospective)-set(teachers))}
 oldgames=set();newgames=set();owners={}
 for n in prior:
  games=raw[n][0]['games'];assert len(games)==len(set(games));oldgames.update(games)
 for n in names:
  games=raw[n][0]['games'];assert len(games)==len(set(games));assert not newgames.intersection(games);newgames.update(games)
 assert not oldgames.intersection(newgames)
 game_proofs[sid]={'source_dir':str(src),'source_config_sha256':manifest['config_sha256'],'prior_shards':prior,'selected_shards':names,'prior_games':len(oldgames),'selected_games':len(newgames),'prior_overlap':0,'within_selection_overlap':0,'selected_game_ids':sorted(newgames),'prior_game_ids_sha256':hashlib.sha256(json.dumps(sorted(oldgames),separators=(',',':')).encode()).hexdigest(),'basis':'closed w00 source progress; game identity qualified by original source/config and worker00; not cross-source bare game IDs'}
 entries=[];metadata=[]
 for n in names:
  r=raw[n][0];t=teachers[n][0];path=src/n;st=path.lstat();assert stat.S_ISREG(st.st_mode) and st.st_nlink==1
  side=bt/t['sidecar'];assert side.name==n.replace('.jsonl.zst','.bt4.zarr') and not side.is_symlink()
  attrsbytes=stable_bytes(side/'.zattrs');a=json.loads(attrsbytes)
  assert r['path']==str(path) and r['rows']==t['positions']==a['positions']==a['source_rows_claimed']
  assert a['source_dir']==str(src) and a['source_config_sha256']==manifest['config_sha256'] and a['source_manifest_sha256']==sha(src/'manifest.json')
  assert a['source_file_bytes']==st.st_size and a['source_file_mtime_ns']==st.st_mtime_ns
  for k,v in t.items():
   if k=='sidecar':continue
   assert a[k]==v,(sid,n,k)
  assert a['history_rep_fix'] is True and a['search_nodes']==0 and a['stored_dtype']=='float32' and a['policy_size']==1858
  assert a['policy_encoding']=='lc0_1858' and a['input_history_encoding']=='lc0_root_legacy_meta' and a['input_extra_features']=='v2_threats'
  # Same teacher and functional input/remapping provenance as the previous qualified batch.
  oldattrs=read(P(oldsource['source_metadata']['path']))[0]['sidecar_attrs_snapshot']['path'];oldattrs=read(oldattrs)
  for k in ['onnx_sha256','policy_output','providers','teacher_evaluations_per_position']:
   assert a[k]==oldattrs[k]
  assert a['remap_provenance']['blobs']==oldattrs['remap_provenance']['blobs']
  ap=dest/'sidecar_attrs'/(side.name+'.json');ap.write_bytes(attrsbytes)
  metadata.append({'source_path':str(path),'device':st.st_dev,'inode':st.st_ino,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns,'sidecar_path':str(side),'sidecar_attrs_snapshot':pin(ap)})
  entries.append({'source_shard':n,'rows':r['rows'],'source_sha256':t['source_sha256']})
  assert path.lstat()==st
 for filename,bank in [('closed_source_progress.jsonl',raw),('closed_bt4_receipts.jsonl',teachers)]:
  (dest/filename).write_text(''.join(bank[n][1] for n in names))
 # Preserve the prior game ledger too so overlap can be independently recomputed without live progress.
 (dest/'prior_closed_source_progress.jsonl').write_text(''.join(raw[n][1] for n in prior))
 write(dest/'source_shards.json',{'schema':1,'source_dir':str(src),'source_manifest_sha256':sha(src/'manifest.json'),'shards':entries})
 write(dest/'source_metadata.json',metadata)
 s=copy.deepcopy(oldsource)
 for k in ['prior_w00_00000_00063_game_overlap']:s.pop(k,None)
 s.update(physical_rows=sum(x['rows'] for x in entries),shards=64,games=len(newgames),prior_w00_00000_00127_game_overlap=0,compressed_raw_bytes=sum(x['bytes'] for x in metadata),cpu_affinity=[lane*2,lane*2+1])
 s['missing_result_count_ceiling']=math.floor(s['physical_rows']*.02)
 for k,filename in [('manifest_snapshot','source_manifest.json'),('selection','source_shards.json'),('closed_source_progress','closed_source_progress.jsonl'),('closed_bt4_receipts','closed_bt4_receipts.jsonl'),('source_metadata','source_metadata.json')]:s[k]=pin(dest/filename)
 for k,d in [('derived_output','derived'),('adapted_output','bt4'),('rank_output','rank')]:s[k]=str(dest/d);assert not P(s[k]).exists()
 sources.append(s)
write(OUT/'game_disjointness.json',game_proofs)
review=read(OLD/'independent_completed_review_v1/review.json')
rows=sum(s['physical_rows'] for s in sources)
estimate=review['totals']['peak_sampled_aggregate_output_bytes']*rows/review['totals']['physical_rows']
assert estimate*2 < 8*1024**3
write(OUT/'eligibility_and_resources.json',{'status':'METADATA_ONLY_PREPARED_NOT_LAUNCHED','availability':availability,'selection_reason':'run07 lacks completed teacher receipts for the full128-per-source proposal; freeze64 per source, no automatic expansion','prior_review':pin(OLD/'independent_completed_review_v1/review.json'),'prior_peak_sampled_bytes':review['totals']['peak_sampled_aggregate_output_bytes'],'prior_rows':review['totals']['physical_rows'],'selected_rows':rows,'row_linear_output_estimate_bytes':estimate,'twofold_estimate_bytes':estimate*2,'cap_bytes':8*1024**3,'prior_coordinator_seconds':review['totals']['coordinator_seconds'],'row_linear_elapsed_estimate_seconds':review['totals']['coordinator_seconds']*rows/review['totals']['physical_rows'],'limitations':['Output projection is descriptive, not a quota or guaranteed bound.','No measured scaling extrapolation; same two source lanes and two cores per lane.','Training now has16 planner/load workers; root must refresh host resources and monitor interference.','No source/sidecar payload rereads, exclusion census, inference or derivation during preparation. Raw SHA values are closed teacher receipt claims; actual consumers verify bytes.']})
files=[pin(p) for p in sorted(OUT.rglob('*')) if p.is_file()]
write(OUT/'metadata_snapshot.json',{'schema':1,'status':'PREPARED_NOT_LAUNCHED','captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sources':sources,'physical_rows':rows,'shards':128,'selected_window':'w00-00128..w00-00191 per source','scope':'exact closed metadata only; payload pins are existing verified teacher claims; no raw or policy payload read','files':files})
registration=read(OLD/'registration.json');registration.update(raw_rows=rows,shards=128,registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),selected_window='w00-00128..w00-00191 per source',metadata_snapshot=pin(OUT/'metadata_snapshot.json'))
write(OUT/'registration.json',registration)
(OUT/'preregistration.md').write_text(f'''# G10 common inputs: next fully labelled disjoint block\n\nRegistered before processing. Prepare common inputs for future matched teacher-recipe training; no training, mixing, inference or playing-strength test is part of this batch.\n\nSelect exactly w00-00128 through w00-00191 from each original source: {rows:,} raw rows across128 closed shards. Run06 contributes{sources[0]['physical_rows']:,} rows in{sources[0]['games']:,} games; run07 contributes{sources[1]['physical_rows']:,} rows in{sources[1]['games']:,} games. Each selected shard has an exact closed teacher receipt, original source stat binding and captured sidecar attributes. Source-qualified game IDs are disjoint from prior w00-00000..00127 and between selected shards. Identical bare game numbers across different source namespaces do not imply overlap.\n\nThe proposed128-shard-per-source block is not yet fully teacher-labelled in run07. Freeze this64-per-source fallback, with no automatic later expansion. At the prior batch's measured output per row, expected sampled output is{estimate/1024**3:.3f} GiB; a twofold allowance is{2*estimate/1024**3:.3f} GiB, below the8 GiB guard. This is a descriptive projection, not a guaranteed resource bound.\n\nReuse the qualified56d650e06ca208a8b134155c5a7fad4dd19b105d runtime and common-input runner unchanged. Derive phase-zero complete uniform-d9 policy at temperature0.0005/floor0, latest-phase d9 search value, seed0,8192 rows per output shard, two workers and full-history provenance. Then snapshot, adapt existing BT4 labels, create top3 rank sidecars and qualify the exact common survivor complement. Missing-result omissions are limited to2% per source ({sources[0]['missing_result_count_ceiling']} and{sources[1]['missing_result_count_ceiling']}); support exclusions are limited to64 per source with the existing strict history/result/rank/full-width proof. No envelope drops, additional malformed categories, d8 substitution or value changes. Survivor counts remain unknown. Raw source payloads and teacher labels remain untouched.\n\nUse two concurrent source lanes, CPU0–1 and2–3, two numeric threads, nice19, idle I/O and hidden CUDA. B100's16 planner/load workers remain active; root refreshes host resources and monitors coexistence. Four-hour absolute deadline includes30-second kill grace. Preserve150 GiB free space; sample aggregate new output/cache against8 GiB and bound each adapter/rank index cache at64 MiB. Sampled output guards are not quotas. Preserve partials on failure, cancel only owned groups, no automatic retry/resume. Exact argv/deadline/PIDs are recorded by the operator at launch; preparation here launches nothing.\n\nAccept only after both lanes complete, selected source storage remains stable, all ordinary BT4/rank admission and source-qualified row/history/complement checks pass, and final counts/resources are recorded. Record each real stage once. This is input identity qualification, not a training schedule qualification or a controlled throughput comparison. Source generators may append unselected shards without invalidating the selection. No preliminary raw exclusion census is planned.\n'''.replace('across128','across 128').replace('contributes','contributes ').replace(' in', ' in').replace('games;', 'games;').replace('this64','this 64').replace('proposed128','proposed 128').replace('qualified56','qualified 56').replace('below the8','below the 8').replace('is limited to','is limited to'))
# Reuse all runtime pins, not irrelevant prior data selection pins.
plan=copy.deepcopy(oldplan);plan.update(state=str(OUT),sources=sources,preregistration=pin(OUT/'preregistration.md'),pins=dict(runtime['pins']))
for p in ['/usr/bin/time','/usr/bin/timeout']:plan['pins'][p]=oldplan['pins'][p]
for p in sorted(OUT.rglob('*')):
 if p.is_file():plan['pins'][str(p)]=sha(p)
plan['pins'][plan['runtime_qualification']['path']]=plan['runtime_qualification']['sha256']
write(OUT/'runner_manifest.json',plan)
launch=read(OLD/'launch_preparation_v2.json');launch.update(manifest=pin(OUT/'runner_manifest.json'),preregistration=pin(OUT/'preregistration.md'),registration=pin(OUT/'registration.json'))
a=launch['argv_template'];a[a.index('--manifest')+1]=str(OUT/'runner_manifest.json');a[a.index('--expected-manifest-sha256')+1]=sha(OUT/'runner_manifest.json')
launch['prelaunch_checks']=['Parent reviews frozen metadata/manifest and refreshes host memory/disk/CPU allocation alongside active B100 training.','Exact runtime/selected source pins checked before processing; no STOP, no existing output, no competing common-input owner on0..3.']
write(OUT/'launch_preparation.json',launch)
# Metadata admission only. Does not call verify() (large native/library hashes), any action or import scientific stacks.
spec=importlib.util.spec_from_file_location('common_metadata',P(plan['checkout'])/'scripts/common_input_batch.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mod.validate_manifest(plan);mod.fresh_outputs(plan)
write(OUT/'metadata_admission.json',{'status':'PASS_METADATA_ONLY_NOT_LAUNCHED','manifest':pin(OUT/'runner_manifest.json'),'runner':pin(P(plan['checkout'])/'scripts/common_input_batch.py'),'checks':['actual validate_manifest and fresh_outputs','exact receipt/attrs/source metadata row and teacher/function lineage','source-qualified game disjointness from prior128 and within selected64','all derived/adapted/rank outputs absent'],'not_repeated':'Full native/library pin hashing and import qualification are reused; full verify occurs under registered launch deadline.'})
shutil.copyfile(__file__,OUT/'prepare_metadata.py')
write(OUT/'prepared.json',{'status':'PREPARED_NOT_LAUNCHED','manifest':pin(OUT/'runner_manifest.json'),'registration':pin(OUT/'registration.json'),'preregistration':pin(OUT/'preregistration.md'),'metadata':pin(OUT/'metadata_snapshot.json'),'admission':pin(OUT/'metadata_admission.json'),'launch':pin(OUT/'launch_preparation.json'),'preparer':pin(OUT/'prepare_metadata.py'),'rows':rows,'shards':128})
print(json.dumps(read(OUT/'prepared.json'),indent=2))
