# G20T05 reclamation preparation

Inactive templates only. The ongoing copy is unchanged. No source scan, archive hash, process check, lock acquisition or removal was run for this preparation.

First require the actual captured outer exit and completed member/content/external-readback receipt, bound to the existing copy plan. Then review that chain and bind the actual saved manifest hash/count/bytes and current archive identity. Only afterward run the adapted bounded source-metadata and host-consumer checks. Their exact shard list and allocated-byte measurement supply fresh readiness evidence.

All three .py.in files have an immediate refusal guard. Final scripts must be explicitly bound and frozen after prerequisite evidence is available. workflow.json lists the future commands; none is a launch instruction for the unbound templates. No automatic watcher or continuation is created.

The changes from qualified G20T1 are literal source/state/archive profile names, pending completion-specific hashes/counts and the refusal guard. Do not copy G20T1 sizes, entry counts, archive identity or readiness/list hashes. Preserve exactly the two original top-level summaries and all checkpoints/receipts; only reviewed shard directories may later be reclaimed.

Use the same preparation lock and low-priority bounded operation. Final receipts distinguish verified shard removals, prior allocated bytes and observed whole-filesystem free-space change. Parent chooses each actual resource window.
