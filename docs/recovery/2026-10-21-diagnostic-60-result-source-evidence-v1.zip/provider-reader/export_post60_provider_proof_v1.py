"""UNRUN exact one-record saved provider-proof export; no guest writes or target imports."""
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time

FILES = (
    ('/home/josh/chess-artifacts/operations/bt4-pr1110-correctness-private-20261021-v4/unit-000000000000/attempt-00/raw/provider_proof.json',
     '6eb991f4cd83b57bbf7687e00b865dfc4742a416593e9b4e25fc017c93de625f', 974),
)
def need(value, message):
    if not value:
        raise ValueError(message)

need(len(sys.argv) == 1 and sys.version_info[:2] == (3, 10) and sys.flags.isolated
     and sys.flags.no_site and sys.flags.dont_write_bytecode and sys.flags.optimize == 0,
     'exact no-argument isolated CP310 startup')
for which, cap in ((resource.RLIMIT_CPU, 10), (resource.RLIMIT_AS, 512 << 20)):
    soft, hard = resource.getrlimit(which)
    bound = min(v for v in (soft, hard, cap) if v != resource.RLIM_INFINITY)
    resource.setrlimit(which, (bound, min(hard, cap) if hard != resource.RLIM_INFINITY else cap))
started = time.monotonic()
records = []
read_bytes = 0
for name, expected, expected_size in FILES:
    path = Path(name)
    need(path.resolve(strict=True) == path, 'fixed canonical saved path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= 16384
             and (expected_size is None or before.st_size == expected_size), 'bounded exact saved regular file')
        chunks = []
        count = 0
        while True:
            need(time.monotonic() - started < 9, 'saved-only read deadline')
            raw = os.read(fd, min(65536, 16385 - count))
            if not raw:
                break
            count += len(raw)
            read_bytes += len(raw)
            need(count <= 16384 and read_bytes <= 16384, 'fixed one-file read bound')
            chunks.append(raw)
        key = lambda x: (x.st_dev, x.st_ino, x.st_mode, x.st_size, x.st_mtime_ns, x.st_ctime_ns)
        need(count == before.st_size and key(before) == key(os.fstat(fd)) == key(path.lstat()),
             'saved bytes changed while captured')
        raw = b''.join(chunks)
        digest = hashlib.sha256(raw).hexdigest()
        need(digest == expected, 'exact accepted saved SHA256')
        records.append({'path': name, 'bytes': len(raw), 'sha256': digest, 'raw': raw.decode('utf-8', errors='strict')})
    finally:
        os.close(fd)
output = (json.dumps({'files': records}, sort_keys=True, ensure_ascii=True, separators=(',', ':')) + '\n').encode('ascii')
need(len(output) <= 16384 and time.monotonic() - started < 9, 'complete untruncated serialized output bound')
sys.stdout.buffer.write(output)
sys.stdout.buffer.flush()
