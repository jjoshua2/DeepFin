"""UNRUN V2 fixed saved-only POST60 summary. No target imports or guest writes."""
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import stat
import sys
import time

PARENT = Path('/home/josh/chess-artifacts/operations/pr1110-finite-diagnostic60-20261021-v1')
PRIVATE = Path('/home/josh/chess-artifacts/operations/bt4-pr1110-correctness-private-20261021-v4')
UNIT = PRIVATE / 'unit-000000000000'
ATTEMPT = UNIT / 'attempt-00'
RAW = ATTEMPT / 'raw'
BOOT = 'e34eff27-d1dc-49c0-bac2-e8525ea1b52f'
READ_CAP = 16 << 20
OUTPUT_CAP = 256 << 10
started = time.monotonic()
read_bytes = 0
records = []


def need(value, message):
    if not value:
        raise ValueError(message)


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=True, allow_nan=False,
                      separators=(',', ':')).encode('ascii')


def append(record, cap=8192):
    need(len(encoded(record)) <= cap, 'bounded per-record summary')
    records.append(record)
    need(len(encoded({'files': records})) <= OUTPUT_CAP - 8192, 'aggregate summary bound')


def capture(path, limit):
    global read_bytes
    need(time.monotonic() - started < 9, 'saved read deadline')
    try:
        info = path.lstat()
    except FileNotFoundError:
        return {'path': str(path), 'status': 'MISSING'}, None
    need(stat.S_ISREG(info.st_mode) and path.resolve(strict=True) == path,
         'fixed canonical regular saved artifact')
    if info.st_size > limit or info.st_size > READ_CAP - read_bytes:
        return {'path': str(path), 'status': 'NOT_READ_SIZE_OR_AGGREGATE_BOUND', 'bytes': info.st_size}, None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        chunks = []
        count = 0
        while True:
            need(time.monotonic() - started < 9, 'saved read deadline')
            raw = os.read(fd, min(65536, limit + 1 - count))
            if not raw:
                break
            count += len(raw)
            read_bytes += len(raw)
            need(count <= limit and read_bytes <= READ_CAP, 'explicit saved read bound')
            chunks.append(raw)
        key = lambda x: (x.st_dev, x.st_ino, x.st_mode, x.st_size, x.st_mtime_ns, x.st_ctime_ns)
        need(count == before.st_size and key(info) == key(before) == key(os.fstat(fd)) == key(path.lstat()),
             'saved artifact changed while captured')
        raw = b''.join(chunks)
        return {'path': str(path), 'status': 'READ_STABLE', 'bytes': len(raw),
                'sha256': hashlib.sha256(raw).hexdigest()}, raw
    finally:
        os.close(fd)


def json_record(path, limit=262144, fields=None, cap=8192):
    record, raw = capture(path, limit)
    value = None
    if raw is not None:
        try:
            value = json.loads(raw.decode('utf-8', errors='strict'))
            need(isinstance(value, dict), 'JSON object expected')
            record['source_top_level_keys'] = sorted(value)
            chosen = value if fields is None else {k: value[k] for k in fields if k in value}
            record['summary'] = chosen
            record['omitted_top_level_values'] = sorted(set(value) - set(chosen))
            if len(encoded(record)) > cap:
                record.pop('summary')
                record['summary_not_exported_size_bound'] = True
        except (UnicodeError, ValueError, TypeError) as error:
            record['json_error'] = type(error).__name__
            value = None
    append(record, cap)
    return value


def snapshot(path):
    record, raw = capture(path, 196608)
    read_monotonic = time.monotonic()
    record.update(read_monotonic_seconds=read_monotonic, age_at_closure_seconds=None,
                  age_at_closure_reason='Authenticated parent source has no absolute closure monotonic field; elapsed duration is not an endpoint',
                  state_at_publication_only=True, pending_is_not_current_liveness=True)
    if raw is not None:
        try:
            value = json.loads(raw.decode('utf-8', errors='strict'))
            need(isinstance(value, dict), 'snapshot object')
            record['source_top_level_keys'] = sorted(value)
            summary = {}
            omitted = []
            for key, item in value.items():
                if item is None or type(item) in (bool, int, float):
                    summary[key] = item
                elif isinstance(item, str):
                    summary[key] = item[:512]
                    if len(item) > 512:
                        omitted.append(key + ':string suffix')
                elif key == 'execute_attempt_batch_histogram' and isinstance(item, dict) and len(item) <= 65:
                    summary[key] = item
                elif key == 'errors' and isinstance(item, list):
                    summary[key] = item[:8]
                    if len(item) > 8:
                        omitted.append(key + ':older/unexported errors')
                elif key == 'events' and isinstance(item, list):
                    summary['events_total_in_snapshot'] = len(item)
                    summary['last_events'] = item[-8:]
                    summary['events_omitted_count'] = max(0, len(item) - 8)
                else:
                    omitted.append(key)
            record['summary'] = summary
            record['omitted_or_shortened_values'] = omitted
            mono = value.get('snapshot_monotonic_seconds')
            record['snapshot_monotonic_seconds'] = mono
            valid = type(mono) in (int, float) and math.isfinite(mono) and 0 <= mono <= read_monotonic
            record['age_at_read_seconds'] = read_monotonic - mono if valid else None
            record['age_at_read_basis'] = 'actual current expected boot plus source snapshot monotonic' if valid else 'missing/invalid/future monotonic; unknown'
        except (UnicodeError, ValueError, TypeError) as error:
            record['json_error'] = type(error).__name__
    append(record, 8192)


def read_boot():
    global read_bytes
    need(time.monotonic() - started < 9, 'boot read deadline')
    fd = os.open('/proc/sys/kernel/random/boot_id', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        # procfs pseudo-file reports st_size0 despite a nonempty bounded body.
        raw = os.read(fd, 129)
        need(len(raw) <= 128, 'bounded boot pseudo-file')
        read_bytes += len(raw)
        need(read_bytes <= READ_CAP and raw.decode('ascii').strip() == BOOT, 'actual same expected boot')
        return raw.decode('ascii').strip()
    finally:
        os.close(fd)

def stat_only(path):
    try:
        info = path.lstat()
        need(stat.S_ISREG(info.st_mode) and path.resolve(strict=True) == path, 'canonical regular stat-only file')
        return {'path': str(path), 'status': 'STAT_ONLY_NOT_OPENED', 'bytes': info.st_size}
    except FileNotFoundError:
        return {'path': str(path), 'status': 'MISSING'}


def output(value):
    raw = encoded(value) + b'\n'
    need(len(raw) <= OUTPUT_CAP and time.monotonic() - started < 9, 'complete output/deadline bound')
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()


need(len(sys.argv) == 1 and sys.version_info[:2] == (3, 10) and sys.flags.isolated
     and sys.flags.no_site and sys.flags.dont_write_bytecode and sys.flags.optimize == 0,
     'fixed isolated CP310 no-argument startup')
for which, cap in ((resource.RLIMIT_CPU, 10), (resource.RLIMIT_AS, 512 << 20)):
    soft, hard = resource.getrlimit(which)
    bound = min(v for v in (soft, hard, cap) if v != resource.RLIM_INFINITY)
    resource.setrlimit(which, (bound, min(hard, cap) if hard != resource.RLIM_INFINITY else cap))
observed_boot_before = read_boot()
closure_record, closure_raw = capture(PARENT / 'CLOSED-PAUSED.json', 262144)
closure = None
if closure_raw is not None:
    try:
        closure = json.loads(closure_raw)
    except (ValueError, UnicodeError):
        pass
closure_ok = isinstance(closure, dict) and closure.get('kernel_ECHILD') is True and closure.get('canonical_lock_rows') == []
closure_ok = closure_ok and closure.get('before') == closure.get('after') and isinstance(closure.get('before'), dict)
closure_ok = closure_ok and isinstance(closure.get('packet'), dict) and isinstance(closure.get('review'), dict)
if not closure_ok:
    append(closure_record)
    output({'schema': 'PR1110_POST60_SAVED_READOUT_V2', 'status': 'REFUSED_MISSING_OR_UNACCEPTED_SAVED_CLOSURE',
            'files': records, 'actual_boot_id': BOOT, 'read_bytes': read_bytes,
            'live_process_or_lock_observation': False, 'follow_on_reads_performed': False})
    raise SystemExit(2)
closure_fields = ('packet','review','kernel_ECHILD','canonical_lock_rows','returncode','elapsed_seconds',
                  'failure','native_admission','training_credit','stream_transport','cleanup_seconds_is_unknown_hold_release_deadline')
closure_record.update(summary={k: closure[k] for k in closure_fields if k in closure},
                      source_top_level_keys=sorted(closure), omitted_top_level_values=sorted(set(closure) - set(closure_fields)))
if len(closure_raw) <= 65536:
    candidate = {**closure_record, 'raw': closure_raw.decode('utf-8', errors='strict')}
    if len(encoded(candidate)) <= 98304:
        closure_record = candidate
    else:
        closure_record['raw_not_exported'] = 'serialized raw closure exceeds96KiB; hash/summary only, no full raw closure credit'
else:
    closure_record['raw_not_exported'] = 'raw closure exceeds64KiB; hash/summary only, no full raw closure credit'
append(closure_record, 98304)
for name in ('ONE-USE.json','BOUND-PARENT-CLAIM.json','PARENT-CLAIM.json'):
    json_record(PARENT / name)
for name in ('stdout','stderr'):
    record, raw = capture(PARENT / name, 1 << 20)
    if raw is not None:
        record.update(tail_utf8=raw[-4096:].decode('utf-8', errors='replace'), tail_bytes=min(len(raw),4096),
                      earlier_bytes_not_exported=max(0,len(raw)-4096), tail_is_derived_text_not_raw_record=True)
    append(record)
for suffix in ('','.quiescent.json'):
    snapshot(PRIVATE / ('diagnostic-partial-60s.json' + suffix))
for slot in range(17):
    snapshot(PRIVATE / ('diagnostic-partial-60s.json.during-%02d.json' % slot))
for path in (PRIVATE/'coordinator/cross_unit_launch.json', PRIVATE/'coordinator/cross_unit_complete.json',
             PRIVATE/'coordinator/cross_unit_paused.json', RAW/'launch.json', RAW/'provider_proof.json',
             RAW/'paused.json', RAW/'summary.json'):
    json_record(path, fields=('status','rows','games','attempted','emitted','completed','paused','reason','error',
                             'requested_provider','actual_provider','provider','model_sha256','launch_sha256',
                             'profile_sha256','shared_unit_launch_sha256','cuda_execution_count','neural_cuda_execution_count',
                             'cpu_execution_count','effective_batch_sizes','backend_stages','writer_seconds'), cap=4096)
receipt_count = 0
for game in range(128):
    path = RAW / ('games/game_%08d.checkpoint.json' % game)
    value = json_record(path, limit=8192, fields=('game_id','path','sha256','launch_sha256','status','rows','discarded_rows','termination'), cap=1536)
    receipt_count += int(value is not None)
sqlite_metadata = [stat_only(UNIT / ('checkpoint.sqlite' + suffix)) for suffix in ('','-wal','-shm','-journal')]
observed_boot_after = read_boot()
output({'schema': 'PR1110_POST60_SAVED_READOUT_V2', 'status': 'SAVED_SUMMARIES_ONLY_NOT_UNIT_QUALIFICATION',
        'files': records, 'actual_boot_id': observed_boot_after, 'actual_boot_before': observed_boot_before, 'read_finished_monotonic_seconds': time.monotonic(),
        'read_bytes': read_bytes, 'writer_receipt_json_objects_read': receipt_count,
        'checkpoint_stat_only': sqlite_metadata, 'sqlite_database_opened': False,
        'snapshot_slot_range_fully_attempted': [0,16], 'age_at_closure_seconds': None,
        'closure_time_reason': 'No authenticated absolute closure monotonic in current parent source; no inferred endpoint',
        'saved_closure_gate': 'source-shaped kernelECHILD/zero canonical rows/equal preservation snapshots/packet+review refs; root independently authenticates saved hash and physical closure',
        'live_process_or_lock_observation': False, 'saved_receipts_are_not_independent_live_closure': True,
        'not_exported': ['full snapshot raw bodies','events before last8','NPZ/model/checkpoint payloads','ORT profile payloads','SQLite database contents','directory listings'],
        'full_128_qualification_predicate_evaluated': False, 'training_credit': 0, 'native_admission': False,
        'scope': 'First saved durable boundary/receipt progress only; stale pending never establishes current live inference'})
