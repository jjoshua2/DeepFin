"""SOURCE-ONLY, UNBOUND60s diagnostic caller; no launch/custody acquisition.

One unchanged128-game/64-actor production roster API. This diagnostic adapter
never invokes or changes the old full128 qualification predicate. Root alone
may bind/review a distinct source closure, packet, custody and one-use decision.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import stat
import time

from finite_roster_adapter_v3 import (GENERATION, GEOMETRY, NAME, ORIGINAL_EXPIRY,
                                     ProductionQuiescence, call_with_diagnostics)

PRIVATE_ROOT = Path("/home/josh/chess-artifacts/operations/bt4-pr1110-correctness-private-20261021-v5")
ACTIVE_SECONDS = 60
HELPER5_SHA256 = "46b951d0e0517491fd26849dc93e9ab9fa1c5b4cf195ae200e21c1b1344fb14d"  # Source pin only; CPU/runtime/action gates remain separate.
TIMER_SHA256 = "868384f4179625eea5af5b84861b5867d7604a4ab4c6dd628f6a55328449babd"  # Inactive until actual helper source review.
STATUS = "APPROVED_EXACT_PRIVATE_60S_DIAGNOSTIC_ONLY"


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def finite_authorizer(expected, expected_sha256, expires_unix):
    """Pure exact private-v5 roster binding, not a scheduler or grant."""
    frozen = json.loads(json.dumps(expected, allow_nan=False))
    need(digest(frozen) == expected_sha256 and type(expires_unix) in (int, float)
         and math.isfinite(expires_unix) and 0 < expires_unix <= ORIGINAL_EXPIRY,
         "exact diagnostic descriptor/expiry")
    def authorize(roster, out):
        now = time.time()
        need(type(now) in (int, float) and math.isfinite(now) and 0 < now < expires_unix,
             "unchanged absolute diagnostic authority")
        need(dict(roster) == {NAME: frozen} and out == PRIVATE_ROOT / "coordinator",
             "exact private-v5 one-unit diagnostic roster")
        need(frozen["unit"] == 0 and frozen["attempt"] == 0 and frozen["prior_roots"] == []
             and frozen["external_root"] == str(PRIVATE_ROOT)
             and frozen["generation"] == GENERATION and frozen["block_seconds"] == ACTIVE_SECONDS,
             "fresh unchanged128x400/64actor science; lower60s diagnostic bound")
    return authorize


def phase_binding_manifest(*, guard, consumer, entry, descriptor, phase_child_ref, root):
    """Bind actual already-created objects; never import a duplicate child/guard."""
    from bounded_phase_timer_v1 import PhaseBinding
    from chess_anti_engine.staged_execution import OwnerThreadCallbacks
    from chess_anti_engine.generation_runtime import GenerationSessionRunner
    from scripts.shared_teacher_generation import BT4GenerationDriver, BT4GamePool
    from scripts.bt4_root_policy_stepper import BT4RootPolicyStepper

    need(type(phase_child_ref) is dict and set(phase_child_ref) == {"path", "sha256"}
         and type(phase_child_ref["sha256"]) is str and len(phase_child_ref["sha256"]) == 64
         and Path(phase_child_ref["path"]).is_absolute(), "exact authenticated child source ref")
    need(type(guard.retained) is consumer.OwnerGuard
         and Path(type(guard).check.__code__.co_filename).resolve() == Path(phase_child_ref["path"]),
         "actual child guard and actual retained consumer guard types")
    bindings = (
        PhaseBinding(type(guard), "check", "outer_guard"),
        PhaseBinding(type(guard.retained), "check", "retained_guard"),
        PhaseBinding(OwnerThreadCallbacks, "__call__", "control_request"),
        PhaseBinding(OwnerThreadCallbacks, "service", "control_service"),
        PhaseBinding(OwnerThreadCallbacks, "_invoke", "control_invoke"),
        PhaseBinding(BT4GenerationDriver, "advance", "driver_advance"),
        PhaseBinding(BT4GenerationDriver, "_advance_games", "native_advance"),
        PhaseBinding(BT4GenerationDriver, "_publish", "publish"),
        PhaseBinding(BT4GenerationDriver, "_settle_cpu", "settle_cpu"),
        PhaseBinding(BT4RootPolicyStepper, "prepare_many", "native_prepare"),
        PhaseBinding(BT4RootPolicyStepper, "apply_many", "native_apply"),
        PhaseBinding(BT4GamePool, "_commit", "writer_commit"),
        PhaseBinding(entry.Checkpoint, "begin", "checkpoint"),
        PhaseBinding(entry.Checkpoint, "record_game", "checkpoint"),
        PhaseBinding(entry.Checkpoint, "finish", "checkpoint"),
        PhaseBinding(entry.Checkpoint, "close", "checkpoint"),
        PhaseBinding(GenerationSessionRunner, "__init__", "runner_wait"),
    )
    relatives = (
        "scripts/bt4_queue_consumer_v2.py", "scripts/bt4_longblock_checkpoint_v2.py",
        "chess_anti_engine/staged_execution.py", "chess_anti_engine/generation_runtime.py",
        "scripts/shared_teacher_generation.py", "scripts/bt4_root_policy_stepper.py",
        "targeted_diagnostics_v1.py", "targeted_diagnostics_v2.py", "targeted_diagnostics_v4.py",
        "targeted_diagnostics_v5.py", "bounded_phase_timer_v1.py",
    )
    pins = {str(root / relative): descriptor["source_pins"][relative] for relative in relatives}
    need(phase_child_ref["path"] not in pins, "child source distinct from runtime sources")
    pins[phase_child_ref["path"]] = phase_child_ref["sha256"]
    return bindings, pins

def run_prepared(packet, *, entry, consumer, recovery, guard, parent, leases, priority_module, phase_child_ref):
    need(type(HELPER5_SHA256) is str and len(HELPER5_SHA256) == 64
         and type(TIMER_SHA256) is str and len(TIMER_SHA256) == 64,
         "SOURCE-ONLY unbound helper/runtime draft")
    need(packet.get("status") == STATUS and packet.get("operational_ready") is True
         and all(packet.get(name) is not None for name in (
             "independent_action_review_ref", "root_resource_decision_ref", "paused_restoration_plan_ref")),
         "distinct reviewed diagnostic admission required")
    now = time.time()
    expires = packet["expires_unix"]
    need(type(expires) in (int, float) and math.isfinite(expires) and now < expires <= ORIGINAL_EXPIRY,
         "original expiry never renews")
    need(set(leases) == {"gpu", "io", "supervisor"} and guard.output_root == PRIVATE_ROOT
         and PRIVATE_ROOT.resolve() == PRIVATE_ROOT, "actual all-three/private-v5 guard")
    metadata = PRIVATE_ROOT.lstat()
    need(stat.S_ISDIR(metadata.st_mode) and not stat.S_ISLNK(metadata.st_mode),
         "authenticated child-prepared diagnostic root")
    need(now < guard.limits["deadline_unix"] <= min(expires, now + ACTIVE_SECONDS),
         "actual parent60s deadline, never reset after import/model")
    descriptor = packet["descriptor"]
    authorize = finite_authorizer(descriptor, packet["descriptor_sha256"], expires)
    out = PRIVATE_ROOT / "coordinator"
    authorize({NAME: descriptor}, out)
    root = Path(entry.__file__).resolve().parents[1]
    need(descriptor["source_pins"].get("targeted_diagnostics_v5.py") == HELPER5_SHA256
         and descriptor["source_pins"].get("bounded_phase_timer_v1.py") == TIMER_SHA256
         and packet["runtime_closure_ref"] == {
             "path": str(root / "scripts/bt4_runtime_closure_v1.json"),
             "sha256": descriptor["source_pins"]["scripts/bt4_runtime_closure_v1.json"]},
         "helper identity and actual child-authenticated closure join")
    # The new child must independently join this packet ref to runtime.closure_ref
    # before imports. Closure SHA is packet data, never embedded in its own source.

    from scripts.shared_teacher_owner import run_owned_roster
    from scripts import bt4_root_policy_worker as worker
    from scripts.bt4_generation_evaluator import BT4OnnxEvaluator
    from targeted_diagnostics_v5 import TargetedDiagnostics

    root = Path(entry.__file__).resolve().parents[1]
    quiescent = ProductionQuiescence()
    phase_bindings, phase_source_pins = phase_binding_manifest(
        guard=guard, consumer=consumer, entry=entry, descriptor=descriptor,
        phase_child_ref=phase_child_ref, root=root)
    trace = TargetedDiagnostics(worker.BT4GamePool, entry.Checkpoint, BT4OnnxEvaluator,
        PRIVATE_ROOT / "diagnostic-partial-60s.json", expected_origins={
            "pool": root / "scripts/shared_teacher_generation.py",
            "checkpoint": root / "scripts/bt4_longblock_checkpoint_v2.py",
            "evaluator": root / "scripts/bt4_generation_evaluator.py"}, quiescent=quiescent,
        phase_bindings=phase_bindings, phase_source_pins=phase_source_pins)
    def actual_call():
        return run_owned_roster({NAME: descriptor}, entry=entry, consumer=consumer, recovery=recovery,
            guard=guard, parent=parent, leases=leases, out=out, priority_module=priority_module,
            authorize=authorize, deadline_seconds=min(float(ACTIVE_SECONDS),
                guard.limits["deadline_unix"] - now), fake_cpu=False, **GEOMETRY)
    # A primary guard deadline/error propagates unchanged. Diagnostic helper must
    # preserve entered/firstexecute/cadence files and unknown ownership until reap.
    result = call_with_diagnostics(trace, quiescent, actual_call)
    return {"status": "DIAGNOSTIC_CALL_RETURNED_NOT_UNIT_QUALIFICATION", "result": result,
            "diagnostic": trace.snapshot(), "full_unit_qualification": False,
            "native_admission": False, "training_credit": 0, "speed_claim": False}
