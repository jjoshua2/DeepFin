"""UNRUN V2 standalone bounded-phase timing CPU gate; frozen author source pins. Root alone may launch after review."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import resource
import runpy
import selectors
import signal
import stat
import subprocess
import sys
import time
import threading
import unittest

SOURCE = Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/docs/intake/pr1110-targeted-diagnostics-v1')
ROOT = Path('/tmp/pr1110-bounded-phase-timing-cpu-20261021-v1')
CAPSULE = ROOT / 'source'
CASES = ROOT / 'cases'
BOOT = 'e34eff27-d1dc-49c0-bac2-e8525ea1b52f'
PINS = {
    'targeted_diagnostics_v1.py': '48dc44768aabdc4e18c4314abeeaefdb255e65ea54150c6b0d04285d36332a22',
    'targeted_diagnostics_v2.py': '444bf23fcd1850efcacd55bb888e7d275e3a02bde3846c80bf0813cecc336bb3',
    'bounded_phase_timer_v1.py': '868384f4179625eea5af5b84861b5867d7604a4ab4c6dd628f6a55328449babd',
    'targeted_diagnostics_v5.py': '46b951d0e0517491fd26849dc93e9ab9fa1c5b4cf195ae200e21c1b1344fb14d',
    'test_phase_timing_v1.py': '823351a95a42a4e10feef870d2c6779f875e073048501e6d0bc53c6ffe168abb',
    'phase_termination_child_v1.py': '8c44cc6130b60e9772fe9687304a671c85e8719a3b6306f23315a82d8afe8ae7',
    'chess_anti_engine/__init__.py': '36d2d5d42f1b8f07957b14e420a5e9a18c09acb9caeb32eb63252d335bc36d50',
    'chess_anti_engine/async_safety.py': '72d2db150d1ff4522e30cd6d586340cb0a93cd181e15240645b7ed7a7da8f70c',
    'chess_anti_engine/request_routing.py': '6a656cffe5a503bd0c0ed7f2b93291fa0cfc44c9f90ba7aa112a874f26827e46',
    'chess_anti_engine/staged_execution.py': 'a02bc7eb86efde6910d6852056ef5414728885e9da733bbed41e1a17da6508f2',
}
SOURCE_PATHS = {
    'targeted_diagnostics_v1.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/docs/intake/pr1110-targeted-diagnostics-v1/targeted_diagnostics_v1.py'),
    'targeted_diagnostics_v2.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/docs/intake/pr1110-targeted-diagnostics-v1/targeted_diagnostics_v2.py'),
    'bounded_phase_timer_v1.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/docs/intake/pr1110-bounded-phase-timing-v1/bounded_phase_timer_v1.py'),
    'targeted_diagnostics_v5.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/docs/intake/pr1110-bounded-phase-timing-v1/targeted_diagnostics_v5.py'),
    'test_phase_timing_v1.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/docs/intake/pr1110-bounded-phase-timing-v1/test_phase_timing_v1.py'),
    'phase_termination_child_v1.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/docs/intake/pr1110-bounded-phase-timing-v1/phase_termination_child_v1.py'),
    'chess_anti_engine/__init__.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/chess_anti_engine/__init__.py'),
    'chess_anti_engine/async_safety.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/chess_anti_engine/async_safety.py'),
    'chess_anti_engine/request_routing.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/chess_anti_engine/request_routing.py'),
    'chess_anti_engine/staged_execution.py': Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-affinity/chess_anti_engine/staged_execution.py'),
}
MODULES = {
    'targeted_diagnostics_v1': 'targeted_diagnostics_v1.py',
    'targeted_diagnostics_v2': 'targeted_diagnostics_v2.py',
    'bounded_phase_timer_v1': 'bounded_phase_timer_v1.py',
    'targeted_diagnostics_v5': 'targeted_diagnostics_v5.py',
    'test_phase_timing_v1': 'test_phase_timing_v1.py',
    'chess_anti_engine': 'chess_anti_engine/__init__.py',
    'chess_anti_engine.async_safety': 'chess_anti_engine/async_safety.py',
    'chess_anti_engine.request_routing': 'chess_anti_engine/request_routing.py',
    'chess_anti_engine.staged_execution': 'chess_anti_engine/staged_execution.py',
}
CHILD_MODULES = ('bounded_phase_timer_v1','targeted_diagnostics_v1','targeted_diagnostics_v2','targeted_diagnostics_v5')
CHILD_SOURCE_NAME = 'phase_termination_child_v1.py'
TEST_MODULE = 'test_phase_timing_v1'
EXPECTED_SOURCE_IDS = [
    'nested_recursion_wall_and_thread_cpu_exact',
    'concurrent_overlap_never_cross_thread_subtracted',
    'clock_and_depth_failures_preserve_target_calls_errors',
    'guard_checkpoint_descriptors_and_owned_wait_restore',
    'actual_owner_callbacks_guard_once_affinity_primary_error',
    'phase_ownership_retained_until_quiescent',
    'mandatory_execute_gate_and_due_pending_phase_snapshot',
    'phase_source_authentication_before_patch',
    'fixed_pure_call_overhead_report_no_noise_threshold',
]
EXPECTED_TERMINATION_IDS = [
    'owned_SIGTERM_inside_guard_after_pending_phase_ack',
    'owned_SIGKILL_inside_guard_after_pending_phase_ack',
]
READ_CAP = 16 << 20
OUTPUT_CAP = 4 << 20
STREAM_CAP = 1 << 20
gate_clock = time.monotonic
started = gate_clock()
read_bytes = stream_bytes = 0
owned = None
children = []
launches = 0
allowed_spawn = None
cleaning = False


def need(value, message):
    if not value:
        raise RuntimeError(message)


def checkpoint():
    need(gate_clock() - started < (90 if cleaning else 60), 'active/cleanup deadline')


def stable(path, limit, digest=None):
    global read_bytes
    checkpoint()
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        first = os.fstat(fd)
        need(stat.S_ISREG(first.st_mode) and first.st_size <= limit, 'bounded regular file')
        pieces = []
        count = 0
        while True:
            raw = os.read(fd, 65536)
            if not raw:
                break
            count += len(raw)
            read_bytes += len(raw)
            need(count <= limit and read_bytes <= READ_CAP, 'explicit named read cap')
            pieces.append(raw)
            checkpoint()
        stamp = lambda s: (s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        need(stamp(first) == stamp(os.fstat(fd)) == stamp(path.lstat()), 'unstable named source')
        raw = b''.join(pieces)
        need(digest is None or hashlib.sha256(raw).hexdigest() == digest, 'exact source pin differs')
        return raw
    finally:
        os.close(fd)


def exclusive(path, raw):
    need(path.parent.resolve(strict=True).is_relative_to(ROOT), 'owned output parent')
    with path.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())


def facts():
    boot = stable(Path('/proc/sys/kernel/random/boot_id'), 128).decode().strip()
    need(boot == BOOT, 'boot mismatch')
    mem = stable(Path('/proc/meminfo'), 65536).decode()
    available = int(next(r.split()[1] for r in mem.splitlines() if r.startswith('MemAvailable:'))) * 1024
    need(available >= 8 << 30, 'memory headroom')
    # Fail closed even on reuse of these PIDs. No signals target these identities.
    for pid in (224690, 238033, 238034, 239144, 239145, 239631, 239632, 239811, 239812):
        need(not os.path.lexists('/proc/' + str(pid)), 'closed PID unexpectedly present')
    locks = stable(Path('/proc/locks'), 1 << 20).decode()
    ids = {(os.major(2096), os.minor(2096), i) for i in (81348917, 18835410, 18503149)}
    ids.add((os.major(73), os.minor(73), 1407374886384886))
    matching = []
    for row in locks.splitlines():
        for token in row.split():
            p = token.split(':')
            if len(p) != 3:
                continue
            try:
                identity = (int(p[0], 16), int(p[1], 16), int(p[2]))
            except ValueError:
                continue
            if identity in ids:
                matching.append(row)
    need(not matching, 'protected lock identity held')
    return {'boot': boot, 'mem_available': available, 'closed_pids_absent': [224690, 238033, 238034, 239144, 239145, 239631, 239632, 239811, 239812],
            'ordinary_known_birth': 45987470, 'v3_parent_known_birth': 55863644,
            'v3_child_birth': 'unrecorded; exact PID absence required',
            'post60_parent_known_birth': 56322853, 'post60_child_birth': 'unrecorded; exact PID absence required', 'matching_lock_rows': matching}


def meter():
    total = 0
    files = {}
    for directory, dirs, names in os.walk(ROOT, followlinks=False):
        for name in [*dirs, *names]:
            need(not (Path(directory) / name).is_symlink(), 'output symlink')
        for name in names:
            path = Path(directory) / name
            size = path.stat().st_size
            total += size
            need(total <= OUTPUT_CAP and len(files) < 128, 'owned output bound')
            raw = stable(path, OUTPUT_CAP)
            files[str(path.relative_to(ROOT))] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    return total, files


def no_children():
    try:
        pid, status = os.waitpid(-1, os.WNOHANG)
    except ChildProcessError:
        return True
    raise RuntimeError('kernel ECHILD absent: unexpected child ' + str(pid))


# Child imports ONLY standard library and the fully pinned private helper capsule.
# Audit forbids additional process/network/lease/shared-memory creation. File writes
# are restricted to the caller's exact owned cases tree. Limits are inherited.
CHILD_CODE = r'''
import os, sys, runpy, importlib, json
from pathlib import Path
capsule, child, snapshot = map(Path, sys.argv[1:4])
assert capsule.resolve(strict=True) == capsule and child.parent == capsule
sys.path.insert(0, str(capsule))
def audit(event, args):
    if event in {'subprocess.Popen','os.fork','os.forkpty','os.posix_spawn','os.exec','os.system',
                 'socket.__new__','ctypes.dlopen','mmap.__new__','fcntl.flock','fcntl.lockf'}:
        raise RuntimeError('child forbidden event: ' + event)
    if event == 'open':
        path, mode, flags = args
        if isinstance(path, int):
            return
        p = Path(os.fsdecode(path)).absolute()
        if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
            assert p.parent.resolve(strict=True).is_relative_to(snapshot.parent)
    if event in {'os.remove','os.mkdir','os.rmdir','os.link','os.rename','os.symlink'}:
        for value in args[:2] if event in {'os.link','os.rename','os.symlink'} else args[:1]:
            if isinstance(value, (str, bytes)):
                p = Path(os.fsdecode(value)).absolute()
                assert p.parent.resolve(strict=True).is_relative_to(snapshot.parent)
sys.addaudithook(audit)
origins = {}
for name, expected_path in json.loads(sys.argv[4]).items():
    module = importlib.import_module(name)
    assert Path(module.__file__) == Path(expected_path)
    origins[name] = module.__file__
print(json.dumps({'child_observed_origins': origins}, sort_keys=True), file=sys.stderr, flush=True)
sys.argv = [str(child), str(snapshot)]
runpy.run_path(str(child), run_name='__main__')
'''


def preserve_streams(root, streams, primary, cleanup_errors, eof, kernel_echild, identity):
    """Bounded best effort on success/failure; never replaces an active primary."""
    try:
        message = None if primary is None else str(primary)[:1024]
    except BaseException:
        message = '<unprintable primary>'
    receipt = {'primary': None if primary is None else {
        'type': type(primary).__name__, 'message': message},
        'cleanup_unknowns': list(cleanup_errors), 'eof': dict(eof),
        'kernel_ECHILD': kernel_echild, 'identity': identity,
        'persistence_errors': [], 'streams': {}}
    for label in ('stdout', 'stderr'):
        raw = bytes(streams[label])
        digest = hashlib.sha256(raw).hexdigest()
        receipt['streams'][label] = {'bytes': len(raw), 'sha256': digest}
        try:
            exclusive(root / ('child-' + label + '.txt'), raw)
            stable(root / ('child-' + label + '.txt'), STREAM_CAP, digest)
        except BaseException as error:
            receipt['persistence_errors'].append(label + ':' + type(error).__name__)
    try:
        raw = (json.dumps(receipt, sort_keys=True) + '\n').encode()
        need(len(raw) <= 16384, 'cleanup receipt bound')
        exclusive(root / 'CHILD-CLEANUP.json', raw)
        stable(root / 'CHILD-CLEANUP.json', 16384, hashlib.sha256(raw).hexdigest())
    except BaseException as error:
        receipt['persistence_errors'].append('receipt:' + type(error).__name__)
    # At most one short controller line; native capture retains it if disk fails.
    if receipt['persistence_errors'] or primary is not None or cleanup_errors:
        try:
            print(json.dumps({'child_cleanup': receipt}, sort_keys=True), file=sys.stderr, flush=True)
        except BaseException:
            pass  # Native stream failure must not replace the primary either.
    return receipt

def run_owned_termination(child_source, snapshot_path, signum):
    global owned, stream_bytes, launches, allowed_spawn, cleaning
    checkpoint()
    need(owned is None and no_children() and launches < 2, 'at most one child and exactly two global launch slots')
    need(child_source == CAPSULE / CHILD_SOURCE_NAME
         and snapshot_path.parent.resolve(strict=True).is_relative_to(CASES)
         and signum in (signal.SIGTERM, signal.SIGKILL), 'exact child test contract')
    for name, digest in PINS.items():
        stable(CAPSULE / name, 131072, digest)
    argv = [sys.executable, '-I', '-S', '-B', '-c', CHILD_CODE,
            str(CAPSULE), str(child_source), str(snapshot_path),
            json.dumps({m: str(CAPSULE / MODULES[m]) for m in CHILD_MODULES}, sort_keys=True)]
    streams = {'stdout': bytearray(), 'stderr': bytearray()}
    selector = selectors.DefaultSelector()
    pidfd = None
    ack = None
    birth = None
    sent = False
    eof = {'stdout': False, 'stderr': False}
    child_origins = None
    launch_started = gate_clock()
    launches += 1
    allowed_spawn = argv
    try:
        popen = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, close_fds=True, env=dict(os.environ))
    finally:
        allowed_spawn = None
    owned = popen
    try:
        pidfd = os.pidfd_open(popen.pid, 0)
        proc_raw = stable(Path('/proc') / str(popen.pid) / 'stat', 8192).decode()
        birth = int(proc_raw.rsplit(')', 1)[1].split()[19])
        for label, stream in (('stdout', popen.stdout), ('stderr', popen.stderr)):
            os.set_blocking(stream.fileno(), False)
            selector.register(stream, selectors.EVENT_READ, label)
        ack_deadline = min(started + 55, gate_clock() + 8)
        while selector.get_map():
            checkpoint()
            need(ack is not None or gate_clock() < ack_deadline, 'durable ACK timeout')
            for key, _ in selector.select(0.05):
                raw = os.read(key.fileobj.fileno(), min(65536, STREAM_CAP - stream_bytes + 1))
                if not raw:
                    eof[key.data] = True
                    selector.unregister(key.fileobj)
                    continue
                remaining = STREAM_CAP - stream_bytes
                streams[key.data].extend(raw[:remaining])
                stream_bytes += min(len(raw), remaining)
                need(len(raw) <= remaining, 'aggregate captured child stream cap')
            if ack is None and b'\n' in streams['stdout']:
                line, remainder = bytes(streams['stdout']).split(b'\n', 1)
                need(not remainder and len(line) < 65536, 'one bounded child ACK')
                ack = json.loads(line)
                need(set(ack) == {'durable_snapshot', 'sha256', 'pid'} and ack['pid'] == popen.pid,
                     'owned child ACK identity')
                durable = Path(ack['durable_snapshot'])
                need(durable.parent == snapshot_path.parent and durable.name.startswith(snapshot_path.name + '.during-'),
                     'owned durable snapshot path')
                pending = json.loads(stable(durable, 196608, ack['sha256']))
                need(durable.name == snapshot_path.name + '.during-01.json'
                     and pending['snapshot_pid'] == popen.pid
                     and pending['snapshot_thread_final'] is False
                     and gate_clock() - launch_started < 20, 'durable pending phase ACK before20s')
                frames = [frame for row in pending['phase_timing']['threads'] for frame in row['open_frames']
                          if frame['phase'] == 'outer_guard']
                need(frames and frames[0]['original_entered'] is False
                     and pending['phase_timing']['closed_phase_totals']['outer_guard']['original_entered'] == 0,
                     'outerguard pending state at durable publication')
                # A live pidfd pins this Popen generation even if its integer PID is reused.
                need(popen.poll() is None, 'child exited before owned signal')
                signal.pidfd_send_signal(pidfd, signum, None, 0)
                sent = True
            if popen.poll() is not None and not selector.get_map():
                break
        returncode = popen.wait(timeout=1)
        need(ack is not None and sent and returncode == -signum, 'expected signal termination')
        need(bytes(streams['stdout']).count(b'\n') == 1, 'exactly one ACK line')
        stable(Path(ack['durable_snapshot']), 196608, ack['sha256'])
        child_origins = json.loads(bytes(streams['stderr']))['child_observed_origins']
        need(child_origins == {m: str(CAPSULE / MODULES[m]) for m in CHILD_MODULES},
             'child observed capsule origins')
    finally:
        primary = sys.exc_info()[1]
        cleanup_errors = []
        kernel_echild = False
        cleaning = True
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        try:
            if popen.poll() is None:
                if pidfd is None:
                    popen.kill()  # Direct unreaped owned Popen cannot have reused PID.
                else:
                    try:
                        signal.pidfd_send_signal(pidfd, signal.SIGKILL, None, 0)
                    except ProcessLookupError:
                        pass
        except BaseException as error:
            cleanup_errors.append('signal:' + type(error).__name__)
        try:
            popen.wait(timeout=25)
        except BaseException as error:
            cleanup_errors.append('wait:' + type(error).__name__)
        # Drain any already-produced bytes after reaping; retain bounded prefixes
        # and explicitly mark incomplete I/O rather than fabricate two EOFs.
        for label, stream in (('stdout', popen.stdout), ('stderr', popen.stderr)):
            try:
                os.set_blocking(stream.fileno(), False)
                while not eof[label] and gate_clock() - started < 89:
                    raw = os.read(stream.fileno(), min(65536, STREAM_CAP - stream_bytes + 1))
                    if not raw:
                        eof[label] = True
                        break
                    remaining = STREAM_CAP - stream_bytes
                    streams[label].extend(raw[:remaining])
                    stream_bytes += min(len(raw), remaining)
                    if len(raw) > remaining:
                        cleanup_errors.append('stream cap:incomplete ' + label)
                        break
            except BaseException as error:
                cleanup_errors.append('drain ' + label + ':' + type(error).__name__)
        for label, close in [('selector', selector.close),
                             ('stdout', popen.stdout.close), ('stderr', popen.stderr.close)]:
            try:
                close()
            except BaseException as error:
                cleanup_errors.append('close ' + label + ':' + type(error).__name__)
        if pidfd is not None:
            try:
                os.close(pidfd)
            except BaseException as error:
                cleanup_errors.append('pidfd close:' + type(error).__name__)
        owned = None
        try:
            kernel_echild = popen.returncode is not None and no_children()
        except BaseException as error:
            cleanup_errors.append('kernel ECHILD:' + type(error).__name__)
        receipt = preserve_streams(snapshot_path.parent, streams, primary,
                                   cleanup_errors, eof, kernel_echild,
                                   {'pid': popen.pid, 'birth_ticks': birth,
                                    'returncode': popen.returncode, 'requested_signal': int(signum)})
        cleaning = False
        signal.signal(signal.SIGTERM, terminate)
        if primary is None:
            need(kernel_echild and not cleanup_errors and not receipt['persistence_errors']
                 and all(eof.values()), 'child cleanup/preservation complete')
    result = {'ack': ack, 'returncode': returncode, 'kernel_ECHILD': True,
              'pid': popen.pid, 'birth_ticks': birth, 'signal': int(signum),
              'child_elapsed_seconds': gate_clock() - launch_started,
              'stdout_bytes': len(streams['stdout']), 'stderr_bytes': len(streams['stderr']),
              'stdout_sha256': hashlib.sha256(bytes(streams['stdout'])).hexdigest(),
              'stderr_sha256': hashlib.sha256(bytes(streams['stderr'])).hexdigest(),
              'observed_origins': child_origins, 'pinned_runpy_source_path': str(child_source)}
    exclusive(snapshot_path.parent / 'CHILD-SUCCESS.json',
              (json.dumps(result, sort_keys=True) + '\n').encode())
    children.append(result)
    meter()
    return result


need(sys.version_info[:2] == (3, 10) and sys.flags.isolated and sys.flags.no_site
     and sys.flags.dont_write_bytecode and sys.flags.optimize == 0, 'exact CP310 isolated startup')
need(len(sys.argv) == 2 and len(sys.argv[1]) == 64, 'exact reviewed self SHA argument')
stable(Path(__file__), 65536, sys.argv[1])
need(sys.executable == '/usr/bin/python3.10', 'fixed system CP310 executable')
stable(Path(sys.executable), 8 << 20, 'a2f33a6e006989270f4340528eb61f8f97366e00a5d1b602ac8672ea44fc56ae')
need(PINS and TEST_MODULE != 'UNFROZEN_PHASE_TEST_MODULE', 'author source must be frozen')
need(sorted(os.sched_getaffinity(0)) == [29, 30] and os.getpriority(os.PRIO_PROCESS, 0) == 19,
     'affinity/nice')
need(os.environ.get('CUDA_VISIBLE_DEVICES') == '' and all(os.environ.get(n) == '2' for n in (
    'OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS')), 'environment bounds')
for which, cap in ((resource.RLIMIT_CPU, 10), (resource.RLIMIT_AS, 512 << 20)):
    soft, hard = resource.getrlimit(which)
    finite = [v for v in (soft, hard, cap) if v != resource.RLIM_INFINITY]
    bound = min(finite)
    resource.setrlimit(which, (bound, min(hard, cap) if hard != resource.RLIM_INFINITY else cap))
need(hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal') and no_children(), 'owned pidfd support/ECHILD')
def audit(event, args):
    if event == 'subprocess.Popen':
        need(allowed_spawn is not None and args[1] == allowed_spawn
             and args[0] == sys.executable and owned is None, 'only exact owned child spawn')
    if event in {'os.fork','os.forkpty','os.posix_spawn','os.exec','os.system',
                 'socket.__new__','ctypes.dlopen','mmap.__new__','fcntl.flock','fcntl.lockf'}:
        raise RuntimeError('forbidden gate event: ' + event)
    if event == 'open':
        path, mode, flags = args
        if isinstance(path, int):
            return
        p = Path(os.fsdecode(path)).absolute()
        if p == Path('/dev/null') and allowed_spawn is not None:
            return
        if flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND):
            need(p.parent.resolve(strict=True).is_relative_to(ROOT), 'write outside private root')
    if event in {'os.remove','os.mkdir','os.rmdir','os.link','os.rename','os.symlink'}:
        for value in args[:2] if event in {'os.link','os.rename','os.symlink'} else args[:1]:
            if isinstance(value, (str, bytes)):
                p = Path(os.fsdecode(value)).absolute()
                need(p == ROOT or p.parent.resolve(strict=True).is_relative_to(ROOT), 'mutation outside private root')

sys.addaudithook(audit)
before = facts()
need(ROOT.parent.resolve(strict=True) == ROOT.parent and not os.path.lexists(ROOT), 'fresh fixed private root')
need(set(SOURCE_PATHS) == set(PINS) and set(MODULES.values()) == set(PINS) - {CHILD_SOURCE_NAME},
     'exact explicit source/module inventory')
source_payloads = {name: stable(SOURCE_PATHS[name], 131072, digest) for name, digest in PINS.items()}
ROOT.mkdir(mode=0o700)
CAPSULE.mkdir(mode=0o700)
CASES.mkdir(mode=0o700)
for name, raw in source_payloads.items():
    need(not Path(name).is_absolute() and Path(name).as_posix() == name
         and not any(p in ('.','..','__pycache__') for p in Path(name).parts)
         and name.endswith('.py'), 'fixed safe capsule Python relative names')
    (CAPSULE / name).parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    exclusive(CAPSULE / name, raw)
    stable(CAPSULE / name, 131072, PINS[name])
# Standalone boundary-control capsule prefix is explicit, disclosed and private.
# No production path, conftest, pytest, Torch or native package is imported.
sys.path.insert(0, str(CAPSULE))
expected_path = tuple(sys.path)
module = importlib.import_module(TEST_MODULE)
origins = {}
for module_name, relative in MODULES.items():
    mod = importlib.import_module(module_name)
    need(Path(mod.__file__) == CAPSULE / relative, 'exact private capsule origin')
    origins[module_name] = mod.__file__
threads_before = [(t.ident, t.name, t.daemon) for t in threading.enumerate()]


observations = {}


class Gate(unittest.TestCase):
    def test_00_controller_retention(self):
        global exclusive
        case = CASES / 'controller-retention'
        case.mkdir(mode=0o700)
        streams = {'stdout': bytearray(b'bad ACK prefix'), 'stderr': bytearray(b'fault stderr')}
        primary = ValueError('synthetic controller parse failure')
        try:
            raise primary
        except ValueError:
            receipt = preserve_streams(case, streams, primary, ['synthetic cleanup unknown'],
                                       {'stdout': False, 'stderr': False}, True, {'synthetic': True})
            need(sys.exc_info()[1] is primary, 'primary retained through successful persistence')
        need(not receipt['persistence_errors'] and receipt['primary']['type'] == 'ValueError'
             and receipt['eof'] == {'stdout': False, 'stderr': False}, 'failure receipt/incomplete IO explicit')
        need(stable(case / 'child-stdout.txt', STREAM_CAP) == bytes(streams['stdout'])
             and stable(case / 'child-stderr.txt', STREAM_CAP) == bytes(streams['stderr']), 'raw prefixes retained')
        original = exclusive
        def fail_write(path, raw):
            raise OSError('synthetic write failure')
        exclusive = fail_write
        try:
            try:
                raise primary
            except ValueError:
                failed = preserve_streams(case, streams, primary, [],
                                          {'stdout': False, 'stderr': False}, True, {'synthetic': True})
                need(sys.exc_info()[1] is primary and len(failed['persistence_errors']) == 3,
                     'write failures do not mask active primary')
        finally:
            exclusive = original
        observations['controller_retention'] = ['bounded_raw_prefix_and_failure_receipt',
                                                 'persistence_failures_preserve_primary']

    def test_01_source_controls(self):
        case = CASES / 'source-controls'
        case.mkdir(mode=0o700)
        observations['source_controls'] = module.run_source_controls(case)
        need(observations['source_controls'] == EXPECTED_SOURCE_IDS, 'nine exact source control IDs')
        meter()

    def test_02_termination_controls(self):
        case = CASES / 'termination-controls'
        case.mkdir(mode=0o700)
        observations['termination_controls'] = module.run_termination_controls(case, run_owned_termination)
        need(observations['termination_controls'] == EXPECTED_TERMINATION_IDS, 'two exact termination IDs')


def terminate(signum, frame):
    raise TimeoutError('outer termination received')


signal.signal(signal.SIGTERM, terminate)
suite = unittest.defaultTestLoader.loadTestsFromTestCase(Gate)
result = unittest.TextTestRunner(stream=sys.stderr, verbosity=2).run(suite)
need(result.wasSuccessful() and result.testsRun == 3 and not result.skipped, 'all three standalone gate groups pass')
need(tuple(sys.path) == expected_path and owned is None and no_children(), 'terminal path/ECHILD')
need(launches == len(children) == 2 and [c['signal'] for c in children] == [int(signal.SIGTERM), int(signal.SIGKILL)],
     'exact two sequential termination children')
for name, digest in PINS.items():
    stable(SOURCE_PATHS[name], 131072, digest)
    stable(CAPSULE / name, 131072, digest)
for name, path in origins.items():
    need(sys.modules[name].__file__ == path, 'origin restored/unchanged')
need(not any(n.split('.')[0] in {'torch','pytest','numpy','onnxruntime'} for n in sys.modules)
     and all(n in MODULES for n in sys.modules if n == 'chess_anti_engine' or n.startswith('chess_anti_engine.')),
     'only exact selected pure callback package; no model/native imports')
threads_after = [(t.ident, t.name, t.daemon) for t in threading.enumerate()]
need(threads_after == threads_before, 'test-owned threads joined and identities restored')
need(isinstance(module.OVERHEAD_REPORT, list) and len(module.OVERHEAD_REPORT) == 6
     and [r['arm'] for r in module.OVERHEAD_REPORT] == ['timer_core'] * 3 + ['phase_wrapper_cadence_noop'] * 3,
     'complete six-row overhead report with both three-trial arms')
after = facts()
output_bytes, files = meter()
usage = resource.getrusage(resource.RUSAGE_SELF)
child_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
report = dict(schema='PR1110_BOUNDED_PHASE_TIMING_STDLIB_CPU_V1',
    status='PASS_STANDALONE_SOURCE_AND_TWO_OWNED_TERMINATION_GROUPS',
    unittest_groups=3, controls=observations, overhead_report=module.OVERHEAD_REPORT,
    threads_before=threads_before, threads_after=threads_after, children=children, kernel_ECHILD=True, before=before, after=after,
    source_pins=PINS, python={'path': sys.executable, 'sha256': 'a2f33a6e006989270f4340528eb61f8f97366e00a5d1b602ac8672ea44fc56ae'}, observed_origins=origins, sys_path=list(expected_path),
    explicit_named_read_bytes=read_bytes, captured_child_stream_bytes=stream_bytes,
    output_bytes_before_report=output_bytes, files=files, elapsed=gate_clock()-started,
    self_cpu_seconds=usage.ru_utime+usage.ru_stime,
    reaped_children_cpu_seconds=child_usage.ru_utime+child_usage.ru_stime,
    self_peak_rss_bytes=usage.ru_maxrss*1024, child_max_peak_rss_bytes=child_usage.ru_maxrss*1024,
    limits={'cpu':resource.getrlimit(resource.RLIMIT_CPU),'as':resource.getrlimit(resource.RLIMIT_AS)},
    accounting='CPU10/AS512MiB limits are per-process. At most parent+one child yields AS ceiling<=1GiB. Parent plus exactly two children have theoretical CPU<=30 seconds under these lower limits, not an independent hard family CPU quota. Named reads/output and captured child streams are explicit meters; interpreter/OS reads and native transport streams are separate.',
    scope='Standalone phase boundary controls plus exact pure OwnerThreadCallbacks source and owned SIGTERM/SIGKILL only; no conftest/model/roster/GPU/queue/lease/runtime qualification',
    training_credit=0, product_credit=0)
raw = (json.dumps(report, sort_keys=True) + '\n').encode()
need(len(raw) < 131072 and output_bytes + len(raw) <= OUTPUT_CAP, 'final report output cap')
exclusive(ROOT / 'REPORT.json', raw)
stable(ROOT / 'REPORT.json', 131072, hashlib.sha256(raw).hexdigest())
print(raw.decode(), end='', flush=True)
