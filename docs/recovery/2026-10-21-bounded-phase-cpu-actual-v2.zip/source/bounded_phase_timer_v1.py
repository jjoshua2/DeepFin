"""UNRUN bounded synchronous per-thread timing; no profiler, threads or IO."""
import threading
import time
import json
from dataclasses import dataclass


@dataclass(frozen=True)
class PhaseBinding:
    target: type
    name: str
    phase: str

PHASES = (
    "outer_guard", "retained_guard", "control_owner_direct", "control_offowner_wait", "control_service",
    "control_invoke", "driver_advance", "native_advance", "native_prepare",
    "native_apply", "publish", "settle_cpu", "writer_commit", "checkpoint",
    "execute", "runner_wait", "diagnostics_io",
)
FIELDS = ("calls", "original_entered", "returns", "raises", "wall_inclusive_ns", "wall_self_ns",
          "cpu_inclusive_ns", "cpu_self_ns", "wall_unknown_calls", "self_unknown_calls")
CEILING = 2**63 - 1


class PhaseTimer:
    """Inclusive invocations overlap; only same-thread direct children subtract.

    Recursion counts each invocation. Closed sums exclude open frames; snapshots
    report open elapsed separately. Thread CPU is current-thread CPU, not process,
    descendant, GPU or native-worker CPU. Unknown child timing invalidates parent
    self time; it is never silently subtracted as zero.
    """
    def __init__(self, *, wall_ns=time.monotonic_ns, cpu_ns=time.thread_time_ns):
        self.wall_ns, self.cpu_ns = wall_ns, cpu_ns
        self.lock = threading.Lock()
        self.totals = {name: dict.fromkeys(FIELDS, 0) for name in PHASES}
        self.threads = {}  # Thread objects prevent ident-reuse aliasing.
        self.errors = []

    def _error(self, message):
        if len(self.errors) < 8:
            self.errors.append(str(message)[:192])

    def _clock(self):
        try:
            value = self.wall_ns(), self.cpu_ns()
            if any(type(n) is not int or not 0 <= n <= CEILING for n in value):
                raise ValueError("nonnegative integer clocks required")
            return value
        except BaseException:
            return None

    @staticmethod
    def _add(stats, field, value=1):
        stats[field] = min(CEILING, stats[field] + value)

    def begin(self, phase):
        try:
            now = self._clock()
            current = threading.current_thread()
            with self.lock:
                if phase not in self.totals:
                    self._error("unknown phase")
                    return None
                stats = self.totals[phase]
                self._add(stats, "calls")
                thread = self.threads.get(current)
                if thread is None:
                    if len(self.threads) >= 16:
                        self._error("thread capacity")
                        return (phase, None, None)
                    thread = {"ident": current.ident, "native_id": current.native_id,
                              "stack": []}
                    self.threads[current] = thread
                if now is None or len(thread["stack"]) >= 16:
                    self._error("clock failure" if now is None else "depth capacity")
                    if thread["stack"]:
                        thread["stack"][-1]["unknown_child"] = True
                    return (phase, thread, None)
                frame = {"phase": phase, "start": now, "child_wall": 0,
                         "child_cpu": 0, "unknown_child": False, "original_entered": False}
                thread["stack"].append(frame)
                return phase, thread, frame
        except BaseException:
            # An observation failure must never prevent the target invocation.
            with self.lock:
                self._error("timing entry failed")
            return None

    def mark_entered(self, token):
        if token is None:
            return
        try:
            phase, _thread, frame = token
            with self.lock:
                if frame is None or not frame["original_entered"]:
                    self._add(self.totals[phase], "original_entered")
                    if frame is not None:
                        frame["original_entered"] = True
        except BaseException:
            with self.lock:
                self._error("original entry observation failed")

    def end(self, token, returned):
        if token is None:
            return
        try:
            now = self._clock()
            phase, thread, frame = token
            with self.lock:
                stats = [self.totals[phase]]
                for row in stats:
                    self._add(row, "returns" if returned else "raises")
                valid = (frame is not None and now is not None and
                         all(end >= start for end, start in zip(now, frame["start"])))
                if frame is not None:
                    stack = thread["stack"]
                    if self.threads.get(threading.current_thread()) is not thread:
                        self._error("cross-thread timing completion")
                        for row in stats:
                            self._add(row, "wall_unknown_calls")
                            self._add(row, "self_unknown_calls")
                        return  # Never pop or subtract another thread's frame.
                    if not stack or stack[-1] is not frame:
                        self._error("non-LIFO or cross-thread timing")
                        valid = False
                    else:
                        stack.pop()
                if not valid:
                    for row in stats:
                        self._add(row, "wall_unknown_calls")
                        self._add(row, "self_unknown_calls")
                    if thread is not None and thread["stack"]:
                        thread["stack"][-1]["unknown_child"] = True
                    self._error("unmeasured completed interval")
                    return
                wall, cpu = (end - start for end, start in zip(now, frame["start"]))
                own_valid = (not frame["unknown_child"] and wall >= frame["child_wall"]
                             and cpu >= frame["child_cpu"])
                for row in stats:
                    self._add(row, "wall_inclusive_ns", wall)
                    self._add(row, "cpu_inclusive_ns", cpu)
                    if own_valid:
                        self._add(row, "wall_self_ns", wall - frame["child_wall"])
                        self._add(row, "cpu_self_ns", cpu - frame["child_cpu"])
                    else:
                        self._add(row, "self_unknown_calls")
                if not own_valid:
                    self._error("self interval unavailable")
                if thread["stack"]:
                    parent = thread["stack"][-1]
                    parent["child_wall"] += wall
                    parent["child_cpu"] += cpu
        except BaseException:
            # Never replace an original target return or exception.
            with self.lock:
                self._error("timing completion failed")

    def call(self, phase, original, *args, **kwargs):
        token = self.begin(phase)
        returned = False
        try:
            self.mark_entered(token)
            result = original(*args, **kwargs)
            returned = True
            return result
        finally:
            self.end(token, returned)

    def snapshot(self):
        now = self._clock()
        with self.lock:
            threads = []
            for owner, thread in self.threads.items():
                frames = []
                for index, frame in enumerate(thread["stack"]):
                    # Wall clocks share a monotonic epoch. CPU clock belongs to
                    # the snapshot caller; never subtract it across threads.
                    elapsed = None if now is None or now[0] < frame["start"][0] else now[0] - frame["start"][0]
                    frames.append({"phase": frame["phase"], "depth": index,
                                   "original_entered": frame["original_entered"],
                                   "start_monotonic_ns": frame["start"][0],
                                   "open_wall_elapsed_ns": elapsed,
                                   "open_cpu_elapsed_ns": (now[1] - frame["start"][1])
                                       if owner is threading.current_thread() and now is not None and now[1] >= frame["start"][1] else None})
                threads.append({"ident": thread["ident"], "native_id": thread["native_id"],
                    "open_frames": frames})
            result = {"integrity_valid": not self.errors, "errors": list(self.errors),
                "closed_phase_totals": {name: dict(value) for name, value in self.totals.items()},
                "threads": threads, "open_frame_count": sum(len(row["open_frames"]) for row in threads),
                "semantics": "calls/returns/raises describe wrapper attempts/outcomes; original_entered is separate. Closed totals aggregate independently timed thread invocations. Same-thread direct children only subtract for self wall/threadCPU; recursion counts invocations. Inclusive sums overlap, not a wall partition. No per-thread closed matrix. Open elapsed is historical at capture, not completion/liveness at closure; cross-thread openCPU is null."}
            if len(json.dumps(result).encode()) > 60000:
                self._error("phase snapshot size bound")
                return {"integrity_valid": False, "errors": list(self.errors),
                        "open_frame_count": result["open_frame_count"],
                        "detail_omitted": "phase snapshot size bound"}
            return result
