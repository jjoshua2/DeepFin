"""UNRUN test-owned guard fault child; no actual model/guard/runtime imports."""
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
import threading
sys.path.insert(0, str(Path(__file__).resolve().parent))
from bounded_phase_timer_v1 import PhaseBinding
from targeted_diagnostics_v5 import TargetedDiagnostics


class Pool:
    def __init__(self, *, commit, make_stepper): self.commit, self.make_stepper = commit, make_stepper
class Checkpoint:
    def record_game(self, attempt, game_id, receipt): return True
class Evaluator:
    def execute(self, prepared): return prepared
class Guard:
    def __init__(self): self.owner = threading.get_ident(); self.calls = 0
    def check(self):
        assert threading.get_ident() == self.owner
        self.calls += 1
        raw = trace.last_durable_checkpoint.read_bytes()
        snapshot = json.loads(raw)
        frames = [frame for row in snapshot["phase_timing"]["threads"] for frame in row["open_frames"]
                  if frame["phase"] == "outer_guard"]
        assert self.calls == 1 and frames and frames[0]["original_entered"] is False
        print(json.dumps(dict(durable_snapshot=str(trace.last_durable_checkpoint),
            sha256=hashlib.sha256(raw).hexdigest(), pid=os.getpid())), flush=True)
        while True: signal.pause()


trace = TargetedDiagnostics(Pool, Checkpoint, Evaluator, Path(sys.argv[1]),
    expected_origins={key: __file__ for key in ("pool", "checkpoint", "evaluator")}, quiescent=lambda: False,
    phase_bindings=(PhaseBinding(Guard, "check", "outer_guard"),),
    phase_source_pins={str(Path(__file__).resolve()): hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
with trace:
    trace._next_checkpoint = 0  # Test-only due cadence; no periodic guarantee claimed.
    Guard().check()
