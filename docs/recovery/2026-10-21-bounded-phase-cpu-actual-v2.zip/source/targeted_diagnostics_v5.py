"""UNRUN V5 scoped bounded phase diagnostics; no new threads, guards or scheduler."""
from functools import wraps
import hashlib
import inspect
import stat
from pathlib import Path
from bounded_phase_timer_v1 import PhaseTimer, PhaseBinding, PHASES
import json
import os
import threading
import time
from targeted_diagnostics_v2 import TargetedDiagnostics as _V2


class TargetedDiagnostics(_V2):
    CADENCE_SECONDS = 20
    MAX_DURING_ATTEMPTS = 17  # Entry + first pre + first post + at most14 cadence attempts.
    MAX_PAYLOAD_BYTES = 196608
    TOTAL_DIAGNOSTIC_BYTES = 4 << 20
    # Reserve worst-case final + deferred-final, each with a leftover hardlink.
    DURING_BYTE_BUDGET = TOTAL_DIAGNOSTIC_BYTES - 4 * MAX_PAYLOAD_BYTES

    def __init__(self, *args, phase_bindings=(), phase_source_pins=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.phases = PhaseTimer()
        self.phase_bindings = tuple(phase_bindings)
        self.phase_source_pins = dict(phase_source_pins or {})
        self._phase_patches = []
        self._event_waits = []
        self._event_wait_lock = threading.Lock()
        self._phase_restored = False
        self._checkpoint_lock = threading.Lock()
        self._next_checkpoint = 0.0
        self._during_attempts = 0
        self._during_charged_bytes = 0
        self.last_durable_checkpoint = None
        self.execute_attempts = self.execute_returns = self.execute_raises = 0
        self.execute_wall_ns = 0
        self.execute_calls_entered = self.execute_pre_refused = 0
        self._first_execute_claimed = False
        self._first_pre_durable = False
        self._first_pre_attempted = self._first_post_attempted = False
        self._cadence_attempts = 0

    def snapshot(self):
        result = super().snapshot()
        with self.lock:
            result.update(execute_attempts=self.execute_attempts,
                execute_returns=self.execute_returns, execute_raises=self.execute_raises,
                execute_inflight=self.execute_attempts - self.execute_returns - self.execute_raises - self.execute_pre_refused,
                execute_calls_entered=self.execute_calls_entered, execute_pre_refused=self.execute_pre_refused,
                execute_wall_ns=self.execute_wall_ns,
                timing_semantics="execute Python boundary wall time, not GPU kernel time; includes original validation/dispatch",
                during_snapshot_attempts=self._during_attempts,
                during_snapshot_conservative_charged_bytes=self._during_charged_bytes)
        result["phase_timing"] = self.phases.snapshot()
        result["phase_bindings"] = [{"class": b.target.__module__ + "." + b.target.__name__,
            "method": b.name, "phase": b.phase} for b in self.phase_bindings]
        result["phase_methods_restored"] = self._phase_restored and not any(
            "restore failed" in error or "changed externally" in error for error in self.errors)
        return result

    def checkpoint(self, **kwargs):
        return self.phases.call("diagnostics_io", self._checkpoint_impl, **kwargs)

    def _checkpoint_impl(self, *, entered=False, first_execute_pre=False, first_execute_post=False):
        """Best effort bounded create-only publication on an existing caller.

        No retries, blocking checkpoint lock, worker creation or final verdict.
        Existing event/timing locks must be released before this method is called.
        """
        if not self.active or not self._checkpoint_lock.acquire(blocking=False):
            return False
        try:
            now = time.monotonic()
            force = entered or first_execute_pre or first_execute_post
            if sum(map(int, (entered, first_execute_pre, first_execute_post))) > 1:
                return False
            if first_execute_pre and self._first_pre_attempted:
                return False
            if first_execute_post and self._first_post_attempted:
                return False
            if not force and self._cadence_attempts >= 14:
                return False
            if entered and self._during_attempts != 0:
                return False
            if self._during_attempts >= self.MAX_DURING_ATTEMPTS:
                return False
            if not force and now < self._next_checkpoint:
                return False
            self._first_pre_attempted |= first_execute_pre
            self._first_post_attempted |= first_execute_post
            if not force:
                self._cadence_attempts += 1
            slot = self._during_attempts
            self._during_attempts += 1
            self._next_checkpoint = now + self.CADENCE_SECONDS
            snapshot = self.snapshot()  # No event lock is held here.
            snapshot.update(snapshot_phase=("entered" if entered else "first_execute_pending" if first_execute_pre else
                                "first_execute_post" if first_execute_post else "during_work"),
                            state_at_publication_only_not_current_at_closure=True,
                            first_pending_is_not_inference_proof=True,
                            snapshot_monotonic_seconds=now, snapshot_pid=os.getpid(),
                            snapshot_thread=threading.get_ident(),
                            snapshot_thread_final=False, snapshot_slot=slot)
            raw = json.dumps(snapshot, sort_keys=True, allow_nan=False).encode()
            if len(raw) > self.MAX_PAYLOAD_BYTES:
                raise ValueError("during snapshot payload bound")
            charge = 2 * len(raw)
            if self._during_charged_bytes + charge > self.DURING_BYTE_BUDGET:
                self._during_attempts = self.MAX_DURING_ATTEMPTS
                with self.lock:
                    self._error("during snapshot byte budget exhausted")
                return False
            # Charge before filesystem operations even if an incomplete stage
            # survives. Stage+final may reference the same inode but count twice
            # in the existing output meter; never undercharge that possibility.
            self._during_charged_bytes += charge
            target = self.path.with_name(self.path.name + f".during-{slot:02d}.json")
            staging = target.with_name(target.name + ".partial")
            with staging.open("xb") as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.link(staging, target)
            staging.unlink()
            directory = os.open(self.path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
            self.last_durable_checkpoint = target
            return True
        except BaseException as error:
            with self.lock:
                self._error("during snapshot failed: " + type(error).__name__)
            return False
        finally:
            self._checkpoint_lock.release()

    def _event(self, *args, **kwargs):
        super()._event(*args, **kwargs)
        self.checkpoint()

    def _patch(self, cls, name, wrapper):
        if name == "execute":
            trace = self
            def timed(original):
                @wraps(original)
                def execute(instance, prepared):
                    if not trace.active:
                        return original(instance, prepared)
                    trace._batch(prepared)
                    phase_token = trace.phases.begin("execute")
                    with trace.lock:
                        trace.execute_attempts = min(2**63 - 1, trace.execute_attempts + 1)
                        first = not trace._first_execute_claimed
                        trace._first_execute_claimed = True
                    returned = False
                    started = None
                    try:
                        if first:
                            if not trace.checkpoint(first_execute_pre=True):
                                with trace.lock:
                                    trace.execute_pre_refused = min(2**63 - 1, trace.execute_pre_refused + 1)
                                raise RuntimeError("durable first execute pending snapshot required")
                            trace._first_pre_durable = True
                        else:
                            if not trace._first_pre_durable:
                                with trace.lock:
                                    trace.execute_pre_refused = min(2**63 - 1, trace.execute_pre_refused + 1)
                                raise RuntimeError("durable first execute pending snapshot required")
                            trace.checkpoint()
                        with trace.lock:
                            trace.execute_calls_entered = min(2**63 - 1, trace.execute_calls_entered + 1)
                        trace.phases.mark_entered(phase_token)
                        started = time.monotonic_ns()
                        result = original(instance, prepared)
                        returned = True
                        return result
                    finally:
                        # Observation cannot replace the original return/error.
                        try:
                            if started is not None:
                                elapsed = max(0, time.monotonic_ns() - started)
                                with trace.lock:
                                    ceiling = 2**63 - 1
                                    trace.execute_returns = min(ceiling, trace.execute_returns + int(returned))
                                    trace.execute_raises = min(ceiling, trace.execute_raises + int(not returned))
                                    trace.execute_wall_ns = min(ceiling, trace.execute_wall_ns + elapsed)
                        except BaseException as error:
                            trace._error("execute timing failed: " + type(error).__name__)
                        finally:
                            trace.phases.end(phase_token, returned)
                            if started is not None:
                                try:
                                    trace.checkpoint(first_execute_post=first)
                                except BaseException:
                                    trace._error("execute post checkpoint failed")
                return execute
            wrapper = timed
        return super()._patch(cls, name, wrapper)

    def __enter__(self):
        self._authenticate_bindings()
        result = super().__enter__()
        if not self.checkpoint(entered=True):
            # No target body has run. Do not admit a model call without a durable
            # entered witness; retain V2 cleanup/ownership behavior on failure.
            error = RuntimeError("durable entered diagnostic snapshot required")
            self.__exit__(type(error), error, None)
            raise error
        try:
            self._install_phase_bindings()
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return result

    @staticmethod
    def _function(descriptor):
        return descriptor.__func__ if isinstance(descriptor, (staticmethod, classmethod)) else descriptor

    def _authenticate_bindings(self):
        if len(self.phase_bindings) > 32 or len(self.phase_source_pins) > 16:
            raise ValueError("bounded exact phase manifest required")
        seen = set()
        origins = set()
        for binding in self.phase_bindings:
            if (not isinstance(binding, PhaseBinding) or not isinstance(binding.target, type)
                    or binding.phase not in (*PHASES, "control_request")
                    or binding.phase in ("execute", "diagnostics_io")
                    or binding.name == "transaction"
                    or (binding.target, binding.name) in seen):
                raise ValueError("closed unique phase binding required")
            seen.add((binding.target, binding.name))
            function = self._function(binding.target.__dict__[binding.name])
            if binding.phase == "runner_wait" and binding.name != "__init__":
                raise ValueError("runner_wait binds exact runner initializer only")
            if binding.phase == "control_request" and binding.name != "__call__":
                raise ValueError("control_request binds actual callback __call__ only")
            chain = set()
            while True:
                if id(function) in chain:
                    raise ValueError("cyclic wrapped callable")
                chain.add(id(function))
                origins.add(str(Path(function.__code__.co_filename).resolve()))
                if not hasattr(function, "__wrapped__"):
                    break
                function = function.__wrapped__
        if not origins <= set(self.phase_source_pins):
            raise ValueError("actual callable sources must belong to closed support pin roster")
        for name, expected in self.phase_source_pins.items():
            path = Path(name)
            if (not path.is_absolute() or path.resolve() != path or type(expected) is not str
                    or len(expected) != 64 or any(c not in "0123456789abcdef" for c in expected)):
                raise ValueError("exact phase source pin required")
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            try:
                before = os.fstat(fd)
                if not stat.S_ISREG(before.st_mode) or before.st_size > 1 << 20:
                    raise ValueError("bounded regular phase source")
                raw = os.read(fd, before.st_size)
                key = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
                if (len(raw) != before.st_size or key(before) != key(os.fstat(fd))
                        or key(before) != key(path.lstat()) or hashlib.sha256(raw).hexdigest() != expected):
                    raise ValueError("phase source changed")
            finally:
                os.close(fd)

    def _best_effort_checkpoint(self):
        try:
            self.checkpoint()
        except BaseException:
            self._error("phase boundary checkpoint failed")

    def _phase_call(self, phase, original, *args, **kwargs):
        # Existing caller only. Pending publication is before original entry and
        # cannot itself prove target execution. Original guard is never skipped.
        if not self.active:
            return original(*args, **kwargs)
        token = self.phases.begin(phase)
        self._best_effort_checkpoint()
        returned = False
        try:
            self.phases.mark_entered(token)
            result = original(*args, **kwargs)
            returned = True
            return result
        finally:
            self.phases.end(token, returned)
            self._best_effort_checkpoint()

    def _install_phase_bindings(self):
        trace = self
        for binding in self.phase_bindings:
            descriptor = binding.target.__dict__[binding.name]
            original = self._function(descriptor)
            def build(function, phase):
                @wraps(function)
                def wrapped(*args, **kwargs):
                    selected = phase
                    if phase == "control_request":
                        try:
                            owner = getattr(args[0], "_owner", None)
                        except BaseException:
                            owner = None
                        if type(owner) is not int:
                            with trace.phases.lock:
                                trace.phases._error("callback owner role unavailable")
                        selected = "control_owner_direct" if threading.get_ident() == owner else "control_offowner_wait"
                    return trace._phase_call(selected, function, *args, **kwargs)
                return wrapped
            if binding.phase == "runner_wait":
                @wraps(original)
                def replacement(instance, *args, _original=original, **kwargs):
                    result = _original(instance, *args, **kwargs)
                    try:
                        with trace._event_wait_lock:
                            event = instance._wake
                            if type(event) is not threading.Event or len(trace._event_waits) >= 16:
                                trace._error("owned runner event binding unavailable")
                                return result
                            previous = event.__dict__.get("wait")
                            had_attribute = "wait" in event.__dict__
                            actual_wait = event.wait
                            def wait(*values, **options):
                                return trace._phase_call("runner_wait", actual_wait, *values, **options)
                            trace._event_waits.append((event, had_attribute, previous, wait))
                            event.wait = wait
                    except BaseException:
                        trace._error("owned runner event instrumentation failed")
                    return result
            else:
                replacement = build(original, binding.phase)
            if isinstance(descriptor, staticmethod):
                replacement = staticmethod(replacement)
            elif isinstance(descriptor, classmethod):
                replacement = classmethod(replacement)
            setattr(binding.target, binding.name, replacement)
            self._phase_patches.append((binding.target, binding.name, descriptor, replacement))

    def _restore_quiescent(self):
        # V2 invokes this only after its explicit quiescence contract succeeds;
        # non-quiescent exceptions retain both method layers and wait observers.
        if not self._phase_restored:
            for event, had_attribute, previous, replacement in reversed(self._event_waits):
                try:
                    if event.__dict__.get("wait") is replacement:
                        if had_attribute:
                            event.wait = previous
                        else:
                            del event.wait
                    else:
                        self._error("owned event wait changed externally")
                except BaseException:
                    self._error("owned event wait restore failed")
            for target, name, original, replacement in reversed(self._phase_patches):
                try:
                    if target.__dict__[name] is replacement:
                        setattr(target, name, original)
                    else:
                        self._error("phase method changed externally")
                except BaseException:
                    self._error("phase method restore failed")
            self._phase_restored = True
        return super()._restore_quiescent()
