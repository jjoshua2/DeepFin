"""UNRUN stdlib controls; actual callback package supplied by pinned CPU capsule."""
import hashlib
import json
from pathlib import Path
import signal
import threading
import time
from types import SimpleNamespace
from unittest.mock import patch
from bounded_phase_timer_v1 import PhaseTimer, PhaseBinding
from targeted_diagnostics_v5 import TargetedDiagnostics

OVERHEAD_REPORT = []


class Pool:
    def __init__(self, *, commit, make_stepper):
        self.commit, self.make_stepper = commit, make_stepper


class Checkpoint:
    def begin(self): return "begin"
    def record_game(self, attempt, game_id, receipt): return True
    def finish(self): return "finish"
    def close(self): return "close"


class Evaluator:
    calls = 0
    def execute(self, prepared):
        Evaluator.calls += 1
        return prepared


class Guard:
    def __init__(self):
        self.owner, self.calls, self.error = threading.get_ident(), 0, None
    def check(self):
        assert threading.get_ident() == self.owner
        self.calls += 1
        if self.error is not None: raise self.error
        return self


class Native:
    @staticmethod
    def prepare(value): return value
    @classmethod
    def apply(cls, value): return cls, value


class Runner:
    def __init__(self): self._wake = threading.Event()


def pin(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def trace_at(root, bindings=(), extra_pins=None, quiescent=lambda: True):
    root.mkdir()
    pins = {str(Path(__file__).resolve()): pin(__file__)} if bindings else {}
    pins.update(extra_pins or {})
    return TargetedDiagnostics(Pool, Checkpoint, Evaluator, root / "trace.json",
        expected_origins={key: __file__ for key in ("pool", "checkpoint", "evaluator")},
        quiescent=quiescent, phase_bindings=bindings, phase_source_pins=pins)


def run_source_controls(case_root):
    results = []
    clock = [0, 0]
    timer = PhaseTimer(wall_ns=lambda: clock[0], cpu_ns=lambda: clock[1])
    def inner(): clock[0] += 20; clock[1] += 10
    def outer():
        clock[0] += 10; clock[1] += 5
        timer.call("native_prepare", inner)
        clock[0] += 70; clock[1] += 35
    timer.call("native_prepare", outer)
    row = timer.snapshot()["closed_phase_totals"]["native_prepare"]
    assert (row["calls"], row["original_entered"], row["returns"]) == (2, 2, 2)
    assert (row["wall_inclusive_ns"], row["wall_self_ns"]) == (120, 100)
    assert (row["cpu_inclusive_ns"], row["cpu_self_ns"]) == (60, 50)
    results.append("nested_recursion_wall_and_thread_cpu_exact")

    wall, cpu = [0], threading.local()
    cpu.value = 0
    timer = PhaseTimer(wall_ns=lambda: wall[0], cpu_ns=lambda: getattr(cpu, "value", 0))
    main = timer.begin("driver_advance"); timer.mark_entered(main)
    entered, release = threading.Event(), threading.Event()
    def concurrent():
        wall[0], cpu.value = 10, 0
        token = timer.begin("control_offowner_wait"); timer.mark_entered(token)
        entered.set()
        assert release.wait(2)
        wall[0], cpu.value = 30, 5
        timer.end(token, True)
    thread = threading.Thread(target=concurrent)
    thread.start()
    try:
        assert entered.wait(2)
        snap = timer.snapshot()
        remote = next(row for row in snap["threads"] if row["ident"] == thread.ident)
        assert remote["open_frames"][0]["open_cpu_elapsed_ns"] is None
    finally:
        release.set(); thread.join(2)
    assert not thread.is_alive()
    wall[0], cpu.value = 50, 10
    timer.end(main, True)
    totals = timer.snapshot()["closed_phase_totals"]
    assert totals["driver_advance"]["wall_self_ns"] == 50
    assert totals["driver_advance"]["cpu_self_ns"] == 10
    assert totals["control_offowner_wait"]["wall_inclusive_ns"] == 20
    assert totals["control_offowner_wait"]["cpu_inclusive_ns"] == 5
    results.append("concurrent_overlap_never_cross_thread_subtracted")

    primary = ValueError("target identity")
    timer = PhaseTimer(wall_ns=lambda: -1, cpu_ns=lambda: 0)
    def fail(): raise primary
    try: timer.call("checkpoint", fail)
    except ValueError as caught: assert caught is primary
    else: raise AssertionError("target exception lost")
    assert not timer.snapshot()["integrity_valid"]
    timer = PhaseTimer(wall_ns=lambda: 1, cpu_ns=lambda: 1)
    calls = [0]
    def recurse(depth):
        calls[0] += 1
        if depth: return timer.call("native_prepare", recurse, depth - 1)
        return primary
    assert timer.call("native_prepare", recurse, 20) is primary and calls == [21]
    assert timer.snapshot()["open_frame_count"] == 0
    assert not timer.snapshot()["integrity_valid"]
    results.append("clock_and_depth_failures_preserve_target_calls_errors")

    bindings = (PhaseBinding(Guard, "check", "outer_guard"),
        PhaseBinding(Native, "prepare", "native_prepare"), PhaseBinding(Native, "apply", "native_apply"),
        *(PhaseBinding(Checkpoint, name, "checkpoint") for name in ("begin", "record_game", "finish", "close")),
        PhaseBinding(Runner, "__init__", "runner_wait"))
    descriptors = {(b.target, b.name): b.target.__dict__[b.name] for b in bindings}
    trace = trace_at(case_root / "descriptors", bindings)
    guard = Guard()
    with trace:
        assert guard.check() is guard and guard.calls == 1
        value = object()
        assert Native.prepare(value) is value and Native.apply(value) == (Native, value)
        receipt = {"sha256": "a" * 64}
        pool = Pool(commit=lambda game: receipt, make_stepper=lambda game, rng: object())
        pool.commit(SimpleNamespace(slot_id=0))
        checkpoint = Checkpoint()
        assert checkpoint.begin() == "begin" and checkpoint.record_game(0, 0, receipt) is True
        assert checkpoint.finish() == "finish" and checkpoint.close() == "close"
        runner = Runner(); event = runner._wake
        assert runner._wake is event and runner._wake.wait(0) is False
        saved = trace.phases.snapshot()["closed_phase_totals"]
        assert saved["checkpoint"]["original_entered"] == 4
        assert saved["runner_wait"]["original_entered"] == 1
    assert all(target.__dict__[name] is descriptor for (target, name), descriptor in descriptors.items())
    assert "wait" not in event.__dict__ and runner._wake is event
    results.append("guard_checkpoint_descriptors_and_owned_wait_restore")

    from chess_anti_engine.staged_execution import OwnerThreadCallbacks
    import chess_anti_engine.staged_execution as staged
    bindings = (PhaseBinding(Guard, "check", "outer_guard"),
        PhaseBinding(OwnerThreadCallbacks, "__call__", "control_request"),
        PhaseBinding(OwnerThreadCallbacks, "service", "control_service"),
        PhaseBinding(OwnerThreadCallbacks, "_invoke", "control_invoke"))
    trace = trace_at(case_root / "actual-callback", bindings,
        {str(Path(staged.__file__).resolve()): pin(staged.__file__)})
    guard = Guard()
    with trace:
        for failure in (None, primary):
            guard.error = failure
            callbacks = OwnerThreadCallbacks(guard.check, capacity=1, timeout=2, deadline=time.monotonic() + 3)
            received = []
            def requester():
                try: received.append(callbacks())
                except BaseException as error: received.append(error)
            thread = threading.Thread(target=requester); thread.start()
            try:
                deadline = time.monotonic() + 2
                while True:
                    with callbacks._lock: pending = bool(callbacks._pending)
                    if pending: break
                    assert time.monotonic() < deadline
                    time.sleep(0.001)
                callbacks.service()
            finally:
                thread.join(3)
            assert not thread.is_alive() and received == [failure]
        guard.error = None
        callbacks = OwnerThreadCallbacks(guard.check, capacity=1, timeout=2, deadline=time.monotonic() + 3)
        callbacks()
        assert guard.calls == 3
        saved = trace.phases.snapshot()["closed_phase_totals"]
        assert saved["control_offowner_wait"]["original_entered"] == 2
        assert saved["control_owner_direct"]["original_entered"] == 1
    results.append("actual_owner_callbacks_guard_once_affinity_primary_error")

    quiet = [False]
    trace = trace_at(case_root / "retain", (PhaseBinding(Guard, "check", "outer_guard"),),
                     quiescent=lambda: quiet[0])
    original = Guard.__dict__["check"]
    with trace: pass
    assert trace.ownership_retained and Guard.__dict__["check"] is not original
    assert not trace.finalize_after_quiescence()
    quiet[0] = True
    assert trace.finalize_after_quiescence() and Guard.__dict__["check"] is original
    results.append("phase_ownership_retained_until_quiescent")

    trace = trace_at(case_root / "first-durable")
    calls = Evaluator.calls
    with trace:
        with patch("targeted_diagnostics_v5.os.link", side_effect=OSError("mandatory pre")):
            try: Evaluator().execute(SimpleNamespace(inference=SimpleNamespace(feed=SimpleNamespace(shape=(32,)))))
            except RuntimeError: pass
            else: raise AssertionError("first mandatory publication bypassed")
        assert Evaluator.calls == calls
    trace = trace_at(case_root / "phase-pending", (PhaseBinding(Guard, "check", "outer_guard"),))
    with trace:
        trace._next_checkpoint = 0  # Make this isolated test's cadence explicitly due.
        guard = Guard(); assert guard.check() is guard
        snapshot = json.loads(trace.last_durable_checkpoint.read_text())
        pending = [frame for row in snapshot["phase_timing"]["threads"] for frame in row["open_frames"]
                   if frame["phase"] == "outer_guard"]
        assert pending and pending[0]["original_entered"] is False
        assert guard.calls == 1
    results.append("mandatory_execute_gate_and_due_pending_phase_snapshot")

    trace = trace_at(case_root / "bad-pin", (PhaseBinding(Guard, "check", "outer_guard"),))
    trace.phase_source_pins[str(Path(__file__).resolve())] = "0" * 64
    original = Guard.__dict__["check"]
    try: trace.__enter__()
    except ValueError: pass
    else: raise AssertionError("wrong phase source accepted")
    assert Guard.__dict__["check"] is original
    results.append("phase_source_authentication_before_patch")

    OVERHEAD_REPORT.clear()
    timer = PhaseTimer()
    count = [0]
    def pure(): count[0] += 1; return 7
    for _ in range(3):
        wall, cpu = time.monotonic_ns(), time.process_time_ns()
        for _index in range(2000): assert pure() == 7
        direct_wall, direct_cpu = time.monotonic_ns() - wall, time.process_time_ns() - cpu
        wall, cpu = time.monotonic_ns(), time.process_time_ns()
        for _index in range(2000): assert timer.call("native_prepare", pure) == 7
        wrapped_wall, wrapped_cpu = time.monotonic_ns() - wall, time.process_time_ns() - cpu
        OVERHEAD_REPORT.append(dict(arm="timer_core", calls_per_arm=2000, direct_wall_ns=direct_wall, direct_cpu_ns=direct_cpu,
            wrapped_wall_ns=wrapped_wall, wrapped_cpu_ns=wrapped_cpu,
            observed_added_wall_ns_per_call=(wrapped_wall-direct_wall)/2000,
            observed_added_cpu_ns_per_call=(wrapped_cpu-direct_cpu)/2000))
    assert count == [12000] and timer.snapshot()["closed_phase_totals"]["native_prepare"]["calls"] == 6000
    trace = trace_at(case_root / "overhead-phase", (PhaseBinding(Guard, "check", "outer_guard"),))
    guard = Guard()
    original_guard = Guard.__dict__["check"]
    with trace:
        # Cadence-noop only: report timer + both real checkpoint-path checks.
        trace._next_checkpoint = float("inf")
        for _round in range(3):
            wall, cpu = time.monotonic_ns(), time.process_time_ns()
            for _index in range(2000): assert original_guard(guard) is guard
            direct_wall, direct_cpu = time.monotonic_ns()-wall, time.process_time_ns()-cpu
            wall, cpu = time.monotonic_ns(), time.process_time_ns()
            for _index in range(2000): assert guard.check() is guard
            wrapped_wall, wrapped_cpu = time.monotonic_ns()-wall, time.process_time_ns()-cpu
            OVERHEAD_REPORT.append(dict(arm="phase_wrapper_cadence_noop", calls_per_arm=2000,
                direct_wall_ns=direct_wall, direct_cpu_ns=direct_cpu,
                wrapped_wall_ns=wrapped_wall, wrapped_cpu_ns=wrapped_cpu,
                observed_added_wall_ns_per_call=(wrapped_wall-direct_wall)/2000,
                observed_added_cpu_ns_per_call=(wrapped_cpu-direct_cpu)/2000))
        assert guard.calls == 12000
        assert trace.phases.snapshot()["closed_phase_totals"]["outer_guard"]["calls"] == 6000
    results.append("fixed_pure_call_overhead_report_no_noise_threshold")
    return results


def run_termination_controls(case_root, run_owned_termination):
    results = []
    child = Path(__file__).with_name("phase_termination_child_v1.py")
    for signum in (signal.SIGTERM, signal.SIGKILL):
        root = case_root / ("sigterm" if signum == signal.SIGTERM else "sigkill"); root.mkdir()
        final = root / "trace.json"
        result = run_owned_termination(child, final, int(signum))
        assert result["returncode"] == -int(signum) and result["kernel_ECHILD"] is True
        expected = final.with_name(final.name + ".during-01.json")
        assert result["ack"]["durable_snapshot"] == str(expected)
        raw = expected.read_bytes(); assert hashlib.sha256(raw).hexdigest() == result["ack"]["sha256"]
        saved = json.loads(raw)
        frames = [frame for row in saved["phase_timing"]["threads"] for frame in row["open_frames"]
                  if frame["phase"] == "outer_guard"]
        assert frames and frames[0]["original_entered"] is False
        assert saved["phase_timing"]["closed_phase_totals"]["outer_guard"]["original_entered"] == 0
        assert saved["status"] == "PARTIAL_DIAGNOSTIC_ONLY" and not final.exists()
        results.append("owned_" + ("SIGTERM" if signum == signal.SIGTERM else "SIGKILL") + "_inside_guard_after_pending_phase_ack")
    return results
