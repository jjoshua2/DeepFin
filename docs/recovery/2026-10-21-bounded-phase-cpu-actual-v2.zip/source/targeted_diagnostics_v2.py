"""UNRUN V2: explicit caller quiescence contract retains live instrumentation.

Compose with the frozen V1 helper in this directory; no scheduler or admission.
"""
from targeted_diagnostics_v1 import TargetedDiagnostics as _V1


class TargetedDiagnostics(_V1):
    def __init__(self, *args, quiescent, **kwargs):
        if not callable(quiescent):
            raise TypeError("explicit caller quiescence contract required")
        super().__init__(*args, **kwargs)
        self.quiescent = quiescent
        self.ownership_retained = False
        self.restored = False

    def _is_quiescent(self):
        try:
            # Fail closed for None, truthy objects and callback failure.
            return self.quiescent() is True
        except BaseException as error:
            self._error("quiescence check failed: " + type(error).__name__)
            return False

    def snapshot(self):
        result = super().snapshot()
        methods_restored = bool(self.patches) and all(
            cls.__dict__[name] is original for cls, name, original, _ in self.patches)
        callbacks_restored = all(instance.commit is commit and instance.make_stepper is make
            for instance, commit, make, _, _ in self.pool_callbacks)
        result.update(ownership_retained=self.ownership_retained,
                      methods_restored=methods_restored and callbacks_restored)
        return result

    def __exit__(self, *_exc):
        if not self._is_quiescent():
            self.ownership_retained = True
            self._error("callers non-quiescent; wrapper ownership retained")
            self.persist()
            return False
        self._restore_quiescent()
        return False

    def _restore_quiescent(self):
        if self.restored:
            return
        if self.ownership_retained:
            # Preserve the exit-time partial snapshot; publish a distinct final
            # diagnostic observation after the caller actually joins/reaps.
            self.path = self.path.with_name(self.path.name + ".quiescent.json")
        self.ownership_retained = False
        # V1 records all restoration conflicts as errors; status stays PARTIAL.
        super().__exit__(None, None, None)
        self.restored = not any("restore failed" in error or "changed externally" in error
                                for error in self.errors)

    def finalize_after_quiescence(self):
        """Caller owns joins/custody/reaping; this method performs none of them."""
        if not self._is_quiescent():
            return False
        self._restore_quiescent()
        return self.restored
