"""UNRUN scoped diagnostics; no admission, scheduler, target import or global profiler."""
from __future__ import annotations

from functools import wraps
import json
import os
from pathlib import Path
import threading
import time


class TargetedDiagnostics:
    """Bind only before a single private roster; exit only after its threads join.

    Caller supplies already verified runtime classes and an exclusive private
    snapshot path. This helper neither authorizes nor calls the roster itself.
    All production guards and callback results/exceptions remain in force.
    """
    def __init__(self, pool_class, checkpoint_class, evaluator_class, snapshot_path, *, expected_origins):
        self.classes = (pool_class, checkpoint_class, evaluator_class)
        self.path = Path(snapshot_path)
        self.expected_origins = dict(expected_origins)
        self.owner = threading.get_ident()
        self.lock = threading.Lock()
        self.events = []
        self.errors = []
        self.histogram = [0] * 65
        self.writes = {}
        self.acks = set()
        self.actors = 0
        self.dropped = 0
        self.patches = []
        self.pool_callbacks = []
        self.active = False

    def _error(self, message):
        if len(self.errors) < 8:
            self.errors.append(str(message)[:256])

    def _event(self, kind, game, sha=None):
        # Called only at targeted boundaries. Never replace an application error.
        try:
            if not self.active:
                return
            with self.lock:
                if type(game) is not int or not 0 <= game < 128:
                    self._error("game outside finite unit")
                    return
                tid = threading.get_ident()
                if kind == "writer":
                    if game in self.writes or type(sha) is not str or len(sha) != 64:
                        self._error("duplicate writer or invalid digest")
                    else:
                        self.writes[game] = sha
                elif kind == "ack":
                    if tid != self.owner or game in self.acks or self.writes.get(game) != sha:
                        self._error("writer-before-owner-ACK identity/order failed")
                    else:
                        self.acks.add(game)
                elif kind == "actor":
                    if tid != self.owner or game != self.actors:
                        self._error("owner sequential actor admission failed")
                    if game >= 64 and len(self.acks) < game - 63:
                        self._error("actor admitted before durable owner ACK")
                    self.actors = min(129, self.actors + 1)
                if len(self.events) < 512:
                    self.events.append(dict(kind=kind, game=game, sha256=sha,
                        sequence=len(self.events), thread=tid, monotonic_ns=time.monotonic_ns()))
                else:
                    self.dropped = min(2**63 - 1, self.dropped + 1)
                    self._error("trace overflow")
        except BaseException as error:
            with self.lock:
                self._error(type(error).__name__)

    def _batch(self, prepared):
        try:
            n = prepared.inference.feed.shape[0]
            with self.lock:
                if type(n) is not int or not 1 <= n <= 64:
                    self._error("execute batch outside finite bound")
                else:
                    self.histogram[n] = min(2**63 - 1, self.histogram[n] + 1)
        except BaseException as error:
            with self.lock:
                self._error("batch shape unavailable: " + type(error).__name__)

    def snapshot(self):
        with self.lock:
            return dict(status="PARTIAL_DIAGNOSTIC_ONLY", events=list(self.events),
                errors=list(self.errors), dropped=self.dropped,
                actors=self.actors, durable_writes=len(self.writes), owner_acks=len(self.acks),
                execute_attempt_batch_histogram={str(n): v for n, v in enumerate(self.histogram) if v},
                training_credit=0, native_admission=False, speed_claim=False)

    def persist(self):
        """Bounded best effort; failure is recorded and cannot mask primary error.

        Call also from the root's existing deadline/cleanup path if termination
        bypasses Python finally. No Python helper can persist after SIGKILL.
        """
        try:
            payload = json.dumps(self.snapshot(), sort_keys=True, allow_nan=False).encode()
            if len(payload) > 196608:
                raise ValueError("snapshot byte bound")
            # Exclusive file: caller must supply a new output path for each scope.
            temporary = self.path.with_name(self.path.name + ".partial")
            with temporary.open("xb") as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
            os.link(temporary, self.path)  # Atomic create-only publication; never replace.
            temporary.unlink()
        except BaseException as error:
            with self.lock:
                self._error("persist failed: " + type(error).__name__)

    def _patch(self, cls, name, wrapper):
        original = cls.__dict__[name]
        replacement = wrapper(original)
        setattr(cls, name, replacement)
        self.patches.append((cls, name, original, replacement))

    def __enter__(self):
        if self.active or self.patches:
            raise RuntimeError("single-use diagnostic scope")
        pool, checkpoint, evaluator = self.classes
        for key, cls, name in (("pool", pool, "__init__"),
                ("checkpoint", checkpoint, "record_game"),
                ("evaluator", evaluator, "execute")):
            method = cls.__dict__[name]
            if Path(method.__code__.co_filename).resolve() != Path(self.expected_origins[key]).resolve():
                raise ValueError("unbound runtime callable origin: " + key)
        self.active = True
        trace = self
        def pool_wrapper(original):
            @wraps(original)
            def initialize(instance, **kwargs):
                commit, make = kwargs["commit"], kwargs["make_stepper"]
                @wraps(commit)
                def committed(game):
                    receipt = commit(game)
                    try:
                        trace._event("writer", game.slot_id, receipt["sha256"])
                    except BaseException as error:
                        trace._error("writer observation failed: " + type(error).__name__)
                    return receipt
                @wraps(make)
                def admitted(game, rng):
                    stepper = make(game, rng)
                    trace._event("actor", game)
                    return stepper
                result = original(instance, **{**kwargs, "commit": committed, "make_stepper": admitted})
                if len(trace.pool_callbacks) < 128:
                    trace.pool_callbacks.append((instance, commit, make, committed, admitted))
                else:
                    trace._error("pool binding bound exceeded")
                return result
            return initialize
        def ack_wrapper(original):
            @wraps(original)
            def recorded(instance, attempt, game_id, receipt):
                result = original(instance, attempt, game_id, receipt)
                if result is True:
                    try:
                        trace._event("ack", game_id, receipt["sha256"])
                    except BaseException as error:
                        trace._error("ACK observation failed: " + type(error).__name__)
                return result
            return recorded
        def execute_wrapper(original):
            @wraps(original)
            def execute(instance, prepared):
                if trace.active:
                    trace._batch(prepared)
                return original(instance, prepared)
            return execute
        try:
            self._patch(pool, "__init__", pool_wrapper)
            self._patch(checkpoint, "record_game", ack_wrapper)
            self._patch(evaluator, "execute", execute_wrapper)
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *_exc):
        self.active = False
        for instance, commit, make, committed, admitted in self.pool_callbacks:
            try:
                if instance.commit is committed:
                    instance.commit = commit
                else:
                    self._error("commit callback changed externally")
                if instance.make_stepper is admitted:
                    instance.make_stepper = make
                else:
                    self._error("actor callback changed externally")
            except BaseException as error:
                self._error("callback restore failed: " + type(error).__name__)
        for cls, name, original, replacement in reversed(self.patches):
            try:
                if cls.__dict__[name] is replacement:
                    setattr(cls, name, original)
                else:
                    self._error("method changed externally: " + name)
            except BaseException as error:
                self._error("restore failed: " + type(error).__name__)
        self.persist()
        return False


