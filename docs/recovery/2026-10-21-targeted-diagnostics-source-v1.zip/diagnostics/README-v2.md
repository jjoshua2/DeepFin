# Targeted diagnostics V2 — UNRUN source increment

V1 files remain frozen. V2 subclasses the adjacent V1 helper to address the
actual `run_owned_roster` ProducerJoinTimeout path: a raised exception does not
prove background callers have stopped. Caller must supply `quiescent`, returning
exactly True only after all relevant producer/writer/dispatcher/owner callers
have joined, or custody-owning supervision has established process reaping.
Callback failure, None and truthy non-bools fail closed. The helper never joins,
kills, reaps, releases custody or changes the existing timeout behavior.

When scope exits non-quiescent it preserves active wrappers, original callback
references and bounded in-memory telemetry. It publishes an exit-time snapshot
explicitly marked `ownership_retained: true`, `methods_restored: false`, always
`PARTIAL_DIAGNOSTIC_ONLY`. This is not a thread-final observation. The original
exception propagates unchanged. The root must retain the helper object and
existing custody. Subsequent targeted calls remain observed with V1 bounds.

Only `finalize_after_quiescence()` with a successful True contract restores
methods/callbacks and writes a separate `.quiescent.json` diagnostic snapshot.
The earlier partial is preserved. False returns without restoration. Process
reaping ends process-local patches; this helper cannot persist after hard kill.
The explicit caller contract must be independently reviewed against actual
retained run_owned_roster/ProducerJoinTimeout cleanup, not guessed from a caught
exception type. Root must bind source closure including unchanged V1.

New source-only controls (none executed/imported/AST-checked):

- `test_targeted_diagnostics_v2.py::test_live_thread_exit_retains_until_join`
  owns a real test thread, observes retained patches after exception, joins it,
  then verifies restoration and both snapshots while preserving primary error.
- `test_targeted_diagnostics_v2.py::test_actual_worker_factory_retained_checkpoint[positive]`
- `test_targeted_diagnostics_v2.py::test_actual_worker_factory_retained_checkpoint[order_negative]`
  call actual worker `_make_pooled_unit`, its nested commit including atomic
  checkpoint JSON/fsync, and retained Checkpoint.record_game with real SQLite
  transaction. Test uses synthetic receipt/game, in-memory DB, dummy stepper,
  external writer sentinel and no model/session. Wrong order calls the actual
  DB ACK before commit. These are integration boundary controls, not raw payload
  reconciliation or full scheduler/game correctness proof. Actual retained
  checkpoint module must be present on root's bound import path; no substitute
  module or skipped test is accepted as a passing integration gate.

Only apply_patch source edits were performed for V2. No commands, tests, Python
imports, GPU work, probes, preparation or new grants were run. V2 hashes and a
combined source patch are deliberately left to root's independently authorized
native evidence packaging; the concrete source increment is these three new
files. This is not an executable adapter or evidence of passing CPU gates.
