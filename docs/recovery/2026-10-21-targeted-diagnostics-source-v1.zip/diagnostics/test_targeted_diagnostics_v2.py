"""UNRUN source controls. Root alone may run bounded CPU gates."""
import json
import sqlite3
import threading
from types import SimpleNamespace
import pytest
from targeted_diagnostics_v2 import TargetedDiagnostics
from test_targeted_diagnostics_v1 import Pool, Checkpoint, Evaluator


def test_live_thread_exit_retains_until_join(tmp_path):
    entered, release = threading.Event(), threading.Event()
    def background():
        entered.set()
        release.wait(5)
    worker = threading.Thread(target=background)
    worker.start()
    assert entered.wait(1)
    originals = (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
    trace = TargetedDiagnostics(Pool, Checkpoint, Evaluator, tmp_path / "partial.json",
        expected_origins={key: __import__("test_targeted_diagnostics_v1").__file__
                          for key in ("pool", "checkpoint", "evaluator")},
        quiescent=lambda: not worker.is_alive())
    primary = TimeoutError("join timeout retained by real caller")
    try:
        with pytest.raises(TimeoutError) as caught:
            with trace:
                raise primary
        assert caught.value is primary
        assert trace.active and trace.ownership_retained
        assert originals != (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
        partial = json.loads(trace.path.read_text())
        assert partial["ownership_retained"] and not partial["methods_restored"]
        assert trace.finalize_after_quiescence() is False
    finally:
        release.set()
        worker.join(2)
        assert not worker.is_alive()
        assert trace.finalize_after_quiescence() is True
    assert originals == (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
    final = json.loads(trace.path.read_text())
    assert final["methods_restored"] and not final["ownership_retained"]
    assert final["status"] == "PARTIAL_DIAGNOSTIC_ONLY"


@pytest.mark.parametrize("wrong_order", [False, True], ids=["positive", "order_negative"])
def test_actual_worker_factory_retained_checkpoint(tmp_path, monkeypatch, wrong_order):
    # Exact retained module must be present on root's independently bound source
    # path; never import a substitute checkpoint implementation for this control.
    from scripts import bt4_root_policy_worker as worker
    from scripts import bt4_longblock_checkpoint_v2 as retained
    from scripts.bt4_generation_evaluator import BT4OnnxEvaluator
    checkpoint_class = retained.Checkpoint
    checkpoint = checkpoint_class.__new__(checkpoint_class)
    checkpoint.binding = "b" * 64
    checkpoint.guard = lambda: None
    checkpoint.db = sqlite3.connect(":memory:", isolation_level=None)
    checkpoint.db.executescript(
        "CREATE TABLE attempts(id INTEGER PRIMARY KEY, unit INTEGER, state TEXT);"
        "INSERT INTO attempts VALUES(1,0,'RUNNING');"
        "CREATE TABLE games(unit INTEGER,game INTEGER,receipt TEXT,sha TEXT,PRIMARY KEY(unit,game));")
    games = tmp_path / "games"
    games.mkdir()
    (tmp_path / "launch.json").write_text("{}")
    receipt = dict(sha256="a" * 64, game_id=0, status="completed", rows=0,
                   binding_sha256=checkpoint.binding, path=str((games / "game_00000000.npz").resolve()))
    monkeypatch.setattr(worker, "reconcile_raw_game", lambda *args, **kwargs: dict(receipt))
    monkeypatch.setattr(worker, "BT4RootPolicyStepper", lambda *args, **kwargs: object())
    spec = SimpleNamespace(initial_fen="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        max_plies=400, syzygy_path="", model_sha256="c" * 64, out=tmp_path,
        games=128, parallel_games=64, seed=1, temperature=1.0)
    trace = TargetedDiagnostics(worker.BT4GamePool, checkpoint_class, BT4OnnxEvaluator,
        tmp_path / "diagnostic.json", quiescent=lambda: True,
        expected_origins={"pool": worker.BT4GamePool.__init__.__code__.co_filename,
                          "checkpoint": checkpoint_class.record_game.__code__.co_filename,
                          "evaluator": BT4OnnxEvaluator.execute.__code__.co_filename})
    try:
        with trace:
            pool = worker._make_pooled_unit(spec, object(), games, object(),
                max_writes=1, resume=False, writer=object())
            pool.make_stepper(0, None)
            if wrong_order:
                assert checkpoint.record_game(1, 0, receipt) is True
            committed = pool.commit(SimpleNamespace(slot_id=0))
            if not wrong_order:
                assert checkpoint.record_game(1, 0, committed) is True
            assert checkpoint.db.execute("SELECT COUNT(*) FROM games").fetchone() == (1,)
        if wrong_order:
            assert any("writer-before-owner" in error for error in trace.errors)
        else:
            assert not trace.errors
            assert [event["kind"] for event in trace.events] == ["actor", "writer", "ack"]
        assert trace.snapshot()["methods_restored"]
    finally:
        checkpoint.db.close()
