# V3 actual checkpoint binding — UNRUN

V1 and V2 remain unchanged and UNRUN. The retained checkpoint source is included
in runtime-v3's repo_sources roster; no missing-module execution failure occurred.
V3 directly binds the actual already-loaded `entry.Checkpoint` through the root
runner's `actual_checkpoint_class` fixture after exact identity, callable
source origin and source hash validation. It must not stage or rename a
historical checkpoint module. No fixture fallback or skip is permitted.

Helper source remains V2 and its frozen V1 dependency; no helper change is needed
because it already takes the supplied exact class. V3 test depends on V2 test for
the unchanged live-thread control, and V2 test imports V1 boundary doubles.
Normal pytest import of V2 test defines but does not run its superseded controls.
Select only these V3 node IDs in the root runner:

- `test_targeted_diagnostics_v3.py::test_live_thread_exit_retains_until_join`
- `test_targeted_diagnostics_v3.py::test_actual_worker_factory_retained_checkpoint[positive]`
- `test_targeted_diagnostics_v3.py::test_actual_worker_factory_retained_checkpoint[order_negative]`

The fixture is supplied by root's exact CPU runner pytest plugin or conftest,
using the existing actual entry loading interface. No new entry loading or
checkpoint implementation is embedded here. Five Python source files are needed:
V1 helper/test, V2 helper/test and V3 test. No tests/imports/commands were run.
Root runner author must confirm the fixture interface before execution and hash
these files in the independently reviewed bounded CPU proposal.
