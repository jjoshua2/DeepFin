"""UNRUN CPU controls. No model, GPU or runtime admission."""
import json
from pathlib import Path
from types import SimpleNamespace
import pytest
from targeted_diagnostics_v1 import TargetedDiagnostics


class Pool:
    def __init__(self, *, commit, make_stepper):
        self.commit, self.make_stepper = commit, make_stepper


class Checkpoint:
    def record_game(self, attempt, game_id, receipt):
        return True


class Evaluator:
    def execute(self, prepared):
        return prepared


def scope(tmp_path, pool=Pool):
    return TargetedDiagnostics(pool, Checkpoint, Evaluator, tmp_path / "partial.json",
        expected_origins={"pool": pool.__init__.__code__.co_filename,
            "checkpoint": __file__, "evaluator": __file__})


def test_callback_positive_and_batch(tmp_path):
    trace = scope(tmp_path)
    receipt = {"sha256": "a" * 64}
    with trace:
        p = Pool(commit=lambda game: receipt, make_stepper=lambda game, rng: object())
        for game in range(65):
            p.make_stepper(game, None)
            assert p.commit(SimpleNamespace(slot_id=game)) is receipt
            assert Checkpoint().record_game(0, game, receipt) is True
        prepared = SimpleNamespace(inference=SimpleNamespace(feed=SimpleNamespace(shape=(32,))))
        assert Evaluator().execute(prepared) is prepared
    saved = json.loads((tmp_path / "partial.json").read_text())
    assert saved["owner_acks"] == 65 and not saved["errors"]
    assert saved["execute_attempt_batch_histogram"] == {"32": 1}
    assert saved["status"] == "PARTIAL_DIAGNOSTIC_ONLY"


def test_order_negative(tmp_path):
    trace = scope(tmp_path)
    with trace:
        Checkpoint().record_game(0, 0, {"sha256": "a" * 64})
        trace._event("actor", 64)
    assert any("writer-before" in error for error in trace.errors)
    assert any("before durable" in error for error in trace.errors)


def test_exception_finally_restore_primary(tmp_path):
    original = (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
    trace = scope(tmp_path)
    primary = TimeoutError("existing deadline")
    with pytest.raises(TimeoutError) as caught:
        with trace:
            raise primary
    assert caught.value is primary
    assert original == (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
    assert (tmp_path / "partial.json").is_file()


def test_bounds_and_create_only(tmp_path):
    trace = scope(tmp_path)
    trace.path.write_text("sentinel")
    with trace:
        for _ in range(600):
            trace._event("writer", 0, "a" * 64)
    assert len(trace.events) == 512 and len(trace.errors) <= 8 and trace.dropped == 88
    assert trace.path.read_text() == "sentinel"


def test_no_global_profiler(tmp_path):
    import sys
    import threading
    before = (sys.getprofile(), threading.getprofile())
    with scope(tmp_path):
        assert before == (sys.getprofile(), threading.getprofile())
    assert before == (sys.getprofile(), threading.getprofile())


def test_wrong_origin_fails_before_patch(tmp_path):
    trace = scope(tmp_path)
    trace.expected_origins["checkpoint"] = str(tmp_path / "wrong.py")
    original = Pool.__init__
    with pytest.raises(ValueError, match="origin"):
        trace.__enter__()
    assert Pool.__init__ is original


def test_real_pool_constructor_binding(tmp_path):
    # Real canonical callback storage, no fake scheduler or worker execution.
    from scripts.shared_teacher_generation import BT4GamePool
    trace = scope(tmp_path, BT4GamePool)
    with trace:
        pool = BT4GamePool(games=128, capacity=64, seed=1, temperature=1.0,
            make_stepper=lambda game, rng: object(), dispatcher=object(),
            commit=lambda game: {"sha256": "a" * 64}, max_writes=1,
            writer=object(), acknowledge=lambda game, receipt: receipt)
        # Constructor uses canonical pool, but worker factory + DB ACK integration
        # remains a separately required gate with the actual retained checkpoint.
        assert pool is not None
