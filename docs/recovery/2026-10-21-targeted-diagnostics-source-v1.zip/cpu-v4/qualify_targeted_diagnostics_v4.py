"""SOURCE-ONLY ten-case diagnostic CPU proposal; root alone admits execution.

Seven unchanged helper controls plus three quiescence/actual worker-factory and
retained SQLite cases. No old startup regressions, model/session or GPU test.
"""
import hashlib
import importlib
import json
import os
from pathlib import Path
import resource
import stat
import sys
import threading
import time
import xml.etree.ElementTree as ET

ROOT = Path('/tmp/deepfin-pr1110-production-20261021-v1/runtime-v3')
REPORT = ROOT.parent / 'reports-targeted-diagnostics-v4'
CAPSULE = REPORT / 'capsule'
DEPS = Path('/home/josh/.local/lib/python3.10/site-packages')
PLAN = Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-targeted-diagnostics-cpu-v1/CPU-CAPSULE-PLAN-v4.json')
PLAN_SHA = '7c11c0aac023665a7dd531ce9cca83e6c9ac0431be33ecc0a226147f4b0d1c5f'
CLOSURE_SHA = '1fce66e0409ca24449d0ea6c897f9a0a5457d35fc0982e6ee9ee87a137168f12'
PYTHON_SHA = 'a2f33a6e006989270f4340528eb61f8f97366e00a5d1b602ac8672ea44fc56ae'
PYTEST_SHA = '7be7a1e2218dc59a19d1ad131e4abe21172a295087efc72898938248782e8766'
CHECKPOINT_SHA = '3e340183934fc06437979898b968d2555cf4931254daafa05c317680b75b9ae9'
CONFTEST_SHA = '0b5bb76a9b95d30c28ba60a1ea9ea8ad83158fd72774094a485e4f2821767413'
NODES = [
    'tests/test_targeted_diagnostics_v1.py::test_callback_positive_and_batch',
    'tests/test_targeted_diagnostics_v1.py::test_order_negative',
    'tests/test_targeted_diagnostics_v1.py::test_exception_finally_restore_primary',
    'tests/test_targeted_diagnostics_v1.py::test_bounds_and_create_only',
    'tests/test_targeted_diagnostics_v1.py::test_no_global_profiler',
    'tests/test_targeted_diagnostics_v1.py::test_wrong_origin_fails_before_patch',
    'tests/test_targeted_diagnostics_v1.py::test_real_pool_constructor_binding',
    'tests/test_targeted_diagnostics_v3.py::test_live_thread_exit_retains_until_join',
    'tests/test_targeted_diagnostics_v3.py::test_actual_worker_factory_retained_checkpoint[positive]',
    'tests/test_targeted_diagnostics_v3.py::test_actual_worker_factory_retained_checkpoint[order_negative]',
]
started = time.monotonic()
read_bytes = 0


def need(ok, why):
    if not ok:
        raise ValueError(why)


def raw_file(path, expected=None, cap=2 << 30, keep=False):
    global read_bytes
    path = Path(path)
    need(path.resolve() == path, 'canonical CPU input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    value, pieces, count = hashlib.sha256(), [], 0
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= cap, 'bounded regular CPU input')
        while True:
            part = os.read(fd, 1 << 20)
            if not part:
                break
            count += len(part)
            read_bytes += len(part)
            need(count <= cap and read_bytes <= 8 << 30, 'explicit hash/read budget')
            value.update(part)
            if keep:
                pieces.append(part)
        stamp = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
        need(count == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()), 'CPU input changed')
    finally:
        os.close(fd)
    need(expected is None or value.hexdigest() == expected, 'CPU source pin mismatch')
    return value.hexdigest(), b''.join(pieces)


def audit(event, args):
    if event in {'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn', 'socket.connect',
                 'socket.bind', 'fcntl.flock', 'fcntl.lockf', 'os.symlink'}:
        raise RuntimeError('diagnostic CPU forbids child/network/lease/link: ' + event)

    def owned(name, dir_fd=None):
        if isinstance(name, int):
            path = Path(os.readlink('/proc/self/fd/' + str(name)))
        elif isinstance(name, (str, bytes, os.PathLike)):
            path = Path(os.fsdecode(name))
            if not path.is_absolute():
                path = (Path(os.readlink('/proc/self/fd/' + str(dir_fd)))
                        if isinstance(dir_fd, int) and dir_fd >= 0 else Path.cwd()) / path
        else:
            return False
        return path.resolve(strict=False).is_relative_to(REPORT)

    if event == 'os.link':
        # persist() publishes only private report files atomically. No dirfd or
        # symlink aliases may turn this narrowly allowed publication external.
        need(len(args) == 4 and all(fd is None or fd == -1 for fd in args[2:]),
             'no dirfd-relative private link')
        for endpoint in args[:2]:
            need(isinstance(endpoint, (str, bytes, os.PathLike)), 'private link path')
            path = Path(os.fsdecode(endpoint))
            need(path.is_absolute() and path.resolve(strict=False) == path
                 and path.is_relative_to(REPORT), 'private canonical link endpoints')
        need(stat.S_ISREG(Path(os.fsdecode(args[0])).lstat().st_mode), 'private regular link source')
    if event == 'sqlite3.connect':
        need(args[0] == ':memory:' or owned(args[0]), 'SQLite outside private CPU report')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        name, mode, flags = os.fsdecode(args[0]), args[1], args[2]
        need(not name.endswith(('.onnx', '.pt', '.pth', '.safetensors')), 'no model payload reads')
        writing = ((isinstance(mode, str) and any(char in mode for char in 'wax+'))
                   or bool(isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)))
        if writing and not owned(name):
            null = Path('/dev/null').lstat()
            need(name == '/dev/null' and stat.S_ISCHR(null.st_mode)
                 and (os.major(null.st_rdev), os.minor(null.st_rdev)) == (1, 3), 'external CPU write')
    if event in {'os.remove', 'os.rename', 'os.mkdir', 'os.rmdir', 'os.chmod'}:
        pairs = ([(args[0], args[2]), (args[1], args[3])] if event == 'os.rename' else
                 [(args[0], args[2] if event in {'os.mkdir', 'os.chmod'} else args[1])])
        need(all(owned(name, dir_fd) for name, dir_fd in pairs), 'external CPU mutation')


for kind, ceiling in ((resource.RLIMIT_CPU, 60), (resource.RLIMIT_AS, 24 << 30)):
    soft, hard = resource.getrlimit(kind)
    resource.setrlimit(kind, (min(value for value in (soft, ceiling) if value >= 0),
                              min(value for value in (hard, ceiling) if value >= 0)))
need(sys.version_info[:2] == (3, 10) and sys.flags.isolated and sys.flags.no_site
     and sys.flags.dont_write_bytecode and sys.flags.optimize == 0, 'isolated nonoptimized CP310')
need(Path.cwd() == ROOT and ROOT.resolve() == ROOT, 'actual runtime-v3 CWD')
raw_file(sys.executable, PYTHON_SHA)
need(os.environ.get('CUDA_VISIBLE_DEVICES') == '' and os.environ.get('PYTEST_DISABLE_PLUGIN_AUTOLOAD') == '1'
     and sorted(os.sched_getaffinity(0)) == [29, 30], 'fixed CPU invocation')
need(Path('/proc/sys/kernel/random/boot_id').read_text().strip() == 'e34eff27-d1dc-49c0-bac2-e8525ea1b52f', 'same qualified boot')
memory = int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines()
                  if line.startswith('MemAvailable:'))) * 1024
need(memory >= 16 << 30, 'CPU prerequisite memory headroom')
need(not os.path.lexists(REPORT), 'create-only CPU report root')
plan = json.loads(raw_file(PLAN, PLAN_SHA, cap=2 << 20, keep=True)[1])
need(plan['nodes'] == NODES and plan['runtime'] == str(ROOT) and plan['closure_sha256'] == CLOSURE_SHA,
     'exact mixed ten-case plan')
closure = json.loads(raw_file(ROOT / 'scripts/bt4_runtime_closure_v1.json', CLOSURE_SHA, 2 << 20, True)[1])
need(len(closure['repo_sources']) == 609 and len(closure['modules']) == 37 and closure['cuda_qualification'] is False,
     'accepted immutable runtime-v3 closure')
pins = {closure['python']['path']: closure['python']['sha256']}
for pin in closure['modules'].values():
    need(pin['path'] not in pins or pins[pin['path']] == pin['sha256'], 'external module pin collision')
    pins[pin['path']] = pin['sha256']
for path, digest in closure['runtime_files'].items():
    need(path not in pins or pins[path] == digest, 'external runtime pin collision')
    pins[path] = digest
for relative, digest in closure['repo_sources'].items():
    pins[str(ROOT / relative)] = digest
for relative, digest in closure['native_source_pins'].items():
    need(closure['repo_sources'].get(relative) == digest, 'native source/image lineage')
pins[str(DEPS / 'pytest/__init__.py')] = PYTEST_SHA
for path, digest in pins.items():
    need((Path(path).is_relative_to(ROOT) or Path(path).is_relative_to(DEPS) or path == '/usr/bin/python3.10')
         and not path.endswith(('.onnx', '.pt', '.pth', '.safetensors')), 'closed CPU pin path')
    raw_file(path, digest)
names = {item['relative'] for item in plan['files']}
need(names == {'tests/conftest.py', 'pyproject.toml', 'tests/targeted_diagnostics_v1.py', 'tests/targeted_diagnostics_v2.py',
               'tests/test_targeted_diagnostics_v1.py', 'tests/test_targeted_diagnostics_v2.py', 'tests/test_targeted_diagnostics_v3.py'}
     and len(plan['files']) == 7, 'exact seven-file private capsule')
payloads = {}
for item in plan['files']:
    need(item['relative'] in names and item['relative'] not in payloads, 'unique capsule input')
    raw = raw_file(item['source']['path'], item['source']['sha256'], 2 << 20, True)[1]
    need(len(raw) == item['bytes'], 'capsule source size')
    payloads[item['relative']] = raw
need(hashlib.sha256(payloads['tests/conftest.py']).hexdigest() == CONFTEST_SHA, 'unchanged normal conftest')
REPORT.mkdir(mode=0o700)
CAPSULE.mkdir(mode=0o700)
(CAPSULE / 'tests').mkdir(mode=0o700)
for name, raw in payloads.items():
    with (CAPSULE / name).open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
for name in ('tmp', 'inductor', 'triton', 'torch-extensions', 'xdg'):
    (REPORT / name).mkdir(mode=0o700)
os.environ.update(TMPDIR=str(REPORT / 'tmp'), TORCHINDUCTOR_CACHE_DIR=str(REPORT / 'inductor'),
                  TRITON_CACHE_DIR=str(REPORT / 'triton'), TORCH_EXTENSIONS_DIR=str(REPORT / 'torch-extensions'),
                  XDG_CACHE_HOME=str(REPORT / 'xdg'))
sys.addaudithook(audit)
sys.path[:0] = [str(ROOT), str(CAPSULE / 'tests'), str(DEPS)]
entry = importlib.import_module('scripts.bt4_queue_worker_entry_v3')
entry.verify_runtime_closure()
import torch
torch.set_num_threads(2)
import pytest
need(Path(pytest.__file__).resolve() == DEPS / 'pytest/__init__.py'
     and raw_file(pytest.__file__, PYTEST_SHA)[0] == PYTEST_SHA and pytest.__version__ == '9.0.2', 'pytest origin')
worker = importlib.import_module('scripts.bt4_root_policy_worker')
evaluator = importlib.import_module('scripts.bt4_generation_evaluator')
checkpoint_module = importlib.import_module('scripts.bt4_longblock_checkpoint_v2')
checkpoint_class = entry.Checkpoint
need(checkpoint_class is checkpoint_module.Checkpoint, 'actual normal entry.Checkpoint identity')
checkpoint_path = ROOT / 'scripts/bt4_longblock_checkpoint_v2.py'
need(closure['repo_sources'].get('scripts/bt4_longblock_checkpoint_v2.py') == CHECKPOINT_SHA, 'retained class source pin')


def check_origins():
    origins = {}
    for name, pin in closure['modules'].items():
        module = sys.modules.get(name)
        need(module is not None and Path(module.__file__).resolve() == Path(pin['path']), 'actual module origin: ' + name)
        raw_file(pin['path'], pin['sha256'])
        origins[name] = pin
    for method in (checkpoint_class.record_game, checkpoint_class.transaction):
        need(Path(method.__code__.co_filename).resolve() == checkpoint_path, 'actual retained checkpoint implementation')
    raw_file(checkpoint_path, CHECKPOINT_SHA)
    for name in ('chess_anti_engine.encoding._lc0_ext', 'chess_anti_engine.mcts._mcts_tree', 'chess_anti_engine.nnue._nnue_ext'):
        need(sys.modules[name].SLIDER_BACKEND == 'pext', 'actual native backend')
    for module in tuple(sys.modules.values()):
        filename = getattr(module, '__file__', None)
        if filename and Path(filename).resolve().is_relative_to(CAPSULE):
            need(Path(filename).resolve().relative_to(CAPSULE).as_posix() in names, 'unpinned capsule import')
    return origins


class ExactCheckpointFixture:
    @pytest.fixture
    def actual_checkpoint_class(self):
        return checkpoint_class  # Same authenticated class used by production run_owned_roster.


origins = check_origins()
pre_path = list(sys.path)
initial_mode = worker.rep_fix.current()
initial_profiles = (sys.getprofile(), threading.getprofile())
initial_threads = {thread.ident for thread in threading.enumerate()}
initial_methods = (worker.BT4GamePool.__init__, checkpoint_class.record_game, evaluator.BT4OnnxEvaluator.execute)
need(not torch.cuda.is_initialized(), 'no CUDA initialization')
result = pytest.main(['-q', '--tb=short', '--maxfail=1', '--import-mode=importlib',
                      '--rootdir=' + str(CAPSULE), '--confcutdir=' + str(CAPSULE), '-c', str(CAPSULE / 'pyproject.toml'),
                      '-o', 'cache_dir=' + str(REPORT / 'cache'), '--basetemp=' + str(REPORT / 'pytest-tmp'),
                      '--junitxml=' + str(REPORT / 'diagnostic-controls.xml'),
                      *(str(CAPSULE) + '/' + node for node in NODES)], plugins=[ExactCheckpointFixture()])
post_origins = check_origins()
need(list(sys.path) == pre_path, 'diagnostic controls must not mutate import paths; no fixture-prefix exemption')
need(not torch.cuda.is_initialized() and worker.rep_fix.current() == initial_mode, 'CUDA/native flag state restoration')
need(initial_profiles == (sys.getprofile(), threading.getprofile()) and
     initial_threads == {thread.ident for thread in threading.enumerate()}, 'profiler/private thread restoration')
need(initial_methods == (worker.BT4GamePool.__init__, checkpoint_class.record_game, evaluator.BT4OnnxEvaluator.execute),
     'actual production method restoration')
conftests = [module for module in tuple(sys.modules.values()) if getattr(module, '__file__', None)
             and Path(module.__file__).resolve() == CAPSULE / 'tests/conftest.py']
need(len(conftests) == 1, 'normal unchanged conftest loaded exactly once')
cases = list(ET.parse(REPORT / 'diagnostic-controls.xml').iter('testcase'))
need(int(result) == 0 and len(cases) == 10 and {case.get('name') for case in cases} == {node.split('::')[1] for node in NODES}
     and not any(case.find(kind) is not None for case in cases for kind in ('failure', 'error', 'skipped')),
     'exact mixed ten cases all pass without skip/error')
for item in plan['files']:
    raw_file(CAPSULE / item['relative'], item['source']['sha256'], 2 << 20)
usage = resource.getrusage(resource.RUSAGE_SELF)
files = [path for path in REPORT.rglob('*') if path.is_file()]
need(len(files) <= 512 and sum(path.stat().st_size for path in files) <= 64 << 20, 'private report postcondition')
actual = {'status': 'TARGETED_DIAGNOSTICS_MIXED_TEN_PASS', 'nodes': NODES, 'case_count': 10,
          'scope': 'Seven V1 helper controls and three V3 quiescence/actual factory/retained SQLite controls only; no product credit.',
          'pytest_exit': int(result), 'closure_sha256': CLOSURE_SHA, 'plan_sha256': PLAN_SHA,
          'normal_conftest_sha256': CONFTEST_SHA, 'origins_before': origins, 'origins_after': post_origins,
          'actual_checkpoint_source_sha256': CHECKPOINT_SHA,
          'checkpoint_origins': {name: {'path': str(Path(getattr(checkpoint_class, name).__code__.co_filename).resolve()),
                                      'sha256': CHECKPOINT_SHA} for name in ('record_game', 'transaction')}, 'sys_path_unchanged': True,
          'cuda_initialized': False, 'model_or_real_session_loaded': False, 'children_authorized': False,
          'elapsed_seconds': time.monotonic() - started, 'cpu_seconds': usage.ru_utime + usage.ru_stime,
          'peak_rss_bytes': usage.ru_maxrss * 1024, 'explicit_hash_read_bytes': read_bytes,
          'accounting_limit': 'Explicit hashes/private output postchecks only, not hard aggregate read/RSS/Windows pipe quotas.'}
with (REPORT / 'actual.json').open('x') as stream:
    json.dump(actual, stream, sort_keys=True)
    stream.write('\n')
print(json.dumps(actual, sort_keys=True), flush=True)
raise SystemExit(int(result))
