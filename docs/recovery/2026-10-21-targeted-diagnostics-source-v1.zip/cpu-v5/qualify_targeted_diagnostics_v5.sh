#!/bin/bash
set -euo pipefail
umask 077
helper=/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-targeted-diagnostics-cpu-v1/qualify_targeted_diagnostics_v5.py
test ! -e /tmp/deepfin-pr1110-production-20261021-v1/reports-targeted-diagnostics-v5
test "$(sha256sum "$helper" | cut -d ' ' -f 1)" = 71f24ea6db6d0687df20deabfe580f1e8420709e2342d416791dd97ad9bbcb22
cd /tmp/deepfin-pr1110-production-20261021-v1/runtime-v3
export CAE_TEST_THREADS=2 CAE_EXPECT_SLIDER_BACKEND=pext PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONDONTWRITEBYTECODE=1 MAX_JOBS=1
exec /usr/bin/python3.10 -I -S -B "$helper"
