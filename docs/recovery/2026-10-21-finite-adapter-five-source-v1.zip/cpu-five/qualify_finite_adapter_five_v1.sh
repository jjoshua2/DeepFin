#!/bin/bash
set -euo pipefail
umask 077
helper=/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-targeted-diagnostics-cpu-v1/qualify_finite_adapter_five_v1.py
test ! -e /tmp/deepfin-pr1110-production-20261021-v1/reports-finite-adapter-five-v1
test "$(sha256sum "$helper" | cut -d ' ' -f 1)" = 7d01e96771cf1d13d2ee519a87e8d797c70d31d993fa6b8e5b3f659d2a8658ec
cd /tmp/deepfin-pr1110-production-20261021-v1/runtime-v3
export CAE_TEST_THREADS=2 CAE_EXPECT_SLIDER_BACKEND=pext PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
export PYTHONDONTWRITEBYTECODE=1 MAX_JOBS=1
exec /usr/bin/python3.10 -I -S -B "$helper"
