"""UNRUN source controls of production composition; no roster/model/session."""
import threading
import pytest
from finite_roster_adapter_v3 import ProductionQuiescence, call_with_diagnostics, verify_complete, NAME
from targeted_diagnostics_v2 import TargetedDiagnostics
from test_targeted_diagnostics_v1 import Pool, Checkpoint, Evaluator


def make_trace(tmp_path, quiescent):
    return TargetedDiagnostics(Pool, Checkpoint, Evaluator, tmp_path / "trace.json",
        expected_origins={"pool": Pool.__init__.__code__.co_filename,
            "checkpoint": Checkpoint.record_game.__code__.co_filename,
            "evaluator": Evaluator.execute.__code__.co_filename}, quiescent=quiescent)


def test_production_quiescence_new_live_thread(tmp_path):
    q = ProductionQuiescence()
    release = threading.Event()
    thread = threading.Thread(target=lambda: release.wait(5))
    thread.start()
    trace = make_trace(tmp_path, q)
    try:
        assert call_with_diagnostics(trace, q, lambda: "returned") == "returned"
        assert not q() and trace.ownership_retained and trace.active
    finally:
        release.set()
        thread.join(2)
        assert not thread.is_alive()
        assert trace.finalize_after_quiescence()


def test_production_wrapper_primary_error_retains(tmp_path):
    q = ProductionQuiescence()
    trace = make_trace(tmp_path, q)
    original = TimeoutError("primary deadline")
    def fail():
        raise original
    with pytest.raises(TimeoutError) as caught:
        call_with_diagnostics(trace, q, fail)
    assert caught.value is original and original.targeted_diagnostics is trace
    assert not q() and trace.ownership_retained and trace.active
    assert trace.path.is_file()
    # Test alone owns its isolated boundary doubles. Production never upgrades
    # unknown exception quiescence; process reaping ends production patch lifetime.
    trace.quiescent = lambda: True
    assert trace.finalize_after_quiescence()


def test_complete_predicate_exact_full_witness(tmp_path):
    q = ProductionQuiescence()
    trace = make_trace(tmp_path, q)
    def witness():
        for game in range(128):
            trace._event("actor", game)
            trace._event("writer", game, "a" * 64)
            trace._event("ack", game, "a" * 64)
        return {"status": "COMPLETE_NOT_ADMISSION", "unit_receipts": {NAME: [{}] * 128}}
    result = call_with_diagnostics(trace, q, witness)
    assert verify_complete(trace, result)["replacement_admissions"] == 64
    with pytest.raises(ValueError, match="incomplete"):
        verify_complete(trace, {**result, "status": "FAILED"})
    trace.events.pop()
    with pytest.raises(ValueError, match="full actual"):
        verify_complete(trace, result)
