"""UNRUN source draft. No CLI, launcher, lease acquisition or queue mutation.

The sole root operator must independently bind/review a DISTINCT armed packet,
materialized runtime, native build, inherited all-three custody and guard first.
Importing this module performs no target import, model read or filesystem write.
The adjacent inactive packet cannot pass run_prepared's admission gate.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import threading
import time
from typing import Any

ORIGINAL_EXPIRY = 1792649011.575
ACTIVE_SECONDS = 300
CLEANUP_SECONDS = 180
PRIVATE_ROOT = PurePosixPath(
    "/home/josh/chess-artifacts/operations/bt4-pr1110-correctness-private-20261021-v3"
)
NAME = "private-unit-000000000000"
GLOBAL_STOP = "/home/josh/projects/chess/chess_anti_engine/operations/DEEPFIN_STOP"
MODEL_SHA256 = "809db9c3c8063683bf8e7c08de8fec92ea4e37ad8c68c8b1befbde4bd1958961"
SEED_BASE = 7000000000002000000
GENERATION = {
    "parallel_games": 64,
    "temperature": 1.0,
    "initial_fen": "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
    "syzygy_path": "/home/josh/projects/chess/data/syzygy_3-4-5:/home/josh/projects/chess/data/syzygy_6",
}
GEOMETRY = {
    "max_units": 1, "max_live_games": 64, "target_rows": 64, "max_rows": 64,
    "batch_wait_ms": 0.0, "max_writes": 1, "producer_threads": 1,
    "writer_threads": 1, "native_microbatch": 32,
    "retained_byte_budget": 2147483648,
}
REQUIRED_ENTRY = {
    "scripts/bt4_queue_worker_entry_v3.py", "scripts/bt4_queue_consumer_v2.py",
    "scripts/bt4_inherited_owner_v2.py", "scripts/bt4_longblock_checkpoint_v2.py",
    "scripts/bt4_unit_runtime_v2.py", "scripts/bt4_raw_recovery_v2.py",
    "scripts/bt4_root_policy_worker.py", "scripts/bt4_generation_evaluator.py",
    "scripts/bt4_tpg_bridge_v2.py",
}


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def make_descriptor(
    *, boot_id: str, source_pins: Mapping[str, str], scope_sha256: str,
    stop_paths: tuple[str, ...], yield_paths: tuple[str, ...],
) -> dict[str, Any]:
    """Pure constructor for the retained CLOSED v3 schema, never an admission.

    Pins must be computed from the NEW source-root-local runtime, including PR
    modules, retained helper source, rebuilt native images and actual closure.
    No list-to-dict coercion of old N10 source_pins is permitted.
    """
    if not isinstance(source_pins, Mapping) or not REQUIRED_ENTRY.issubset(source_pins):
        raise ValueError("new complete dict source pins required")
    pins = dict(source_pins)
    for relative, sha in pins.items():
        path = PurePosixPath(relative)
        if (path.is_absolute() or ".." in path.parts or path.as_posix() != relative
                or type(sha) is not str or len(sha) != 64
                or any(char not in "0123456789abcdef" for char in sha)):
            raise ValueError("canonical relative source pin required")
    if (not boot_id or type(scope_sha256) is not str or len(scope_sha256) != 64
            or any(char not in "0123456789abcdef" for char in scope_sha256)):
        raise ValueError("actual boot and immutable private scope required")
    required_controls = {GLOBAL_STOP, *(str(PRIVATE_ROOT / name) for name in ("STOP", "PAUSE", "CANCEL"))}
    if not required_controls.issubset(stop_paths) or len(set(stop_paths)) != len(stop_paths):
        raise ValueError("explicit private/global STOP coverage required")
    for value in (*stop_paths, *yield_paths):
        path = PurePosixPath(value)
        if not path.is_absolute() or ".." in path.parts or path.as_posix() != value:
            raise ValueError("canonical explicit control path required")
    unit = PRIVATE_ROOT / "unit-000000000000"
    generation = dict(GENERATION)
    return {
        "schema_version": 3, "boot_id": boot_id, "unit": 0,
        "seed_base": SEED_BASE, "output_root": str(unit / "attempt-00"),
        "checkpoint_path": str(unit / "checkpoint.sqlite"),
        "bindings": {"model_sha256": MODEL_SHA256, "source_pins": pins,
                     "generation": generation, "seed_base": SEED_BASE},
        "checkpoint_limits": {
            "max_attempts": 1, "unit_seconds": ACTIVE_SECONDS, "unit_io_bytes": 1,
            "unit_output_bytes": 536870912, "total_seconds": ACTIVE_SECONDS,
            "total_io_bytes": 1, "total_output_bytes": 536870912,
        },
        "owner_limits": {
            "deadline_unix": "QUEUE_ACTUAL_START_PLUS_BLOCK_SECONDS",
            "physical_io_bytes": 1, "minimum_disk_bytes": 1, "output_bytes": 536870912,
        },
        "source_pins": pins, "stop_paths": list(stop_paths),
        "yield_paths": list(yield_paths), "prior_roots": [],
        "generation": generation, "external_root": str(PRIVATE_ROOT),
        "attempt": 0, "scope_sha256": scope_sha256, "block_seconds": ACTIVE_SECONDS,
    }


def finite_authorizer(
    expected: Mapping[str, Any], *, expected_sha256: str, expires_unix: float,
    now: Callable[[], float] = time.time,
) -> Callable[[Mapping[str, dict[str, Any]], Path], None]:
    """Bind the exact ONE private roster; never consult/change the live queue."""
    frozen = json.loads(canonical(dict(expected)))
    if (digest(frozen) != expected_sha256 or type(expires_unix) not in (int, float)
            or not math.isfinite(expires_unix) or not 0 < expires_unix <= ORIGINAL_EXPIRY):
        raise ValueError("exact finite descriptor/expiry binding required")

    def authorize(roster: Mapping[str, dict[str, Any]], out: Path) -> None:
        observed = now()
        if (type(observed) not in (int, float) or not math.isfinite(observed)
                or observed <= 0):
            raise ValueError("finite positive actual clock observation required")
        if observed >= expires_unix or observed >= ORIGINAL_EXPIRY:
            raise ValueError("private qualification authority expired")
        if dict(roster) != {NAME: frozen} or out != Path(str(PRIVATE_ROOT / "coordinator")):
            raise ValueError("exact private one-unit roster/output only")
        if frozen["unit"] != 0 or frozen["attempt"] != 0 or frozen["prior_roots"]:
            raise ValueError("fresh private attempt only; no checkpoint adoption")
        if frozen["generation"] != GENERATION:
            raise ValueError("unchanged 128x400 caller science contract required")

    return authorize


class ProductionQuiescence:
    """Conservative Python caller census; never performs cleanup or releases custody.

    Actual run_pooled_units joins producers then dispatcher/writer before normal
    return; shared_teacher_owner retains custody on ProducerJoinTimeout. Only a
    successful normal return plus no new live Python threads proves this scope.
    Any exceptional/unknown exit retains patches until external process reaping.
    Baseline workers must not be reused by this isolated private roster.
    """
    def __init__(self) -> None:
        self.baseline = frozenset(threading.enumerate())
        self.returned = False
        self.primary_error: BaseException | None = None

    def __call__(self) -> bool:
        if not self.returned or self.primary_error is not None:
            return False
        return not any(thread not in self.baseline and thread.is_alive()
                       for thread in threading.enumerate())


def verify_complete(trace: Any, result: Mapping[str, Any]) -> dict[str, Any]:
    """Only actual complete128 ordering; partial persistence never grants credit."""
    saved = trace.snapshot()
    receipts = result.get("unit_receipts", {}).get(NAME, [])
    if (result.get("status") != "COMPLETE_NOT_ADMISSION" or len(receipts) != 128
            or saved["errors"] or saved["dropped"] or saved["ownership_retained"]
            or not saved["methods_restored"]):
        raise ValueError("incomplete run/trace or retained ownership; no qualification")
    writes, acks, actors = {}, {}, []
    for record in saved["events"]:
        game = record["game"]
        if record["kind"] == "writer":
            if game in writes:
                raise ValueError("duplicate actual writer")
            writes[game] = record
        elif record["kind"] == "ack":
            if (game not in writes or writes[game]["sha256"] != record["sha256"]
                    or game in acks or record["thread"] != trace.owner):
                raise ValueError("actual writer-before-owner ACK failed")
            acks[game] = record
        elif record["kind"] == "actor":
            if (game != len(actors) or record["thread"] != trace.owner
                    or (game >= 64 and len(acks) < game - 63)):
                raise ValueError("actual owner sequential admission/refill order failed")
            actors.append(game)
        else:
            raise ValueError("unknown diagnostic event")
    if (actors != list(range(128)) or set(writes) != set(range(128))
            or set(acks) != set(range(128)) or len(saved["events"]) != 384):
        raise ValueError("full actual writer/ACK/refill witness required")
    return {**saved, "writer_before_owner_ack_before_refill": True,
            "replacement_admissions": 64, "training_credit": 0, "speed_claim": False}


def call_with_diagnostics(trace: Any, quiescent: ProductionQuiescence, call: Callable[[], Any]) -> Any:
    """One existing guarded call; no scheduler, cleanup or error replacement."""
    with trace:
        try:
            result = call()
        except BaseException as error:
            quiescent.primary_error = error
            try:
                error.targeted_diagnostics = trace
                error.targeted_quiescence = quiescent
            except BaseException:
                pass
            raise
        else:
            quiescent.returned = True
    return result

def run_prepared(
    packet: Mapping[str, Any], *, entry: Any, consumer: Any, recovery: Any,
    guard: Any, parent: dict[str, Any], leases: dict[str, Any], priority_module: Any,
) -> dict[str, Any]:
    """One call under ROOT-owned admission/custody; never acquires canonical locks.

    This is a source draft, NOT executable approval. The caller's independently
    reviewed finite parent must first validate actual PID/birth/boot/FLOCK,
    original guard/headroom, exact imported closure/native provenance, expiry,
    one-use slot, all STOPs and qualified post-test CLOSED+PAUSED restoration.
    """
    if (packet.get("status") != "APPROVED_EXACT_PRIVATE_ONE_UNIT_CORRECTNESS"
            or packet.get("operational_ready") is not True
            or packet.get("independent_action_review_ref") is None
            or packet.get("root_resource_decision_ref") is None
            or packet.get("paused_restoration_plan_ref") is None):
        raise ValueError("inactive draft: distinct reviewed root admission required")
    descriptor = packet["descriptor"]
    expires = packet["expires_unix"]
    now = time.time()
    if not now < expires <= ORIGINAL_EXPIRY:
        raise ValueError("original absolute expiry cannot renew")
    out = Path(str(PRIVATE_ROOT / "coordinator"))
    if set(leases) != {"gpu", "io", "supervisor"} or guard.output_root != Path(str(PRIVATE_ROOT)):
        raise ValueError("inherited canonical all-three/private guard required")
    if not now < guard.limits["deadline_unix"] <= min(expires, now + ACTIVE_SECONDS):
        raise ValueError("aggregate guard must fit original authority and300s active bound")
    authorize = finite_authorizer(descriptor, expected_sha256=packet["descriptor_sha256"],
                                  expires_unix=expires)
    authorize({NAME: descriptor}, out)
    # Deferred actual import; no import/runtime action occurs when drafting or
    # reading this module. Same source-root-local retained helpers are passed.
    from scripts.shared_teacher_owner import run_owned_roster

    from scripts import bt4_root_policy_worker as worker
    from scripts.bt4_generation_evaluator import BT4OnnxEvaluator
    from targeted_diagnostics_v2 import TargetedDiagnostics

    source_root = Path(entry.__file__).resolve().parents[1]
    quiescent = ProductionQuiescence()
    trace = TargetedDiagnostics(
        worker.BT4GamePool, entry.Checkpoint, BT4OnnxEvaluator,
        Path(str(PRIVATE_ROOT / "targeted-partial-v3.json")),
        expected_origins={
            "pool": source_root / "scripts/shared_teacher_generation.py",
            "checkpoint": source_root / "scripts/bt4_longblock_checkpoint_v2.py",
            "evaluator": source_root / "scripts/bt4_generation_evaluator.py",
        }, quiescent=quiescent)
    def actual_call() -> Any:
        return run_owned_roster(
                {NAME: descriptor}, entry=entry, consumer=consumer, recovery=recovery,
                guard=guard, parent=parent, leases=leases, out=out,
                priority_module=priority_module, authorize=authorize,
                deadline_seconds=min(float(ACTIVE_SECONDS), guard.limits["deadline_unix"] - now),
                fake_cpu=False, **GEOMETRY,
            )
    result = call_with_diagnostics(trace, quiescent, actual_call)
    return {"result": result, "correctness_trace": verify_complete(trace, result),
            "native_admission": False, "training_credit": 0, "speed_claim": False}
