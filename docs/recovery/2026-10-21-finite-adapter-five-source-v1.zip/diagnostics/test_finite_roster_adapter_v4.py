"""UNRUN actual adapter caller control; no real roster/model/session."""
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
import pytest
import finite_roster_adapter_v4 as adapter


def test_actual_adapter_early_error_persists_before_coordinator(
        tmp_path, monkeypatch, actual_checkpoint_class):
    from scripts import shared_teacher_owner
    from scripts import bt4_queue_worker_entry_v3 as entry
    assert entry.Checkpoint is actual_checkpoint_class
    root = tmp_path / "fresh-private"
    # Match actual finite_child_entry.prepare_private: absent before launch,
    # created by authenticated child before guard/adapter, no old-tree adoption.
    assert not root.exists()
    root.mkdir(mode=0o700)
    monkeypatch.setattr(adapter.base, "PRIVATE_ROOT", PurePosixPath(root.as_posix()))
    monkeypatch.setattr(adapter.time, "time", lambda: 1.0)
    original_authorizer = adapter.base.finite_authorizer
    monkeypatch.setattr(adapter.base, "finite_authorizer", lambda *args, **kwargs:
        original_authorizer(*args, **kwargs, now=lambda: 1.0))
    descriptor = adapter.base.make_descriptor(boot_id="test-boot",
        source_pins={name: "a" * 64 for name in adapter.base.REQUIRED_ENTRY},
        scope_sha256="b" * 64,
        stop_paths=(adapter.base.GLOBAL_STOP, *(str(root / name) for name in ("STOP", "PAUSE", "CANCEL"))),
        yield_paths=())
    packet = dict(status="APPROVED_EXACT_PRIVATE_ONE_UNIT_CORRECTNESS", operational_ready=True,
        independent_action_review_ref={}, root_resource_decision_ref={}, paused_restoration_plan_ref={},
        descriptor=descriptor, descriptor_sha256=adapter.base.digest(descriptor), expires_unix=2.0)
    guard = SimpleNamespace(output_root=root, limits={"deadline_unix": 2.0})
    primary = RuntimeError("actual caller fails before coordinator mkdir")
    def fail(*args, **kwargs):
        assert root.is_dir() and not (root / "coordinator").exists()
        raise primary
    monkeypatch.setattr(shared_teacher_owner, "run_owned_roster", fail)
    with pytest.raises(RuntimeError) as caught:
        adapter.run_prepared(packet, entry=entry, consumer=object(), recovery=object(),
            guard=guard, parent={}, leases={"gpu": object(), "io": object(), "supervisor": object()},
            priority_module=object())
    assert caught.value is primary
    trace = primary.targeted_diagnostics
    try:
        assert (root / "targeted-partial-v4.json").is_file()
        assert not (root / "coordinator").exists()
        assert trace.ownership_retained and trace.snapshot()["status"] == "PARTIAL_DIAGNOSTIC_ONLY"
    finally:
        # This CPU test has no roster threads. Restore test process methods only;
        # actual production unknown exceptions retain ownership until reaping.
        trace.quiescent = lambda: True
        assert trace.finalize_after_quiescence()


def test_exact_prepared_root_validation(tmp_path, monkeypatch):
    root = tmp_path / "new-private"
    monkeypatch.setattr(adapter.base, "PRIVATE_ROOT", PurePosixPath(root.as_posix()))
    with pytest.raises(FileNotFoundError):
        adapter.ensure_private_root(SimpleNamespace(output_root=root))
    assert not root.exists()
    root.mkdir()
    assert adapter.ensure_private_root(SimpleNamespace(output_root=root)) == root
    with pytest.raises(ValueError, match="exact canonical"):
        adapter.ensure_private_root(SimpleNamespace(output_root=tmp_path / "other"))
