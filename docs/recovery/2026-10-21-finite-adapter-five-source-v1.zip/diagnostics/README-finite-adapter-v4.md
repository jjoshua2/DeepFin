# Finite adapter V4 — UNRUN source composition

V3 and all previously frozen files remain unchanged. V4 reuses V3 descriptor,
authorizer, constants, production quiescence and complete predicate; its admission
checks and actual roster call preserve geometry/custody/control/deadline behavior.
After all existing packet/guard/authorizer gates and before trace construction,
V4 verifies the exact guard.output_root is an absolute canonical real directory.
Missing root fails closed; adapter creates nothing. Symlink/non-directory/
canonical mismatch fails.

Actual finite_child_entry_v2.py source was read: prepare_private() first requires
canonical existing PRIVATE.parent and absent PRIVATE, then creates PRIVATE mode
0700 plus unit/attempt directories. This authenticated child preparation occurs
before retained OwnerGuard construction, guard.check and adapter.run_prepared.
Thus the proposed early persist-parent gap was not demonstrated under the actual
V2 child: that caller already creates the root. V4 makes the adapter's assumption
explicit. The existing-directory path validates the already guard-bound
child-prepared directory; it grants no adoption authority. Fresh root absence
before launch remains a parent/child one-use preflight requirement.

V4 uses the same never-consumed V3 private root and distinct snapshot filename
targeted-partial-v4.json; no runtime/private directory was created by authoring.
Original expiry remains unchanged and inactive. Future whole-action review must
bind V4, frozen V3 source and both helpers in source-root-local runtime closure;
ordinary imports are used, with no custom loader or sys.path override. This V4
composition adds a dependency on V3 rather than recopying descriptor/authorizer.

New controls in test_finite_roster_adapter_v4.py (UNRUN):

- test_actual_adapter_early_error_persists_before_coordinator
  invokes actual V4.run_prepared with valid synthetic exact descriptor/authorizer,
  existing child-prepared temp root, actual runtime entry/Checkpoint fixture and
  patched run_owned_roster raising before coordinator creation. Verifies primary
  identity and persistent partial trace, then restores test-owned methods only.
- test_exact_prepared_root_validation
  covers missing-root failure without creation, prepared-root validation and
  wrong-guard-root rejection.

No imports/tests/compilation/GPU/probes/launch or grant preparation occurred.
Only native source reads, source edits and hashes were authorized here. These
controls and the V3 wrapper controls require a separate reviewed bounded CPU gate.
