"""UNRUN V4 composition; exact admitted root exists before diagnostic scope.

V3 stays frozen. This source is inactive under its unchanged original expiry.
Future runtime closure must explicitly include V3 and both diagnostic helpers.
"""
from pathlib import Path
import stat
import time
import finite_roster_adapter_v3 as base

make_descriptor = base.make_descriptor
finite_authorizer = base.finite_authorizer
ProductionQuiescence = base.ProductionQuiescence
verify_complete = base.verify_complete


def ensure_private_root(guard):
    """Validate only the existing authenticated child-prepared root."""
    root = Path(str(base.PRIVATE_ROOT))
    if guard.output_root != root or root.resolve() != root:
        raise ValueError("exact canonical admitted guard root required")
    metadata = root.lstat()  # Missing root fails; adapter creates nothing.
    if stat.S_ISLNK(metadata.st_mode) or not stat.S_ISDIR(metadata.st_mode):
        raise ValueError("private guard root must be a real directory")
    return root


def run_prepared(packet, *, entry, consumer, recovery, guard, parent, leases, priority_module):
    # Same frozen V3 finite gates, geometry and authority. Root creation follows
    # every admission check, and precedes targeted diagnostic construction.
    if (packet.get("status") != "APPROVED_EXACT_PRIVATE_ONE_UNIT_CORRECTNESS"
            or packet.get("operational_ready") is not True
            or packet.get("independent_action_review_ref") is None
            or packet.get("root_resource_decision_ref") is None
            or packet.get("paused_restoration_plan_ref") is None):
        raise ValueError("inactive draft: distinct reviewed root admission required")
    descriptor = packet["descriptor"]
    expires = packet["expires_unix"]
    now = time.time()
    if not now < expires <= base.ORIGINAL_EXPIRY:
        raise ValueError("original absolute expiry cannot renew")
    out = Path(str(base.PRIVATE_ROOT / "coordinator"))
    if set(leases) != {"gpu", "io", "supervisor"} or guard.output_root != Path(str(base.PRIVATE_ROOT)):
        raise ValueError("inherited canonical all-three/private guard required")
    if not now < guard.limits["deadline_unix"] <= min(expires, now + base.ACTIVE_SECONDS):
        raise ValueError("aggregate guard must fit original authority and300s active bound")
    authorize = base.finite_authorizer(descriptor, expected_sha256=packet["descriptor_sha256"],
                                      expires_unix=expires)
    authorize({base.NAME: descriptor}, out)
    ensure_private_root(guard)

    from scripts.shared_teacher_owner import run_owned_roster
    from scripts import bt4_root_policy_worker as worker
    from scripts.bt4_generation_evaluator import BT4OnnxEvaluator
    from targeted_diagnostics_v2 import TargetedDiagnostics

    source_root = Path(entry.__file__).resolve().parents[1]
    quiescent = base.ProductionQuiescence()
    trace = TargetedDiagnostics(
        worker.BT4GamePool, entry.Checkpoint, BT4OnnxEvaluator,
        Path(str(base.PRIVATE_ROOT / "targeted-partial-v4.json")),
        expected_origins={
            "pool": source_root / "scripts/shared_teacher_generation.py",
            "checkpoint": source_root / "scripts/bt4_longblock_checkpoint_v2.py",
            "evaluator": source_root / "scripts/bt4_generation_evaluator.py",
        }, quiescent=quiescent)
    def actual_call():
        return run_owned_roster(
            {base.NAME: descriptor}, entry=entry, consumer=consumer, recovery=recovery,
            guard=guard, parent=parent, leases=leases, out=out,
            priority_module=priority_module, authorize=authorize,
            deadline_seconds=min(float(base.ACTIVE_SECONDS), guard.limits["deadline_unix"] - now),
            fake_cpu=False, **base.GEOMETRY)
    result = base.call_with_diagnostics(trace, quiescent, actual_call)
    return {"result": result, "correctness_trace": base.verify_complete(trace, result),
            "native_admission": False, "training_credit": 0, "speed_claim": False}
