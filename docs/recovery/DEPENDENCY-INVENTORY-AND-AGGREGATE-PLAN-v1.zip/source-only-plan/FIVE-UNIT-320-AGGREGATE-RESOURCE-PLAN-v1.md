The smallest useful aggregate experiment is a new partial supply diagnostic, not a640-game completion test. Reuse `run_owned_roster` and `run_pooled_units` with five canonical128-game/400-ply units,64 actors each; two producers, native160, target320 and owned-row capacity640. Native160 and the possibility of a320-row call are hypotheses. No scheduler, production edit, executable packet or launch authority is supplied here.

Propose the same60-second active observation and180-second cleanup ceiling. Keep CPU affinity29/30, numeric threads2, nice19, familyCPU360/childCPU300, sampled RSS8GiB/PSS6GiB, per-file32MiB, streams1MiB, private output512MiB, minimum available memory16GiB/disk8GiB, sampled accounting and unchanged inherited AS. These are unchanged proposed policy ceilings, not a fit guarantee. Exact final source/action review still decides admission; this document grants nothing.

Five units mean640 total game quotas and320 actor capacity. They must use a new exact ordered descriptor roster, common scientific/source contract and unique private output roots. They cannot use the consumed one-unit GO or its single-unit authorizer. Names proposed in JSON are absent-state requirements, not observed facts. Units0..4 are private namespaces, unrelated to preserved ordinary units4152..4156.

The source reservation arithmetic is exact:

| Reservation | Bytes |
|---|---:|
|320 potential400-ply trajectories |7,758,315,520|
|Writer progress |48,489,472|
|Two native160 producers plus640 dispatch credits |212,776,960|
|Fixed progress |1,048,576|
|Total progress |262,315,008|
|Required retained credit |8,020,630,528|

`bt4_root_policy_worker.py:943–972` enforces requested trajectory plus progress against explicit `retained_byte_budget`. It does **not** require this bookkeeping credit to be below sampled RSS/PSS. The worst-case7.47GiB credit exceeds6GiB PSS, but does not prove an early partial run physically exceeds6GiB: stored trajectory length and current resident allocation differ. Conversely, it cannot establish fit; ORT/model/interpreter/native overhead remains additional. Keep the existing RSS/PSS abort policy, collect actual accounting, and preserve partial outputs on resource failure. No cap increase is proposed.

The full640×400 schema-row planning upper bound alone is15,474,688,000 bytes before other output overhead. Compression and early termination mean this is not an exact NPZ forecast, but512MiB cannot be represented as guaranteed capacity for all640 games. It can remain the partial diagnostic's abort threshold. Per-file32MiB is likewise an enforced ceiling, not a promise every artifact fits. No deletion, quota recycling or full-unit qualification follows a cap-stopped partial.

Target320/max640 gives room for two full320-row credit waves, but the five-unit320-actor reservoir cannot independently supply640 outstanding roots. With wait0, one native160 task may be dispatched before another settles; two producers do not guarantee one320 batch. The useful observation is the actual distinct-root row histogram and readiness, with startup/playing labels and current model/provider/root proof. A single320 call would establish that call only, not sustained occupancy, speedup or optimal settings.

Use the existing absolute deadline for the first short diagnostic. A separate evidence-triggered earlier end would require an exact source-reviewed private STOP transition and all-five propagation; it must not throw an artificial evaluator exception or skip a guard. Saved diagnostic snapshots remain historical state, not live-state proof. Writer receipts and actual committed owner ACKs must be counted separately; no completed games is still an informative partial, with zero durability/fullunit credit.

Preserve the existing all-three inherited custody, canonical lock identities and exclusions,564 control states, six evaluation STOPs, ordinary PAUSE, compact logical queue snapshot and five stopped checkpoint main/WAL/SHM/journal vectors. Ordinary head14 remains CLOSED+PAUSED. All checks retain current paths, failure order, call timing and owner affinity. No Windows-native verifier implementation, dynamic cache or poll reduction is proposed. Canonical and inherited source/native/model/provider/precision identities remain exact;809's existing arithmetic contract is unchanged.

The final decision must explicitly bind the five descriptor hashes/roster digest;640 quota and320 actors; producer/native/dispatch/writer geometry;8,020,630,528-byte retained credit; unchanged physical/output policy;60+180 horizon; private parent/child/unit/coordinator roots; stop-path union; source/runtime/import/model/custody chain; preserved ordinary snapshot; fresh one-use and expiry. The unchanged overall upper expiry is1792649011.575. Remaining time must be measured at final admission; no clock observation or renewal is implied here.

Existing single-unit adapter/child authorizer bindings intentionally refuse this roster. A distinct minimal five-unit caller must bind the existing APIs, guard and real owner checkpoint ACK path; no new scheduler or ordinary queue registration is needed. Root's separate logical CPU proof and exact source/action review remain prerequisites. Full640-game completion, training admission, numerical equivalence, speed acceptance and production adoption are outside this partial plan.
