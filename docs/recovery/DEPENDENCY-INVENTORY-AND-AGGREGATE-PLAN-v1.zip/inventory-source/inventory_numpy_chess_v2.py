"""UNRUN V2 fixed-root readonly identity inventory; no package import or ELF load."""
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import struct
import sys
import time
import traceback

BASE = Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5')
SITE = Path('/home/josh/.local/lib/python3.10/site-packages')
ROOTS = (SITE/'numpy', SITE/'numpy.libs', SITE/'chess')
SYSTEM = (Path('/usr/lib/x86_64-linux-gnu'), Path('/lib/x86_64-linux-gnu'), Path('/usr/lib64'), Path('/lib64'))
CLOSURE = Path('/tmp/deepfin-pr1110-production-20261021-v1/runtime-v6/scripts/bt4_runtime_closure_v1.json')
CLOSURE_SHA = '9d30112a802059feb4c177ca4efbabd280ebc6e6941eb75f8cb11d3cdfc24bc4'
INTENT = BASE/'bt4-qualification-intake-root-20261021-v1/NUMPY-CHESS-INVENTORY-ONE-USE-INTENT-v1.json'
BOOT = 'e34eff27-d1dc-49c0-bac2-e8525ea1b52f'
ABSENT = (224690,238033,238034,239144,239145,239631,239632,239811,239812,240331,240332,240486,240487)
READ_CAP = 128 << 20
OUT_CAP = 256 << 10
FILE_CAP = 512
DIR_CAP = 256
ENTRY_CAP = 8192
clock = time.monotonic
started = clock()
read_bytes = 0
STATE = {'status':'INCOMPLETE','records':[]}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def checkpoint():
    need(clock()-started < 9, 'inventory internal9s deadline')


def stamp(s):
    return [s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns]


def read_stable(path, limit, digest=None, pseudo=False):
    global read_bytes
    checkpoint()
    path = Path(path)
    need(path.resolve() == path, 'canonical opened input')
    fd = os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        first = os.fstat(fd)
        need(pseudo or stat.S_ISREG(first.st_mode) and first.st_size <= limit, 'bounded regular file')
        parts, count = [], 0
        while True:
            checkpoint()
            request = min(65536,limit-count+1)
            need(request <= READ_CAP-read_bytes, '128MiB explicit named read cap')
            raw = os.read(fd,request)
            read_bytes += len(raw)
            if not raw:
                break
            count += len(raw)
            need(count <= limit,'named file limit')
            parts.append(raw)
        need(pseudo or count == first.st_size and stamp(first) == stamp(os.fstat(fd)) == stamp(path.lstat()),'stable regular input')
        raw = b''.join(parts)
        h = hashlib.sha256(raw).hexdigest()
        need(digest is None or h == digest,'exact accepted source pin')
        return raw,h,stamp(first)
    finally:
        os.close(fd)


def facts():
    boot = read_stable('/proc/sys/kernel/random/boot_id',128,pseudo=True)[0].decode().strip()
    need(boot == BOOT,'actual expected boot')
    mem = read_stable('/proc/meminfo',65536,pseudo=True)[0].decode()
    available = int(next(r.split()[1] for r in mem.splitlines() if r.startswith('MemAvailable:')))*1024
    need(available >= 8 << 30,'MemAvailable8GiB')
    for pid in ABSENT:
        need(not os.path.lexists('/proc/'+str(pid)),'known closed PID must be absent even if reused')
    identities = {(os.major(2096),os.minor(2096),i) for i in (81348917,18835410,18503149)}
    identities.add((os.major(73),os.minor(73),1407374886384886))
    matching = []
    for row in read_stable('/proc/locks',1 << 20,pseudo=True)[0].decode().splitlines():
        for token in row.split():
            parts = token.split(':')
            if len(parts) != 3:
                continue
            try:
                identity = (int(parts[0],16),int(parts[1],16),int(parts[2]))
            except ValueError:
                continue
            if identity in identities:
                matching.append(row)
    need(not matching,'canonical4/original guard lock rows zero')
    return {'boot':boot,'MemAvailable':available,'absent_pids':list(ABSENT),'matching_lock_rows':matching}


def audit(event,args):
    if event == 'open':
        flags = args[2]
        need(not isinstance(flags,int) or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND) == 0,'readonly open')
    need(event not in {'subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.kill','os.killpg','os.remove','os.rename','os.mkdir','os.rmdir','os.link','os.symlink','os.truncate','fcntl.flock','fcntl.lockf','ctypes.dlopen','socket.__new__'},'no child/write/load/signal/lease')
    if event == 'import':
        need(args[0].split('.')[0] in sys.stdlib_module_names,'stdlib imports only; no NumPy/chess import')


def elf_needed(raw):
    need(len(raw) >= 64 and raw[:6] == b'\x7fELF\x02\x01','ELF64 little endian only')
    header = struct.unpack_from('<HHIQQQIHHHHHH',raw,16)
    need(header[1] == 62,'x86_64 ELF only')
    offset,size,count = header[4],header[8],header[9]
    need(size == 56 and 0 < count <= 128 and offset+size*count <= len(raw),'bounded program headers')
    loads,dynamic = [],None
    for i in range(count):
        p = struct.unpack_from('<IIQQQQQQ',raw,offset+i*size)
        need(p[2]+p[5] <= len(raw),'ELF segment file bounds')
        if p[0] == 1:
            loads.append((p[3],p[2],p[5]))
        if p[0] == 2:
            need(dynamic is None,'one dynamic segment')
            dynamic = (p[2],p[5])
    if dynamic is None:
        return [],[]
    doff,dsize = dynamic
    need(dsize % 16 == 0 and dsize//16 <= 4096,'bounded dynamic table')
    entries=[]
    ended=False
    for i in range(dsize//16):
        tag,value=struct.unpack_from('<qQ',raw,doff+16*i)
        if tag == 0:
            ended=True
            break
        entries.append((tag,value))
    need(ended,'terminated dynamic table')
    tabs=[v for t,v in entries if t == 5]
    sizes=[v for t,v in entries if t == 10]
    need(len(tabs) == len(sizes) == 1 and 0 < sizes[0] <= 1 << 20,'one bounded string table')
    offsets=[o+tabs[0]-v for v,o,n in loads if v <= tabs[0] and tabs[0]+sizes[0] <= v+n]
    need(len(offsets) == 1,'mapped dynamic string table')
    table=raw[offsets[0]:offsets[0]+sizes[0]]
    def string(index):
        need(index < len(table),'dynamic string offset')
        end=table.find(b'\0',index)
        need(end >= index and end-index <= 4096,'bounded terminated dynamic string')
        return table[index:end].decode('utf-8','strict')
    needed=[string(v) for t,v in entries if t == 1]
    paths=[string(v) for t,v in entries if t in (15,29)]
    need(len(needed) <= 64 and len(paths) <= 2,'bounded dependencies and rpaths')
    return needed,paths


def inventory():
    roots=[]
    for root in ROOTS:
        need(root.is_dir() and root.resolve() == root,'fixed canonical package root')
        roots.append(root)
    system=tuple(dict.fromkeys(p.resolve() for p in SYSTEM if p.is_dir()))
    allowed=tuple(roots)+system
    def within(p):
        return any(p == root or p.is_relative_to(root) for root in allowed)
    pending=[]
    directories,entries=0,0
    directory_stamps={}
    # Only these three explicit package roots are traversed; never scan system roots.
    for root in roots:
        todo=[(root,0)]
        while todo:
            checkpoint()
            directory,depth=todo.pop()
            directories+=1
            need(directories <= DIR_CAP and depth <= 16,'bounded fixed-root directories')
            directory_stamps[str(directory)]=stamp(directory.lstat())
            names=[]
            with os.scandir(directory) as scan:
                for entry in scan:
                    entries+=1
                    need(entries <= ENTRY_CAP,'bounded fixed-root entries')
                    names.append(entry)
            names.sort(key=lambda e:e.name)
            for entry in names:
                p=Path(entry.path)
                if entry.is_dir(follow_symlinks=False):
                    if entry.name not in ('tests','__pycache__'):
                        todo.append((p,depth+1))
                elif entry.name.endswith('.py') or '.so' in entry.name:
                    need(not entry.is_symlink(),'package source/library symlink refused')
                    pending.append(p)
    records={}
    while pending:
        checkpoint()
        path=pending.pop(0).resolve(strict=True)
        need(within(path),'resolved dependency in fixed roots')
        if str(path) in records:
            continue
        need(len(records) < FILE_CAP,'bounded inventory file count')
        raw,h,s=read_stable(path,64 << 20)
        record={'p':str(path),'n':len(raw),'h':h,'s':s}
        records[str(path)]=record
        STATE['records'].append(record)
        if raw[:4] == b'\x7fELF':
            needed,rpaths=elf_needed(raw)
            search=[path.parent,ROOTS[1]]
            for rpath in rpaths:
                for component in rpath.split(':'):
                    need(component,'no implicit CWD rpath')
                    component=component.replace('${ORIGIN}',str(path.parent)).replace('$ORIGIN',str(path.parent))
                    need('$' not in component and Path(component).is_absolute(),'fixed absolute ORIGIN rpath only')
                    resolved=Path(component).resolve()
                    need(within(resolved),'rpath within fixed roots')
                    search.append(resolved)
            search.extend(system)
            edges=[]
            for name in needed:
                need(name and '/' not in name and '\\' not in name and len(name) <= 255,'needed basename only')
                candidates=[]
                for directory in dict.fromkeys(search):
                    candidate=directory/name
                    if os.path.lexists(candidate):
                        resolved=candidate.resolve(strict=True)
                        need(within(resolved) and resolved.is_file(),'bounded resolved system dependency')
                        candidates.append(resolved)
                unique=tuple(dict.fromkeys(candidates))
                need(len(unique) == 1,'missing or ambiguous fixed-root dependency; no loader guess')
                pending.append(unique[0])
                edges.append([name,str(unique[0])])
            record['elf_needed']=edges
            record['elf_rpaths']=rpaths
    # A final metadata sweep authenticates the whole once-hashed inventory interval.
    for path,s in directory_stamps.items():
        need(stamp(Path(path).lstat()) == s,'package directory changed')
    for record in records.values():
        need(stamp(Path(record['p']).lstat()) == record['s'],'inventory source changed after hashing')
    return records,{'directories':directories,'directory_entries':entries,'package_roots':[str(p) for p in roots],'resolved_system_roots':[str(p) for p in system]}


def main():
    need(sys.version_info[:2] == (3,10) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode,'CP310-I-S-B')
    need(len(sys.argv) == 3,'exact selfsha/intent SHA arguments')
    def timeout(signum,frame):
        raise TimeoutError('external10s timeout; inventory incomplete')
    signal.signal(signal.SIGTERM,timeout)
    for key,value in ((resource.RLIMIT_CPU,10),(resource.RLIMIT_AS,512 << 20)):
        soft,hard=resource.getrlimit(key)
        cap=value if hard == resource.RLIM_INFINITY else min(value,hard)
        resource.setrlimit(key,(cap if soft == resource.RLIM_INFINITY else min(soft,cap),cap))
    sys.addaudithook(audit)
    read_stable(Path(__file__),65536,sys.argv[1])
    before=facts()
    raw=read_stable(INTENT,65536,sys.argv[2])[0]
    intent=json.loads(raw)
    need(type(intent) is dict and set(intent) == {'schema','scope','program_sha256','boot','issued_unix','expires_unix','native_single_use'},'closed inventory intent')
    need(intent['schema'] == 'PR1110_NUMPY_CHESS_INVENTORY_INTENT_V1' and intent['scope'] == 'ONE_FIXED_READONLY_NUMPY_CHESS_INVENTORY' and intent['program_sha256'] == sys.argv[1] and intent['boot'] == BOOT and intent['native_single_use'] is True,'sourcebound inventory intent')
    now=time.time()
    need(type(intent['issued_unix']) in (int,float) and type(intent['expires_unix']) in (int,float) and 0 < intent['expires_unix']-intent['issued_unix'] <= 600 and intent['issued_unix'] <= now and intent['expires_unix']-now >= 11,'fresh600s intent remaining11s')
    closure=json.loads(read_stable(CLOSURE,128 << 10,CLOSURE_SHA)[0])
    records,geometry=inventory()
    for module in ('numpy','numpy.core._multiarray_umath','chess'):
        ref=closure['modules'][module]
        need(ref['path'] in records and records[ref['path']]['h'] == ref['sha256'],'accepted installed module anchor')
    total=sum(r['n'] for r in records.values())
    remaining=READ_CAP-read_bytes
    fits=total+(2 << 20) <= remaining
    enough_time=clock()-started < 3.5
    second=fits and enough_time
    if second:
        for record in records.values():
            read_stable(record['p'],64 << 20,record['h'])
    after=facts()
    read_stable(INTENT,65536,sys.argv[2])
    read_stable(CLOSURE,128 << 10,CLOSURE_SHA)
    for record in records.values():
        need(stamp(Path(record['p']).lstat()) == record['s'],'final inventory file identity differs')
    STATE.update(status='COMPLETE_FIXED_ROOT_IDENTITY_INVENTORY',facts_before=before,facts_after=after,geometry=geometry,file_count=len(records),unique_file_bytes=total,twice_hash_fits_remaining_read_budget=fits,second_full_hash_performed=second,identity_mode='full_second_hash' if second else 'one_full_hash_plus_stable_file_and_directory_stamps',explicit_named_read_bytes=read_bytes,elapsed_seconds=clock()-started,no_imports_or_dlopen=True,child_processes=0,guest_writes=0,source_scope='All .py and .so-named files under fixed NumPy/numpy.libs/chess excluding tests and __pycache__; conservative source/ELF inventory, not dynamically observed normal-import module closure.',elf_scope='ELF64 x86_64 DT_NEEDED recursion under fixed roots; unresolved/ambiguous/RPATH-escape refuses. No ldd/loader invocation. Does not authenticate global loader configuration/preloads or prove which native objects a future normal import actually maps.')


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        STATE.update(status='INCOMPLETE_SOURCE_HOLD',primary_error_type=type(error).__name__,primary_error_message=str(error)[:2048],explicit_named_read_bytes=read_bytes,elapsed_seconds=clock()-started)
        try:
            STATE['facts_after_failure']=facts()
        except BaseException as after_error:
            STATE['facts_after_failure_unavailable']=type(after_error).__name__+': '+str(after_error)[:512]
        traceback.print_exc()
    raw=json.dumps(STATE,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    if len(raw)+1 > OUT_CAP:
        raw=json.dumps({'status':'INCOMPLETE_SOURCE_HOLD','error':'inventory exceeds256KiB output; no complete roster exported','file_count':len(STATE['records']),'explicit_named_read_bytes':read_bytes},sort_keys=True).encode()
        STATE['status']='INCOMPLETE_SOURCE_HOLD'
    sys.stdout.buffer.write(raw+b'\n')
    sys.stdout.buffer.flush()
    raise SystemExit(0 if STATE['status'] == 'COMPLETE_FIXED_ROOT_IDENTITY_INVENTORY' else 1)
