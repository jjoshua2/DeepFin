# Bounded phase timing — SOURCE ONLY, UNRUN

New source files are bounded_phase_timer_v1.py, targeted_diagnostics_v5.py,
test_phase_timing_v1.py and phase_termination_child_v1.py. Frozen helper V4 is
unchanged. V5 copies its mandatory entered/first-pre/first-post durability,
17-slot/4MiB conservative byte caps, original execute-wall accumulator and V2
quiescence/primary-error ownership behavior. Dependencies are frozen V1/V2,
not V4 at import. No profiler, new watcher thread, scheduler, guard removal,
control bypass, custody change, deadline widening or model action is introduced.

API: PhaseBinding(target_class, method_name, phase) is exported by the timer.
V5 accepts phase_bindings tuple (<=32) and phase_source_pins closed map (<=16
canonical absolute <=1MiB source files). Actual descriptor and unwrap-chain
code filenames must belong to this map; every support source is hash/stamp
authenticated before patches. staticmethod/classmethod descriptors are retained.
Do not bind transaction/contextmanager protocol: checkpoint label covers actual
begin/record_game/finish/close bodies. Outer/retained guard are the actual supplied
instances' classes; no proxy guard or duplicate child import is used. Original
bound methods are invoked once with unchanged objects/arguments/affinity/errors.

Fixed17 labels: outer_guard, retained_guard, control_owner_direct,
control_offowner_wait, control_service, control_invoke, driver_advance,
native_advance, native_prepare, native_apply, publish, settle_cpu, writer_commit,
checkpoint, execute, runner_wait, diagnostics_io. Special binding control_request
for actual OwnerThreadCallbacks.__call__ observationally selects owner versus
off-owner from the same instance._owner. runner_wait on actual runner.__init__
installs only that newly created _wake Event instance's wait; Event identity is
unchanged. No Event/Future global patch. Other result.wait callbacks remain
unmeasured. Event-wait installation errors preserve the original initializer
result and mark observation error. All added methods/wait observers remain
owned until V2 quiescence allows restoration, before V1 method restoration.

Timer owns <=16 Thread-object registries and depth<=16 stacks; thread objects
avoid ident-reuse aliasing. No per-call trace is stored. It reports17 closed
phase records, bounded errors and bounded open frames (<=60000-byte nested
phase report, otherwise explicit invalid/omitted detail). No per-thread closed
matrix is exported. Existing196608-byte full-snapshot guard remains: oversized
snapshot fails/records error rather than widening publication/output limits.

counts calls/returns/raises describe wrapper attempts/outcomes. original_entered
marks reaching the original invocation boundary, not proof of model work or
completion. Every frame has that flag, start monotonic and open historical wall
elapsed. Open CPU elapsed is recorded only when snapshot caller is the frame's
own thread; other threads are null. Open exclusive time is not inferred.
Completed inclusive/self-exclusive wall and thread_time_ns subtract only direct
same-thread children. Recursion counts each invocation; cross-thread overlap is
never subtracted. Unknown child intervals invalidate parent self accounting.
Clock/capacity failures mark integrity invalid but still invoke original once.
Inclusive phase sums overlap and are not an elapsed-wall partition. Thread CPU
excludes other native/OpenMP threads, descendants and GPU, and does not identify
an I/O cause. Parent family CPU/RSS/PSS remains separate.

Phase wrappers opportunistically checkpoint before original entry and after
completion on the existing caller, outside timer/event locks. Snapshot may thus
preserve an open pending frame, not proof the body was entered or still runs at
closure. No cadence is guaranteed during a blocked/no-callback interval. Phase
inclusive timing includes pre-call checkpoint instrumentation; directly nested
diagnostics_io subtracts for self-exclusive timing. Even no-op cadence checks
have observer overhead. Legacy execute-wall still starts immediately before
original execute and ends before post-publication. The first pending execute
snapshot and first post remain forced as in V4; no original guard is skipped.

CPU API: run_source_controls(case_root) returns exactly nine IDs:

1. nested_recursion_wall_and_thread_cpu_exact
2. concurrent_overlap_never_cross_thread_subtracted
3. clock_and_depth_failures_preserve_target_calls_errors
4. guard_checkpoint_descriptors_and_owned_wait_restore
5. actual_owner_callbacks_guard_once_affinity_primary_error
6. phase_ownership_retained_until_quiescent
7. mandatory_execute_gate_and_due_pending_phase_snapshot
8. phase_source_authentication_before_patch
9. fixed_pure_call_overhead_report_no_noise_threshold

Actual callback control imports only the exact pinned four-file pure Python
package from accepted runtime-v5: chess_anti_engine __init__, async_safety,
request_routing, staged_execution (affinity source a02bc7...); no full project,
conftest, Torch/NumPy/model/native import. Two off-owner rendezvous plus one direct
owner request call the original guard exactly once each on the same owner;
original failure identity survives. Three controlled test threads total are
joined; no additional processes in source controls. OVERHEAD_REPORT contains
three rounds,2000 direct versus2000 timer-core-wrapped pure calls each, raw wall/
CPU and added ns/call; no noise-sensitive speed threshold or model/host overhead
promise. It measures timer core, not the complete phase hook/snapshot system.

run_termination_controls(case_root, run_owned_termination) returns exactly:

1. owned_SIGTERM_inside_guard_after_pending_phase_ack
2. owned_SIGKILL_inside_guard_after_pending_phase_ack

Callback interface stays (pinned_child, snapshot_path, signum)->ack/returncode/
kernel_ECHILD; ACK has durable_snapshot/sha256/pid. Test child uses only stdlib,
timer and helpers V1/V2/V5 (no actual callback package). It makes its isolated
cadence due, enters one original test-owned guard on the owner, verifies durable
slot1 contains open outer_guard original_entered=false captured before body,
then ACKs inside the actual guard body and blocks. Runner owns exact PIDfd/Popen
signals, bounded streams and finally reap/ECHILD, exactly two sequential owned
children. No production PID is accepted. Historical snapshot need not claim
body entered even though ACK source proves the later test body entry.

Controller author separately binds parent/childCPU10,AS512MiB,60+30 wall,
CPU29,30/nice19/numeric2/hiddenCUDA,16MiB named-read/4MiB aggregate owned-output/
1MiB stream caps, protected exact identities and absent private root before any
stage. Old/new processes, grants and source remain untouched. Reader successor
must explicitly export nested phase_timing or prior reader will omit it.
No imports/tests/compilation/child/model/GPU/guest action occurred in authoring.

Phase inclusive wall includes pre-call checkpoint instrumentation; self excludes directly nested diagnostics_io intervals, while cadence-noop bookkeeping remains included. Overhead evidence has separate three-round 2000-call timer-core and actual Guard phase-wrapper/cadence-noop arms, without timing thresholds or model generalization. Observer event installation is serialized independently of original runner initialization; observation failures preserve original returns/errors.
