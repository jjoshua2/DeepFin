"""SOURCE-ONLY lower-only metadata entry; no target import or launch authority."""
import hashlib
import os
from pathlib import Path
import resource
import runpy
import stat
import sys

CONSTRUCTOR = Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-sixty-second-diagnostic-draft-v1/construct_diagnostic_metadata_60s_v2.py')
CTOR_SHA = '0dbc757b55b1d2cbb4e57d3d110d26d09dfac1a4d52ad787873317b4f44e3810'
FINAL_INPUT = CONSTRUCTOR.parent / 'DIAGNOSTIC-60-INPUTS-FINAL-v1.json'


def need(ok, message):
    if not ok:
        raise ValueError(message)


def pinned(path, expected):
    need(path.resolve() == path, 'canonical exact metadata entry input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= 1 << 20, 'small pinned metadata entry input')
        raw = os.read(fd, before.st_size + 1)
        after, named = os.fstat(fd), path.lstat()
        stamp = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
        need(len(raw) == before.st_size and stamp(before) == stamp(after) == stamp(named)
             and hashlib.sha256(raw).hexdigest() == expected, 'metadata entry source/input hash mismatch')
    finally:
        os.close(fd)


need(sys.version_info[:2] == (3, 10) and sys.flags.isolated and sys.flags.no_site
     and sys.flags.dont_write_bytecode and sys.flags.optimize == 0, 'isolated nonoptimized CP310')
need(hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest() ==
     'a2f33a6e006989270f4340528eb61f8f97366e00a5d1b602ac8672ea44fc56ae', 'qualified metadata interpreter')
need(len(sys.argv) == 5 and sys.argv[1] == '--inputs' and sys.argv[3] == '--inputs-sha256'
     and Path(sys.argv[2]) == FINAL_INPUT and len(sys.argv[4]) == 64
     and all(value in '0123456789abcdef' for value in sys.argv[4]), 'closed fixed final-input argv')
for kind, bound in ((resource.RLIMIT_CPU, 10), (resource.RLIMIT_AS, 512 << 20)):
    soft, hard = resource.getrlimit(kind)
    resource.setrlimit(kind, (min(value for value in (soft, bound) if value >= 0),
                              min(value for value in (hard, bound) if value >= 0)))
os.umask(0o077)
pinned(CONSTRUCTOR, CTOR_SHA)
pinned(FINAL_INPUT, sys.argv[4])
sys.argv = [str(CONSTRUCTOR), *sys.argv[1:]]
runpy.run_path(str(CONSTRUCTOR), run_name='__main__')
