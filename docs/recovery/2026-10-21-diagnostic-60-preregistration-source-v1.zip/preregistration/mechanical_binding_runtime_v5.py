"""Inactive source-composition tool; never launches or acquires custody.

Root must separately authenticate the actual runtime/helper/model/provider and
q closure, full packet/action review, finite budgets and live preservation gates.
The returned source requires independent review before any import or execution.
There is deliberately no CLI, parent runner, q substitute or activation switch.
"""
from __future__ import annotations

import hashlib
from collections.abc import Mapping


RETAINED_SHA256 = "186bcd3f0e0918dac64d018ac78c74d2516b037f4cec822a06a14c67b9507964"
RUNTIME = "/tmp/deepfin-pr1110-production-20261021-v1/runtime-v5"
OLD_RUNTIME = "/tmp/bt4-rolling-hotpath320-runtime-20261018-v1"
OLD_ADAPTER = "ba3935ae7e436ac5a9c72165618069d6336412e2404c6182d8332c8f1b1b5307"
OLD_INHERITED = "c58edc55a5eb102993a99500cde35d3e365eab078fc89ae672a44a92542a97d1"


def _digest(value: str) -> None:
    if len(value) != 64 or any(character not in "0123456789abcdef" for character in value):
        raise ValueError("exact lowercase source SHA256 required")


def compose_source(
    retained_source: bytes, *, adapter: Mapping[str, str], inherited: Mapping[str, str],
) -> bytes:
    """Change only the retained helper's three reviewed binding constants.

    Missing exact references refuse composition. Supplying references authorizes
    neither runtime use nor a finite action: this function only returns bytes.
    No owner, settlement, lock, signal, claim or cleanup logic is rewritten.
    """
    if hashlib.sha256(retained_source).hexdigest() != RETAINED_SHA256:
        raise ValueError("retained custody source differs")
    for reference, name in ((adapter, "bt4_queue_consumer_v2.py"),
                            (inherited, "bt4_inherited_owner_v2.py")):
        if set(reference) != {"path", "sha256"} or reference["path"] != RUNTIME + "/scripts/" + name:
            raise ValueError("exact future runtime source reference required")
        _digest(reference["sha256"])
    replacements = (
        (f"INTEGRATED_RUNTIME = Path('{OLD_RUNTIME}')", f"INTEGRATED_RUNTIME = Path('{RUNTIME}')"),
        (f"ADAPTER_SHA256 = '{OLD_ADAPTER}'", f"ADAPTER_SHA256 = '{adapter['sha256']}'"),
        (f"INHERITED_SHA256 = '{OLD_INHERITED}'", f"INHERITED_SHA256 = '{inherited['sha256']}'"),
    )
    source = retained_source
    for before, after in replacements:
        old, new = before.encode("ascii"), after.encode("ascii")
        if source.count(old) != 1:
            raise ValueError("unique retained binding declaration required")
        source = source.replace(old, new, 1)
    return source
