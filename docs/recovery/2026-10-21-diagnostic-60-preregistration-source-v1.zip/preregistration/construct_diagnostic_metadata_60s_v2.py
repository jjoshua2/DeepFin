"""SOURCE-ONLY metadata constructor; never executes its emitted packets.

Stdlib JSON/hash reads and create-only metadata output. No target import,
descriptor registration, queue/controls mutation, model read, lease or child.
Root must separately review/admit even this constructor. Final one-use launch
authority is issued AFTER the immutable parent packet, never embedded in it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import stat
import time

RUNTIME = "/tmp/deepfin-pr1110-production-20261021-v1/runtime-v5"
OPERATIONS = "/home/josh/chess-artifacts/operations"
PRIVATE = OPERATIONS + "/bt4-pr1110-correctness-private-20261021-v4"
METADATA_PARENT = "/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-qualification-intake-root-20261021-v1"
EXPIRY = 1792649011.575
BOOT = "e34eff27-d1dc-49c0-bac2-e8525ea1b52f"
OWNER = {"pid": 224690, "start_ticks": 45987470, "boot_id": BOOT}
MODEL = {"path": "/home/josh/chess-artifacts/bt4-fp16-conversion-20261018-v1/attempt-01/BT4-it332-vanilla-winner.fp16-internal-fp32-io.onnx",
         "sha256": "809db9c3c8063683bf8e7c08de8fec92ea4e37ad8c68c8b1befbde4bd1958961"}
PRECISION_SHA = "ba3f35e768a9e64c1417856b176526e463b466898b1d3b42f80734d150cc4af4"
PROVISIONAL_SHA = "c769ceef3cf2abfb95185c0db2b79fe01b8e6ff171572c19ac5b65f3f5d5c6e3"
BUNDLE_SHA = "3a9a92ec72b74f86e8b948acc196dcaee03a3759fe034a59c361ef6e344fc12d"
COPY_REVIEW_SHA = "de9c76ec0104212ff246f01b142225701decbb2f1aff523b0497264ff39e130d"
CLOSURE_SHA = "a492d9ad8c7480957e28c1503eb6cba7316816c6aae1514892d8db0d0bd34d3f"
CHILD_SHA = "d96826ca415b35fbcdb43317b6a8b96f668cd655f099b407122bcbcb9658991e"
ADAPTER_SHA = "79b1c8dc6c24d038c9609b574376eb2455b237867a30da3176fd6a0560b8edb3"
PARENT_SHA = "2a465f8ecb1948e6bd8fc00038208b9cee3cdee95cdfc5182b2fc0e2fb28275b"
ACTUAL_REPORT_PATH = "/tmp/deepfin-pr1110-production-20261021-v1/RUNTIME-COPY-ACTUAL-v6.json"
NATIVE_ACTUAL_REPORT_PATH = METADATA_PARENT + "/RUNTIME-COPY-V6-ACTUAL-stdout.json"
COPY_REVIEW_SCHEMA = "PR1110_RUNTIME_COPY_V6_INDEPENDENT_ACTUAL_REVIEW_V1"
# Canonical420 Git blob bytes; author9e306/worktree CRLF bytes are distinct.
OWNER_SOURCE_SHA = "a77c2d9c05a60eddfb44dfb7604ea31c7c85d965bf8da82d452aa0e1104a153f"
# Exact retained PREPARED.json exclusion_locks, provenancea6ee4d04...; these
# three OFDs are distinct from all canonical3 and ordinary queue supervisor.
EXCLUSIONS = [
    "/home/josh/chess-artifacts/operations/bt4-local-continuous-newboot-20261013-v1/supervisor.lock",
    "/home/josh/chess-artifacts/operations/bt4-local-continuous-operational-20261008-v2/supervisor.lock",
    "/mnt/c/Users/jjosh/Documents/Codex/2026-10-08/task/bt4-reserve-staged-stock-append-20261013-v5/staging-operator.lock",
]
SOURCES = {"parent", "mechanical_binding", "retained_custody", "bound_custody",
           "owner_helper", "settlement", "child", "adapter", "outer_launcher"}
GATES = {"source_review", "cpu_and_native_qualification", "runtime_import_closure",
         "model_precision_provider_contract", "resources_and_accounting",
         "child_claim_before_target_imports", "paused_state_guard_interface",
         "parent_and_child_lifecycle_review", "user_authority"}
PREPARATION = {"source_review", "action_review", "resource_decision", "paused_restoration_plan"}
GEOMETRY = {"units": 1, "games": 128, "max_plies": 400, "actors": 64,
            "target_rows": 64, "max_rows": 64, "active_seconds": 60, "cleanup_seconds": 180}
# These numbers are a fixed PROPOSAL. A preparation budget review and final
# independent exact action/resource gate are mandatory; this source grants none.
BUDGET_PROPOSAL = {
    "metadata_read_bytes": 64 << 20, "preflight_seconds": 30,
    "min_memory_bytes": 16 << 30, "min_disk_bytes": 8 << 30,
    "max_stream_bytes": 1 << 20, "max_output_bytes": 512 << 20,
    "family_cpu_seconds": 360, "child_cpu_seconds": 300,
    "family_rss_bytes": 8 << 30, "family_pss_bytes": 6 << 30,
    "child_file_bytes": 32 << 20, "child_as_bytes": None, "process_as_bytes": None,
    "sample_interval_ms": 100, "max_family_processes": 64,
}


def need(ok, why):
    if not ok:
        raise ValueError(why)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def reference(value):
    need(type(value) is dict and set(value) == {"path", "sha256"}, "exact metadata reference")
    need(type(value["path"]) is str and PurePosixPath(value["path"]).is_absolute()
         and PurePosixPath(value["path"]).as_posix() == value["path"]
         and ".." not in PurePosixPath(value["path"]).parts, "canonical absolute metadata reference")
    need(type(value["sha256"]) is str and re.fullmatch("[0-9a-f]{64}", value["sha256"]), "exact SHA256")
    return value


class Reads:
    """Only explicitly listed bounded metadata documents; no payload traversal."""

    def __init__(self):
        self.remaining = 64 << 20

    def checked(self, ref):
        reference(ref)
        path = Path(ref["path"])
        need(path.resolve() == path, "canonical named metadata")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            before = os.fstat(fd)
            need(stat.S_ISREG(before.st_mode) and before.st_size <= min(16 << 20, self.remaining), "bounded metadata input")
            raw = os.read(fd, before.st_size + 1)
            after, named = os.fstat(fd), path.lstat()
            key = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
            need(len(raw) == before.st_size and key(before) == key(after) == key(named) and sha(raw) == ref["sha256"], "metadata input changed")
            self.remaining -= len(raw)
            return raw
        finally:
            os.close(fd)


def runtime_data(bundle, review):
    need(type(bundle) is dict and type(bundle.get("files")) is list and len(bundle["files"]) == 2, "exact two-record runtime bundle")
    decoded, records = {}, {}
    for record in bundle["files"]:
        raw = record["raw"].encode()
        need(len(raw) == record["bytes"] and sha(raw) == record["sha256"], "embedded raw proof identity")
        decoded[record["path"]] = json.loads(raw)
        records[record["path"]] = record
    actual_path = ACTUAL_REPORT_PATH
    closure_path = RUNTIME + "/scripts/bt4_runtime_closure_v1.json"
    need(set(decoded) == {actual_path, closure_path}, "accepted distinct runtime-v5 paths")
    actual, closure = decoded[actual_path], decoded[closure_path]
    need(actual["root"] == RUNTIME and actual["closure_sha256"] == CLOSURE_SHA
         and actual["source_only"] is True and actual["model_gpu_queue_actions"] is False,
         "accepted source-only copy proof")
    # Actual-copy review shape is joined honestly to its exact native raw record.
    # This draft remains unbound until the new independent review exists.
    need(review["schema"] == COPY_REVIEW_SCHEMA
         and review["status"] == "ACCEPT_SOURCE_COPY_READBACK_ONLY" and review["findings"] == []
         and review["actual_ref"] == {"path": NATIVE_ACTUAL_REPORT_PATH, "sha256": records[actual_path]["sha256"]}
         and review["target_root"] == RUNTIME and review["closure_sha256"] == CLOSURE_SHA
         and review["payload_count"] == 615 and review["payload_bytes"] == 17988980
         and review["runtime_readback_member_count"] == 616,
         "exact native review/guest raw bytes SHA join; source copy only, never model qualification")
    need(actual["files"] == 615 and actual["bytes"] == 17988980
         and actual["source_commit"] == "42027482a7091ddbd2c8bc98e266b3ac3afbb744"
         and actual["old_runtime_revalidated_unchanged"] is True
         and actual["target_tests_executed"] is False and actual["git_or_child_started"] is False,
         "exact accepted613 plus helperV4 and diagnosticadapter, source-only")
    pins = actual["runtime_files"]
    need(type(pins) is dict and len(pins) == 616 and pins["scripts/bt4_runtime_closure_v1.json"] == CLOSURE_SHA, "complete616 readback dict")
    need(pins.get("scripts/shared_teacher_owner.py") == OWNER_SOURCE_SHA, "exact composed canonical420 startup correction")
    need(len(closure["repo_sources"]) == 615 and all(pins.get(key) == value for key, value in closure["repo_sources"].items()), "closure source/readback join")
    diagnostic = {
        "targeted_diagnostics_v1": "48dc44768aabdc4e18c4314abeeaefdb255e65ea54150c6b0d04285d36332a22",
        "targeted_diagnostics_v2": "444bf23fcd1850efcacd55bb888e7d275e3a02bde3846c80bf0813cecc336bb3",
        "finite_roster_adapter_v3": "e9eef16db86884dc7399566b094ae00a272580cdd390b2a397f231bcd5a5e3f1",
        "finite_roster_adapter_v4": "6b7632488c6c079bb287d4887937c212ad024dce757b3e6a6c4821eb1eabaa5a",
        "targeted_diagnostics_v4": "998061bfe81aaf49eca04a71dbf5bdf1fe573f2877da340d4c143bce71249993",
        "finite_diagnostic_adapter_60s_v2": "79b1c8dc6c24d038c9609b574376eb2455b237867a30da3176fd6a0560b8edb3",
    }
    need(len(closure["modules"]) == 43, "all43 real runtime/helper origins")
    for name, digest in diagnostic.items():
        need(pins.get(name + ".py") == digest
             and closure["modules"][name]["path"] == RUNTIME + "/" + name + ".py"
             and closure["modules"][name]["sha256"] == digest,
             "normal diagnostic+adapter source/import closure join")
    need(closure["provisional_arithmetic_contract"]["model_sha256"] == MODEL["sha256"]
         and closure["provisional_arithmetic_contract"]["arithmetic_precision"] == "fp16"
         and closure["provisional_arithmetic_contract"]["raw_values_cast_or_normalized"] is False,
         "existing closed model arithmetic contract")
    return pins, closure


def construct(inputs, documents):
    """Pure data joins; does not import/call parent, child, adapter or runtime."""
    need(set(inputs) == {"schema", "attempt", "issued_unix", "expires_unix", "metadata_output",
                         "scope_sha256", "documents", "sources", "gates", "preparation_refs", "child_env", "exclusion_paths"}
         and inputs["schema"] == "PR1110_FINITE_METADATA_INPUTS_V1", "closed constructor inputs")
    need(all(type(value) is str and re.fullmatch("[0-9a-f]{64}", value)
             for value in (BUNDLE_SHA, COPY_REVIEW_SHA, CLOSURE_SHA, PARENT_SHA)),
         "SOURCE-ONLY draft: actualcopy/closure/review/parent remain unbound")
    attempt = inputs["attempt"]
    need(type(attempt) is str and re.fullmatch("[A-Za-z0-9-]{1,96}", attempt), "one-use attempt name")
    issued, expires = inputs["issued_unix"], inputs["expires_unix"]
    need(all(type(value) in (int, float) and math.isfinite(value) for value in (issued, expires))
         and 0 < issued < expires <= EXPIRY, "unchanged finite absolute expiry")
    metadata = inputs["metadata_output"]
    need(metadata == METADATA_PARENT + "/prepared-finite-" + attempt, "fresh owned-Windows metadata-only destination")
    parent_out = OPERATIONS + "/pr1110-finite-" + attempt
    sources = dict(inputs["sources"])
    need(set(sources) == SOURCES and set(inputs["gates"]) == GATES and set(inputs["preparation_refs"]) == PREPARATION,
         "closed source/gate/preparation input roles")
    for group in (sources, inputs["gates"], inputs["preparation_refs"]):
        for ref in group.values():
            reference(ref)
    need(sources["parent"]["sha256"] == PARENT_SHA and sources["child"]["sha256"] == CHILD_SHA
         and sources["adapter"]["sha256"] == ADAPTER_SHA, "distinct reviewed60s/runtime-v5/private-v4 parent+child+diagnosticadapter only")
    need(inputs["documents"]["runtime_bundle"]["sha256"] == BUNDLE_SHA
         and inputs["documents"]["runtime_copy_review"]["sha256"] == COPY_REVIEW_SHA,
         "fixed accepted runtime metadata inputs")
    pins, closure = runtime_data(documents["runtime_bundle"], documents["runtime_copy_review"])
    capture = documents["capture"]
    need(capture["schema"] == "PR1110_CLOSED_PAUSED_METADATA_CAPTURE_V1" and capture["boot_id"] == BOOT
         and capture["old_birth_absent"] is True and capture["ordinary_owner"] == OWNER,
         "actual CLOSED+PAUSED observation required")
    need(sha(canonical(capture["snapshot"])) == capture["snapshot_sha256"], "captured SQL logical snapshot join")
    need(all(type(row.get("item_sha256")) is str and re.fullmatch("[0-9a-f]{64}", row["item_sha256"])
             and "item" not in row for row in capture["snapshot"]["jobs"]), "compact exact item-byte projection required")
    captured_jobs = {row["id"]: row for row in capture["snapshot"]["jobs"]}
    need(set(capture["stopped_items"]) == {f"bt4-u{unit:012d}-a00" for unit in range(4152, 4157)}
         and all(type(item) is str and sha(item.encode("utf-8")) == captured_jobs[job_id]["item_sha256"]
                 for job_id, item in capture["stopped_items"].items()), "five actual stopped specs/compact digests join")
    controls = capture["controls"]
    need(len(controls) == 564 and len({state["path"] for state in controls}) == 564
         and len(capture["evaluation_stops"]) == 6 and capture["pause"] == OPERATIONS + "/bt4-local-continuous-postboot-20261015-v1/PAUSE", "exact564/sixSTOP/ordinaryPAUSE")
    need(capture["fixed_refs"]["controls"]["sha256"] == "7ccf636c67e862e01670a8d45a0588bf8f5d3844681339afa0d2da6fdd2c72dd", "retained union roster")
    checkpoints = capture["stopped_units"]
    need([row["unit"] for row in checkpoints] == list(range(4152, 4157)), "five exact stopped unit observations")
    for row in checkpoints:
        need(row["job_id"] == f"bt4-u{row['unit']:012d}-a00", "stopped unit job identity")
        reference(row["descriptor_ref"])
        proof = row["component_proof"]
        need(type(proof) is dict and set(proof) == {"main", "sidecars"}, "closed main+sidecar proof")
        main = reference(proof["main"])
        need(main["path"].startswith(OPERATIONS + "/")
             and main["path"].endswith(f"/unit-{row['unit']:012d}/checkpoint.sqlite"), "retained exact unit checkpoint")
        need(type(proof["sidecars"]) is list
             and [state["suffix"] for state in proof["sidecars"]] == ["-wal", "-shm", "-journal"], "exact ordered component suffixes")
        for state in proof["sidecars"]:
            need(type(state) is dict and set(state) == {"suffix", "present", "sha256"}
                 and type(state["present"]) is bool, "closed checkpoint component state")
            if state["present"]:
                reference({"path": main["path"] + state["suffix"], "sha256": state["sha256"]})
            else:
                need(state["sha256"] is None, "absent component cannot carry a digest")
    # Inputs are observations, not a claim of future freshness. The actual parent
    # repeats kernel/canonical freedom, snapshot, marker and headroom gates.
    received = capture["observed_rlimits_before_observer_bounds"]
    need(set(received) == {"CPU", "AS", "FSIZE"} and received["CPU"] == [-1, -1], "sole settlement parent must not inherit CPU hardkill")
    resources = dict(BUDGET_PROPOSAL, accounting_source=sources["parent"],
                     inherited_as_limit=received["AS"], received_parent_rlimits=received)
    exclusions = inputs["exclusion_paths"]
    need(type(exclusions) is list and exclusions == EXCLUSIONS
         and len(exclusions) == len(set(exclusions))
         and all(type(path) is str and PurePosixPath(path).is_absolute() for path in exclusions)
         and not set(exclusions) & {state["path"] for state in controls},
         "exact retained three exclusion lock OFDs; NEVER marker/control paths")
    snapshot_ref = {"path": metadata + "/ORDINARY-SNAPSHOT.json", "sha256": capture["snapshot_sha256"]}
    parent_aborts = [parent_out + "/" + name for name in ("STOP", "PAUSE", "CANCEL")]
    aborts = [PRIVATE + "/" + name for name in ("STOP", "PAUSE", "CANCEL")]
    aborts += ["/home/josh/projects/chess/chess_anti_engine/operations/DEEPFIN_STOP", *parent_aborts]
    generation = {"parallel_games": 64, "temperature": 1.0,
                  "initial_fen": "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
                  "syzygy_path": "/home/josh/projects/chess/data/syzygy_3-4-5:/home/josh/projects/chess/data/syzygy_6"}
    need(type(inputs["scope_sha256"]) is str and re.fullmatch("[0-9a-f]{64}", inputs["scope_sha256"]), "reviewed private scientific scope")
    descriptor = {
        "schema_version": 3, "boot_id": BOOT, "unit": 0, "seed_base": 7000000000002000000,
        "output_root": PRIVATE + "/unit-000000000000/attempt-00",
        "checkpoint_path": PRIVATE + "/unit-000000000000/checkpoint.sqlite",
        "bindings": {"model_sha256": MODEL["sha256"], "source_pins": pins, "generation": generation,
                     "seed_base": 7000000000002000000},
        "checkpoint_limits": {"max_attempts": 1, "unit_seconds": 60, "unit_io_bytes": 1,
                              "unit_output_bytes": 512 << 20, "total_seconds": 60,
                              "total_io_bytes": 1, "total_output_bytes": 512 << 20},
        "owner_limits": {"deadline_unix": "QUEUE_ACTUAL_START_PLUS_BLOCK_SECONDS", "physical_io_bytes": 1,
                         "minimum_disk_bytes": 1, "output_bytes": 512 << 20},
        "source_pins": pins, "stop_paths": aborts, "yield_paths": [], "prior_roots": [],
        "generation": generation, "external_root": PRIVATE, "attempt": 0,
        "scope_sha256": inputs["scope_sha256"], "block_seconds": 60,
    }
    need(sources["adapter"]["path"] == RUNTIME + "/finite_diagnostic_adapter_60s_v2.py", "normal runtime diagnostic adapter path")
    prep = inputs["preparation_refs"]
    adapter = {"status": "APPROVED_EXACT_PRIVATE_60S_DIAGNOSTIC_ONLY", "operational_ready": True,
               "descriptor": descriptor, "descriptor_sha256": sha(canonical(descriptor)), "expires_unix": expires,
               "independent_action_review_ref": prep["action_review"],
               "root_resource_decision_ref": prep["resource_decision"],
               "paused_restoration_plan_ref": prep["paused_restoration_plan"],
               "runtime_closure_ref": {"path": RUNTIME + "/scripts/bt4_runtime_closure_v1.json", "sha256": CLOSURE_SHA}}
    precision, provisional = inputs["documents"]["precision"], inputs["documents"]["provisional_authority"]
    need(precision["sha256"] == PRECISION_SHA and provisional["sha256"] == PROVISIONAL_SHA, "original809 precision/provisional refs")
    origins = {name: {key: pin[key] for key in ("path", "sha256")} for name, pin in closure["modules"].items()}
    native = {relative: {"path": RUNTIME + "/" + relative, "sha256": digest}
              for relative, digest in pins.items() if relative.endswith(".so")}
    need(len(native) == 5, "five fresh candidate native images")
    child = {
        "schema": "PR1110_FINITE_CHILD_PACKET_V1", "status": adapter["status"], "operational_ready": True,
        "adapter_packet": adapter,
        "runtime": {"source_root": RUNTIME, "interpreter": {key: closure["python"][key] for key in ("path", "sha256")},
                    "child": sources["child"], "adapter": sources["adapter"], "custody": sources["bound_custody"],
                    "model": MODEL, "precision_ref": precision, "provisional_authority_ref": provisional,
                    "closure_ref": {"path": RUNTIME + "/scripts/bt4_runtime_closure_v1.json", "sha256": CLOSURE_SHA},
                    "provider_pins": {path: {"path": path, "sha256": digest} for path, digest in closure["runtime_files"].items()},
                    "native_pins": native, "python_paths": ["/home/josh/.local/lib/python3.10/site-packages"],
                    "origin_pins": origins, "read_bytes": 8 << 30},
        "controls": {"preserved": controls, "ordinary_pause": capture["pause"],
                     "evaluation_stops": capture["evaluation_stops"], "abort_paths": aborts},
        "guard_limits": {"physical_io_bytes": 1, "minimum_disk_bytes": 1, "output_bytes": 512 << 20},
        "binding_refs": prep,
    }
    child_ref = {"path": metadata + "/CHILD-PACKET.json", "sha256": sha(canonical(child))}
    parent_sources = {key: value for key, value in sources.items() if key != "adapter"}
    parent_sources.update(child_packet=child_ref, interpreter=child["runtime"]["interpreter"])
    parent = {"schema": "PR1110_FINITE_CORRECTNESS_PARENT_PACKET_V1", "attempt": attempt,
              "issued_unix": issued, "expires_unix": expires, "sources": parent_sources,
              "gates": inputs["gates"], "runtime_sources": pins, "geometry": GEOMETRY,
              "resources": resources,
              "preservation": {"former_owner": OWNER, "snapshot": snapshot_ref, "controls": controls,
                               "evaluation_stops": capture["evaluation_stops"], "pause": capture["pause"],
                               "stopped_units": [row["component_proof"] for row in checkpoints]},
              "outputs": {"root": parent_out, "child": PRIVATE}, "exclusion_paths": exclusions,
              "child_argv": [child["runtime"]["interpreter"]["path"], "-I", "-S", "-B", sources["child"]["path"],
                             "--packet", child_ref["path"], "--packet-sha256", child_ref["sha256"]],
              "child_env": inputs["child_env"], "abort_paths": parent_aborts}
    summary = {"schema": "PR1110_PREPARED_METADATA_NOT_LAUNCH_AUTHORITY_V1",
               "runtime_closure_sha256": CLOSURE_SHA, "capture_ref": inputs["documents"]["capture"],
               "parent_packet": {"path": metadata + "/PARENT-PACKET.json", "sha256": sha(canonical(parent))},
               "child_packet": child_ref, "preparation_reference_meaning": "Scope/lifecycle and budget PLAN review only",
               "final_action_gate": "Root must issue distinct exact parent --action-review plus one-use resource authority AFTER these immutable packet hashes",
               "model_first": "Current provider/root proof separate; no diagnostic outcome earns full-unit acceptance",
               "partial_diagnostic_path": PRIVATE + "/diagnostic-partial-60s.json",
               "partial_diagnostic_semantics": "HelperV4 diagnosticadapter persists bounded historical entered/firstexecute/cadence telemetry; no live-state/fullunit/admission claim, unknown wrappers retained until reaping",
               "training_credit": 0, "speed_claim": False, "constructor_launches_nothing": True}
    return {"ORDINARY-SNAPSHOT.json": capture["snapshot"], "PRIVATE-DESCRIPTOR.json": descriptor,
            "ADAPTER-PACKET.json": adapter, "CHILD-PACKET.json": child,
            "PARENT-PACKET.json": parent, "CONSTRUCTION-SUMMARY.json": summary}


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--inputs", required=True)
    parser.add_argument("--inputs-sha256", required=True)
    args = parser.parse_args()
    reads = Reads()
    inputs = json.loads(reads.checked({"path": args.inputs, "sha256": args.inputs_sha256}))
    document_keys = {"runtime_bundle", "runtime_copy_review", "capture", "precision", "provisional_authority"}
    need(set(inputs["documents"]) == document_keys, "exact metadata document roles")
    documents = {name: json.loads(reads.checked(ref)) for name, ref in inputs["documents"].items()}
    for group in (inputs["gates"], inputs["preparation_refs"]):
        for ref in group.values():
            reads.checked(ref)  # opaque gate content is independently reviewed by root, not interpreted as a grant here
    need(time.time() + 240 < inputs["expires_unix"] <= EXPIRY, "remaining finite action/cleanup authority")
    outputs = construct(inputs, documents)
    destination = Path(inputs["metadata_output"])
    need(destination.parent.resolve() == destination.parent and not os.path.lexists(destination), "create-only metadata destination")
    destination.mkdir(mode=0o700)
    refs = {}
    for name, document in outputs.items():
        raw = canonical(document)
        need(len(raw) <= 16 << 20, "bounded metadata output")
        path = destination / name
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
        except BaseException:
            # Keep every already-created partial artifact; no cleanup/retry.
            raise
        refs[name] = {"path": str(path), "sha256": sha(raw)}
    print(json.dumps({"created": refs, "launch_authority": False, "training_credit": 0}, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
