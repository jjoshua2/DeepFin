"""SOURCE-ONLY finite parent draft: unbound packets refuse before custody.

No scheduler, ordinary-owner launch, queue/control mutation, fake q or alternate
settlement. Root must independently review and bind this source, the exact
child, actual runtime/resources and action packet before a single invocation.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import resource
import signal
import sqlite3
import stat
import sys
import time


RUNTIME = Path("/tmp/deepfin-pr1110-production-20261021-v1/runtime-v5")
QROOT = Path("/tmp/bt4-local-continuous-adoption-runtime-20261008-v2")
EXPIRY = 1792649011.575
BOOT = "e34eff27-d1dc-49c0-bac2-e8525ea1b52f"
OLD_OWNER = {"pid": 224690, "start_ticks": 45987470, "boot_id": BOOT}
EXCLUSION_LOCKS = [
    "/home/josh/chess-artifacts/operations/bt4-local-continuous-newboot-20261013-v1/supervisor.lock",
    "/home/josh/chess-artifacts/operations/bt4-local-continuous-operational-20261008-v2/supervisor.lock",
    "/mnt/c/Users/jjosh/Documents/Codex/2026-10-08/task/bt4-reserve-staged-stock-append-20261013-v5/staging-operator.lock",
]
Q_FILES = {
    "__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "durable_gpu_queue.py": "df5fd4c7fa047795dc5b47d687340831161aaa2e0f3964e8489b5b748c804fa8",
    "bt4_continuous_queue_v3.py": "75548841654bc2ef1994aa07d1fd99e858f9c9e6cbf67381703f4922cc914f50",
    "bootstrap_operator_support.py": "834fab3d594f8d9a3f992f64fd2a530ef79bdec3d6b8c3f35c778770a2015f6c",
    "bt4_inherited_owner_v2.py": "cfcae5b3d75e7926e5ce1a39e7d17c0d6ad2c468aa2057bbea7b894ebf0b9c59",
    "canonical_queue_custody_v2.py": "186c165f084c8ef1c3d8bc17c1130aefa128217ae21628c23991f5a0c6700b08",
}
GATES = (
    "source_review", "cpu_and_native_qualification", "runtime_import_closure",
    "model_precision_provider_contract", "resources_and_accounting",
    "child_claim_before_target_imports", "paused_state_guard_interface",
    "parent_and_child_lifecycle_review", "user_authority",
)
SOURCE_KEYS = {"parent", "mechanical_binding", "retained_custody", "bound_custody",
               "owner_helper", "settlement", "child", "child_packet", "interpreter", "outer_launcher"}
PACKET_KEYS = {"schema", "attempt", "issued_unix", "expires_unix", "sources", "gates",
               "runtime_sources", "geometry", "resources", "preservation", "outputs",
               "exclusion_paths", "child_argv", "child_env", "abort_paths"}
GEOMETRY = {"units": 1, "games": 128, "max_plies": 400, "actors": 64,
            "target_rows": 64, "max_rows": 64, "active_seconds": 60, "cleanup_seconds": 180}
CHILD_ROOT = Path("/home/josh/chess-artifacts/operations/bt4-pr1110-correctness-private-20261021-v4")
CHECKPOINT_SUFFIXES = ("-wal", "-shm", "-journal")
ACCOUNTING_STATES = frozenset("RSDZTtWKPI")
RESOURCE_KEYS = {"metadata_read_bytes", "preflight_seconds", "min_memory_bytes", "min_disk_bytes",
                 "max_stream_bytes", "max_output_bytes", "accounting_source", "family_cpu_seconds",
                 "family_rss_bytes", "family_pss_bytes", "process_as_bytes", "child_cpu_seconds", "child_as_bytes",
                 "child_file_bytes",
                 "inherited_as_limit", "received_parent_rlimits",
                 "sample_interval_ms", "max_family_processes"}
FIXED_SOURCE_HASHES = {
    "retained_custody": "186bcd3f0e0918dac64d018ac78c74d2516b037f4cec822a06a14c67b9507964",
    "owner_helper": "b52f2b180e08af28e65c1ce414926f9fe7a176fd7fd5522cea836a6c127febba",
    "settlement": "b480d1a3291d10ad88d248d7174080f9a11c5e76f45604dc7a60241dd7a5a98b",
}


def need(ok, why):
    if not ok:
        raise ValueError(why)


def reference(value):
    need(type(value) is dict and set(value) == {"path", "sha256"}, "unbound exact reference")
    need(type(value["path"]) is str and Path(value["path"]).is_absolute(), "absolute reference")
    need(type(value["sha256"]) is str and re.fullmatch("[0-9a-f]{64}", value["sha256"]),
         "exact SHA256 reference")
    return value


def validate_packet(packet, now):
    """Pure closed-shape gate; no filesystem, import, process or lease actions."""
    need(type(packet) is dict and set(packet) == PACKET_KEYS, "closed packet fields required")
    need(packet["schema"] == "PR1110_FINITE_CORRECTNESS_PARENT_PACKET_V1", "inactive/unbound packet")
    need(type(packet["attempt"]) is str and re.fullmatch("[A-Za-z0-9-]{1,96}", packet["attempt"]), "one-use attempt")
    issued, expires = packet["issued_unix"], packet["expires_unix"]
    need(all(type(x) in (int, float) and math.isfinite(x) for x in (issued, expires, now)), "finite times")
    need(0 < issued <= now < expires <= EXPIRY and now + 240 < expires, "action/cleanup expiry")
    need(type(packet["geometry"]) is dict and packet["geometry"] == GEOMETRY
         and all(type(value) is int for value in packet["geometry"].values()), "one reviewed finite geometry only")
    need(type(packet["sources"]) is dict and set(packet["sources"]) == SOURCE_KEYS, "exact source closure")
    for name, value in packet["sources"].items():
        reference(value)
        if name in FIXED_SOURCE_HASHES:
            need(value["sha256"] == FIXED_SOURCE_HASHES[name], "unchanged retained helper required")
    need(type(packet["gates"]) is dict and set(packet["gates"]) == set(GATES), "all independent gates required")
    for value in packet["gates"].values():
        reference(value)
    runtime_sources = packet["runtime_sources"]
    need(type(runtime_sources) is dict and 2 <= len(runtime_sources) <= 1024, "bound runtime source closure")
    for relative, digest in runtime_sources.items():
        need(type(relative) is str and not Path(relative).is_absolute() and ".." not in Path(relative).parts,
             "canonical relative runtime source")
        reference({"path": str(RUNTIME / relative), "sha256": digest})
    need({"scripts/bt4_queue_consumer_v2.py", "scripts/bt4_inherited_owner_v2.py"} <= set(runtime_sources),
         "actual adapter/inherited binding required")
    resources = packet["resources"]
    need(type(resources) is dict and set(resources) == RESOURCE_KEYS, "concrete resource plan required")
    for name in RESOURCE_KEYS - {"accounting_source", "child_as_bytes", "process_as_bytes",
                                 "inherited_as_limit", "received_parent_rlimits"}:
        need(type(resources[name]) is int and resources[name] > 0, "positive exact resource bound")
    need(resources["metadata_read_bytes"] <= 64 << 20 and type(resources["preflight_seconds"]) is int
         and 0 < resources["preflight_seconds"] <= 30, "bounded metadata preflight")
    reference(resources["accounting_source"])
    need(resources["accounting_source"] == packet["sources"]["parent"], "actual parent accounting source required")
    need(resources["child_as_bytes"] is None and resources["process_as_bytes"] is None,
         "GPU AS policy must remain unchanged, not an inferred memory fit")
    as_limit = resources["inherited_as_limit"]
    need(type(as_limit) is list and len(as_limit) == 2
         and all(type(value) is int and (value == -1 or value > 0) for value in as_limit)
         and (as_limit[1] == -1 or 0 < as_limit[0] <= as_limit[1]), "exact inherited AS pair required")
    received = resources["received_parent_rlimits"]
    need(type(received) is dict and set(received) == {"CPU", "AS", "FSIZE"}, "exact received parent rlimits required")
    for pair in received.values():
        need(type(pair) is list and len(pair) == 2
             and all(type(value) is int and (value == -1 or value > 0) for value in pair)
             and (pair[1] == -1 or 0 < pair[0] <= pair[1]), "exact received parent rlimit pair")
    need(received["AS"] == as_limit and received["CPU"] == [-1, -1],
         "no inherited hard CPU kill of sole settlement parent; no limit raise")
    need(resources["sample_interval_ms"] <= 100 and resources["max_family_processes"] <= 64
         and resources["child_cpu_seconds"] <= resources["family_cpu_seconds"]
         and resources["child_file_bytes"] <= resources["max_output_bytes"], "bounded family accounting contract")
    need(packet["child_argv"] == child_prefix(packet), "closed isolated child argv required")
    need(type(packet["child_env"]) is dict and all(type(k) is str and type(v) is str for k, v in packet["child_env"].items()),
         "exact reviewed child environment")
    need(set(packet["child_env"]) <= {"PATH", "HOME", "LANG", "LC_ALL", "OMP_NUM_THREADS",
         "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS",
         "VECLIB_MAXIMUM_THREADS", "CUDA_VISIBLE_DEVICES"}, "no injected interpreter/loader environment")
    need("DEEPFIN_FINITE_ALL_THREE_CLAIM" not in packet["child_env"], "parent supplies inherited claim")
    for name in ("exclusion_paths", "abort_paths"):
        need(type(packet[name]) is list and len(set(packet[name])) == len(packet[name])
             and all(type(path) is str and Path(path).is_absolute() for path in packet[name]), "bound control/lock paths")
    need(packet["exclusion_paths"] == EXCLUSION_LOCKS, "exact retained exclusion LOCK roster; never marker paths")
    need(type(packet["preservation"]) is dict and set(packet["preservation"]) == {
        "former_owner", "snapshot", "controls", "evaluation_stops", "pause", "stopped_units"}, "preservation proof required")
    preservation = packet["preservation"]
    need(preservation["former_owner"] == OLD_OWNER, "closed head14 owner only")
    reference(preservation["snapshot"])
    need(type(preservation["controls"]) is list and len(preservation["controls"]) == 564, "exact union control roster")
    paths = [state["path"] for state in preservation["controls"]]
    need(len(set(paths)) == 564 and len(preservation["evaluation_stops"]) == 6
         and len(set(preservation["evaluation_stops"])) == 6
         and set(preservation["evaluation_stops"]) <= set(paths)
         and preservation["pause"] in paths, "PAUSE and all six evaluation STOPs retained")
    for state in preservation["controls"]:
        need(type(state) is dict and set(state) == {"path", "present", "sha256"}
             and type(state["present"]) is bool, "closed control state")
        if state["present"]:
            reference({"path": state["path"], "sha256": state["sha256"]})
        else:
            need(state["sha256"] is None and Path(state["path"]).is_absolute(), "absent control state")
        if state["path"] in preservation["evaluation_stops"] + [preservation["pause"]]:
            need(state["present"], "required PAUSE/STOP cannot be absent")
    need(type(preservation["stopped_units"]) is list and len(preservation["stopped_units"]) == 5,
         "five stopped-unit/checkpoint proofs required")
    for value in preservation["stopped_units"]:
        checkpoint_components(value)
    need(type(packet["outputs"]) is dict and set(packet["outputs"]) == {"root", "child"}, "unique private outputs")
    root = Path(packet["outputs"]["root"])
    need(root.is_absolute() and root.name == "pr1110-finite-" + packet["attempt"]
         and root.parent == Path("/home/josh/chess-artifacts/operations")
         and packet["outputs"]["child"] == str(CHILD_ROOT), "private non-training output anchor")
    need(1 <= len(packet["abort_paths"]) <= 8
         and all(Path(path).is_relative_to(root) for path in packet["abort_paths"])
         and not set(packet["abort_paths"]) & set(paths), "separate private abort controls required")


def child_prefix(packet):
    """The only variable launch arguments are the parent-created claim hash."""
    sources = packet["sources"]
    return [sources["interpreter"]["path"], "-I", "-S", "-B", sources["child"]["path"],
            "--packet", sources["child_packet"]["path"],
            "--packet-sha256", sources["child_packet"]["sha256"]]


def outer_contract(packet, packet_ref, review_ref):
    """Circular self-hash is represented by one explicit review template token."""
    return {"launcher": packet["sources"]["outer_launcher"],
            "argv_template": [packet["sources"]["interpreter"]["path"], "-I", "-S", "-B",
                packet["sources"]["parent"]["path"], "--packet", packet_ref["path"],
                "--packet-sha256", packet_ref["sha256"], "--action-review", review_ref["path"],
                "--action-review-sha256", "ACTION_REVIEW_SELF_SHA256"],
            "parent_kill_timeout_seconds": None, "native_session_polling_is_completion": False}


def deadline_claim(packet, custody_claim, parent_argv, wall, monotonic):
    """Pure immutable launch contract. No child-relative timer or renewal."""
    need(all(type(value) in (int, float) and math.isfinite(value) and value > 0
             for value in (wall, monotonic)), "finite launch clocks")
    need(wall + 240 < packet["expires_unix"], "launch cleanup expiry")
    return {"schema": "PR1110_FINITE_PARENT_CLAIM_V1",
            "packet_sha256": packet["sources"]["child_packet"]["sha256"],
            "parent": custody_claim["parent"], "canonical_leases": custody_claim["leases"],
            "child_program_sha256": packet["sources"]["child"]["sha256"],
            "started_unix": wall, "started_monotonic": monotonic,
            "active_deadline_unix": wall + 60, "active_deadline_monotonic": monotonic + 60,
            "cleanup_deadline_monotonic": monotonic + 240, "parent_argv": parent_argv,
            "resources": {name: packet["resources"][name] for name in
                          ("child_cpu_seconds", "child_as_bytes", "inherited_as_limit",
                           "child_file_bytes", "max_stream_bytes", "max_output_bytes")}}


def proc_sample(raw, expected, page_size, clock_ticks):
    """Pure /proc/stat decoding; PID and birth are checked around each read."""
    fields = raw.rsplit(")", 1)[1].split()
    need(int(raw.split("(", 1)[0]) == expected["pid"]
         and int(fields[19]) == expected["start_ticks"], "family process identity changed")
    need(fields[0] in ACCOUNTING_STATES, "recognized accounting process state required")
    if fields[0] == "Z":
        need(int(fields[20]) == 0 and int(fields[21]) == 0, "zombie userspace memory must be zero")
    # Include waited-descendant cutime/cstime while this process remains live.
    # Those counters have not yet reached the outer parent's RUSAGE_CHILDREN.
    # Charging them again after a later reap is conservatively intentional.
    return {"cpu_seconds": sum(int(fields[index]) for index in (11, 12, 13, 14)) / clock_ticks,
            "rss_bytes": max(0, int(fields[21])) * page_size, "as_bytes": int(fields[20])}


def proc_record(raw, pid):
    """Accounting identity includes readable zombies, unlike live-only q.identity.

    This does not change any custody/helper predicate. Unknown, dead, malformed,
    reused or unreadable processes still refuse; an exited PID is never skipped.
    """
    fields = raw.rsplit(")", 1)[1].split()
    need(int(raw.split("(", 1)[0]) == pid and len(fields) >= 22
         and fields[0] in ACCOUNTING_STATES, "readable accounting process state required")
    start, parent_pid = int(fields[19]), int(fields[1])
    need(start > 0 and parent_pid >= 0, "accounting birth/parent fields required")
    return {"identity": {"pid": pid, "start_ticks": start, "boot_id": BOOT},
            "parent_pid": parent_pid, "state": fields[0]}


def proc_text(path):
    with Path(path).open("rb") as stream:
        raw = stream.read((64 << 10) + 1)
    need(len(raw) <= 64 << 10, "bounded accounting proc read")
    return raw.decode()


def received_rlimits():
    return {name: list(resource.getrlimit(getattr(resource, "RLIMIT_" + name)))
            for name in ("CPU", "AS", "FSIZE")}


def enforce_sample(resources, cpu, rss, pss, processes, elapsed):
    """Pure active-stage limits. Refusal enters retained settlement, never kills parent."""
    need(cpu <= resources["family_cpu_seconds"], "family CPU cap")
    need(rss <= resources["family_rss_bytes"], "sampled family RSS cap")
    need(pss <= resources["family_pss_bytes"], "sampled family PSS cap")
    need(processes <= resources["max_family_processes"], "family process count cap")
    need(elapsed < 60, "parent-bound active deadline")


def accounting_family(_q, parent, max_processes):
    """Strict accounting census; read errors refuse instead of becoming zero.

    Retained q still exclusively owns stop/reap/settlement. This observation
    checks all thread children (including subreaper-adopted descendants) and
    exact parent/birth on both sides of each process enumeration.
    """
    need(proc_text("/proc/sys/kernel/random/boot_id").strip() == BOOT, "accounting boot changed")
    family = {parent["pid"]: parent}
    pending = [parent]
    while pending:
        owner = pending.pop()
        before = proc_record(proc_text(f"/proc/{owner['pid']}/stat"), owner["pid"])
        need(before["identity"] == owner, "accounting owner birth changed")
        tasks = list(Path(f"/proc/{owner['pid']}/task").iterdir())
        need(len(tasks) <= 4096, "bounded accounting task roster")
        children = set()
        for task in tasks:
            with (task / "children").open("rb") as stream:
                raw = stream.read((64 << 10) + 1)
            need(len(raw) <= 64 << 10, "bounded accounting children read")
            children.update(int(value) for value in raw.split())
        after = proc_record(proc_text(f"/proc/{owner['pid']}/stat"), owner["pid"])
        need(after["identity"] == owner and after["parent_pid"] == before["parent_pid"],
             "accounting owner changed during census")
        for pid in children:
            relation = proc_record(proc_text(f"/proc/{pid}/stat"), pid)
            need(relation["parent_pid"] == owner["pid"], "accounting child parent changed")
            if pid not in family:
                need(len(family) < max_processes, "bounded actual family census")
                family[pid] = relation["identity"]
                pending.append(relation["identity"])
    return family


class FamilyAccounting:
    """Sampled aggregate RSS/AS and conservative cumulative CPU, not a cgroup quota.

    Per-identity CPU maxima include each live process's waited-descendant CPU
    and persist after exit; reaped-child rusage is added too,
    so a reaped process may be double-charged but is not silently forgotten.
    Short-lived unsampled RSS/AS peaks are not claimed measured. Child hard
    CPU/FSIZE limits are separately checked before its target imports. GPU AS is
    observed only; neither this parent nor child changes the inherited AS pair.
    """
    def __init__(self, resources, q, parent, started):
        self.resources, self.q, self.parent, self.started = resources, q, parent, started
        self.self_cpu_start = time.process_time()
        used = resource.getrusage(resource.RUSAGE_CHILDREN)
        self.reaped_start = used.ru_utime + used.ru_stime
        self.cpu_max = {}
        self.peak_rss = self.peak_pss = self.peak_as = self.peak_count = self.samples = 0
        self.zombie_samples = 0
        self.cpu_charge = 0.0

    def sample(self):
        family = accounting_family(self.q, self.parent, self.resources["max_family_processes"])
        rss = pss = address_space = 0
        for pid, identity in family.items():
            raw = proc_text(f"/proc/{pid}/stat")
            before = proc_record(raw, pid)
            need(identity["boot_id"] == BOOT and before["identity"] == identity,
                 "actual family birth before sample")
            need(pid == self.parent["pid"] or before["parent_pid"] in family, "sampled process outside accounting family")
            sample = proc_sample(raw, identity,
                                 os.sysconf("SC_PAGE_SIZE"), os.sysconf("SC_CLK_TCK"))
            if before["state"] != "Z":
                # Never swallow a missing/unreadable live-process PSS record.
                rollup = proc_text(f"/proc/{pid}/smaps_rollup")
                pss_rows = [line.split() for line in rollup.splitlines() if line.startswith("Pss:")]
                need(len(pss_rows) == 1 and pss_rows[0][2:] == ["kB"], "actual family PSS sample required")
                pss += int(pss_rows[0][1]) * 1024
            after_raw = proc_text(f"/proc/{pid}/stat")
            after = proc_record(after_raw, pid)
            need(after["identity"] == identity and after["parent_pid"] == before["parent_pid"],
                 "actual family birth/parent after sample")
            after_sample = proc_sample(after_raw, identity, os.sysconf("SC_PAGE_SIZE"), os.sysconf("SC_CLK_TCK"))
            if before["state"] == "Z":
                need(after["state"] == "Z", "zombie accounting state changed")
                self.zombie_samples += 1  # explicit zero-userspace stat proof, not an ignored PSS error
            if pid != os.getpid():
                key = (pid, identity["start_ticks"])
                self.cpu_max[key] = max(self.cpu_max.get(key, 0), sample["cpu_seconds"], after_sample["cpu_seconds"])
            rss += max(sample["rss_bytes"], after_sample["rss_bytes"])
            address_space = max(address_space, sample["as_bytes"], after_sample["as_bytes"])
        reaped = resource.getrusage(resource.RUSAGE_CHILDREN)
        self.cpu_charge = (time.process_time() - self.self_cpu_start + sum(self.cpu_max.values())
                           + reaped.ru_utime + reaped.ru_stime - self.reaped_start)
        self.peak_rss = max(self.peak_rss, rss)
        self.peak_pss = max(self.peak_pss, pss)
        self.peak_as = max(self.peak_as, address_space)
        self.peak_count = max(self.peak_count, len(family))
        self.samples += 1
        enforce_sample(self.resources, self.cpu_charge, rss, pss, len(family),
                       time.monotonic() - self.started)

    def final_cpu(self):
        reaped = resource.getrusage(resource.RUSAGE_CHILDREN)
        self.cpu_charge = (time.process_time() - self.self_cpu_start + sum(self.cpu_max.values())
                           + reaped.ru_utime + reaped.ru_stime - self.reaped_start)
        need(self.cpu_charge <= self.resources["family_cpu_seconds"], "final family CPU cap")

    def report(self):
        return {"samples": self.samples, "conservative_family_cpu_seconds": self.cpu_charge,
                "sampled_family_peak_rss_bytes": self.peak_rss,
                "sampled_family_peak_pss_bytes": self.peak_pss,
                "sampled_process_peak_as_bytes": self.peak_as, "sampled_peak_processes": self.peak_count,
                "short_lived_memory_peaks_measured": False, "family_hard_quota": False,
                "verified_zero_userspace_zombie_samples": self.zombie_samples,
                "gpu_as_limit_changed": False, "inherited_as_limit": self.resources["inherited_as_limit"]}


class Reads:
    def __init__(self, amount, seconds):
        self.remaining = amount
        self.deadline = time.monotonic() + seconds

    def raw(self, path, cap=8 << 20):
        need(time.monotonic() < self.deadline, "metadata deadline")
        path = Path(path)
        need(path.resolve(strict=True) == path, "canonical named file")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            before = os.fstat(fd)
            need(stat.S_ISREG(before.st_mode) and before.st_size <= min(cap, self.remaining), "bounded regular read")
            raw = os.read(fd, before.st_size + 1)
            after, named = os.fstat(fd), path.lstat()
            identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
            need(len(raw) == before.st_size and identity(before) == identity(after) == identity(named), "read changed")
            self.remaining -= len(raw)
            need(time.monotonic() < self.deadline, "metadata deadline")
            return raw
        finally:
            os.close(fd)

    def checked(self, ref, cap=8 << 20):
        reference(ref)
        raw = self.raw(ref["path"], cap)
        need(hashlib.sha256(raw).hexdigest() == ref["sha256"], "exact reference changed")
        return raw


def load_file(ref, name, reads):
    raw = reads.checked(ref)
    spec = importlib.util.spec_from_file_location(name, ref["path"])
    need(spec is not None, "exact source spec")
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, ref["path"], "exec"), module.__dict__)
    return module


def load_q(reads):
    need(not any(name == "scripts" or name.startswith("scripts.") for name in sys.modules),
         "dedicated parent without preloaded project modules required")
    for name, digest in Q_FILES.items():
        reads.checked({"path": str(QROOT / "scripts" / name), "sha256": digest})
    sys.path.insert(0, str(QROOT))
    q = importlib.import_module("scripts.durable_gpu_queue")  # normal intact import; never q.main
    for name, module in tuple(sys.modules.items()):
        if name == "scripts" or name.startswith("scripts."):
            path = Path(module.__file__).resolve()
            relative = path.relative_to(QROOT / "scripts").as_posix()
            need(relative in Q_FILES, "unreviewed retained q import")
            reads.checked({"path": str(path), "sha256": Q_FILES[relative]})
    return q


def closed_snapshot(path, deadline):
    """Same retained projection, with an explicit connection close on every path.

    No retained helper is monkeypatched. The SQL transaction is mode=ro,
    query_only and rolled back/closed before any subsequent filesystem scan.
    This is bounded logical metadata, not a physical read-byte quota.
    """
    sql_deadline = min(deadline, time.monotonic() + 0.5)
    connection = sqlite3.connect("file:" + str(path) + "?mode=ro", uri=True, timeout=0.5)
    try:
        connection.row_factory = sqlite3.Row
        connection.set_progress_handler(lambda: int(time.monotonic() >= sql_deadline), 1000)
        connection.execute("pragma query_only=ON")
        connection.execute("BEGIN DEFERRED")
        campaign = dict(connection.execute("select hash,control,policy from campaign").fetchone())
        jobs = []
        for row in connection.execute("select id,ordinal,item,status,attempt,process from jobs order by ordinal"):
            need(len(jobs) < 8192, "snapshot job roster exceeds 8192")
            need(time.monotonic() < sql_deadline, "snapshot SQL deadline exceeded")
            jobs.append(compact_job(dict(row)))
        result = {"campaign": campaign, "jobs": jobs,
                  "addition_count": connection.execute("select count(*) from additions").fetchone()[0]}
        need(len(json.dumps(result).encode()) <= 8 << 20, "snapshot result exceeds 8MiB")
        need(time.monotonic() < sql_deadline, "snapshot SQL deadline exceeded")
        return result
    except sqlite3.OperationalError as error:
        if time.monotonic() >= sql_deadline:
            raise ValueError("snapshot SQL deadline exceeded") from error
        raise
    finally:
        try:
            connection.rollback()
        finally:
            connection.close()


def compact_job(row):
    """Preserve every job field, binding exact full item text by SHA256.

    No JSON normalization or selected-item projection: every row's entire item
    UTF-8 payload is bound even when only five stopped descriptors are examined
    separately by the preservation capture helper.
    """
    need(type(row) is dict and set(row) == {"id", "ordinal", "item", "status", "attempt", "process"},
         "exact snapshot job fields")
    item = row["item"]
    need(type(item) is str, "snapshot item must be exact text")
    return {**{name: value for name, value in row.items() if name != "item"},
            "item_sha256": hashlib.sha256(item.encode("utf-8")).hexdigest()}


def checkpoint_components(proof):
    """Closed file-only proof; no SQLite connection or checkpoint operation."""
    need(type(proof) is dict and set(proof) == {"main", "sidecars"}, "checkpoint component proof required")
    main = reference(proof["main"])
    sidecars = proof["sidecars"]
    need(type(sidecars) is list and len(sidecars) == 3, "three checkpoint sidecar states required")
    result = [{"path": main["path"], "present": True, "sha256": main["sha256"]}]
    for suffix, state in zip(CHECKPOINT_SUFFIXES, sidecars):
        need(type(state) is dict and set(state) == {"suffix", "present", "sha256"}
             and state["suffix"] == suffix and type(state["present"]) is bool,
             "exact checkpoint suffix order and presence required")
        path = main["path"] + suffix
        if state["present"]:
            reference({"path": path, "sha256": state["sha256"]})
        else:
            need(state["sha256"] is None, "absent checkpoint sidecar cannot have a digest")
        result.append({"path": path, "present": state["present"], "sha256": state["sha256"]})
    return result


def checkpoint_state(components):
    states = []
    for component in components:
        path = Path(component["path"])
        need(os.path.lexists(path) == component["present"], "checkpoint component presence changed")
        if component["present"]:
            info = path.lstat()
            need(stat.S_ISREG(info.st_mode), "checkpoint component must be regular")
            states.append((str(path), True, info.st_dev, info.st_ino, info.st_size,
                           info.st_mtime_ns, info.st_ctime_ns))
        else:
            states.append((str(path), False))
    return states


def verify_checkpoint(proof, reads):
    components = checkpoint_components(proof)
    before = checkpoint_state(components)
    for component in components:
        if component["present"]:
            reads.checked({"path": component["path"], "sha256": component["sha256"]}, cap=reads.remaining)
    need(checkpoint_state(components) == before, "checkpoint component set changed during hash pass")


def preserved(packet, h, reads):
    need(Path("/proc/sys/kernel/random/boot_id").read_text().strip() == BOOT, "exact boot changed")
    need(h.birth(OLD_OWNER["pid"]) != OLD_OWNER, "closed ordinary owner returned")
    expected = packet["preservation"]
    need(expected["pause"] == str(h.ROOT / "PAUSE"), "ordinary PAUSE path differs")
    snapshot = json.loads(reads.checked(expected["snapshot"]))
    actual = closed_snapshot(h.ROOT / "queue.sqlite", reads.deadline)
    need(actual == snapshot, "ordinary queue/prefix/control changed")
    for state in expected["controls"]:
        need(os.path.lexists(state["path"]) == state["present"], "preserved control presence changed")
        if state["present"]:
            reads.checked({"path": state["path"], "sha256": state["sha256"]})
    for proof in expected["stopped_units"]:
        verify_checkpoint(proof, reads)
    need(time.monotonic() < reads.deadline, "preservation preflight deadline")
    return {"ordinary_snapshot_sha256": h.stable_digest(actual), "control_count": 564,
            "evaluation_stops": 6, "stopped_units": 5, "ordinary_state": "CLOSED_PAUSED"}


def free_canonical(h):
    fixed = {tuple(identity): path for path, identity in h.CANONICAL}
    for identity, path in fixed.items():
        info = Path(path).lstat()
        need(stat.S_ISREG(info.st_mode) and (info.st_dev, info.st_ino) == identity, "canonical identity changed")
    matches = []
    for line in Path("/proc/locks").read_text().splitlines():
        match = re.search(r"\b([0-9a-fA-F]+):([0-9a-fA-F]+):(\d+)\b", line)
        if match and (os.makedev(int(match[1], 16), int(match[2], 16)), int(match[3])) in fixed:
            matches.append(line)
    need(not matches, "canonical locks not free")
    return matches


def run(packet_ref, review_ref):
    initial = Reads(8 << 20, 30)
    packet = json.loads(initial.checked(packet_ref))
    validate_packet(packet, time.time())  # null/unbound refuses before any imports or lock/output action
    need(list(resource.getrlimit(resource.RLIMIT_AS)) == packet["resources"]["inherited_as_limit"],
         "received AS limit differs; no limit raise or implicit CUDA-fit assumption")
    need(received_rlimits() == packet["resources"]["received_parent_rlimits"], "received parent rlimits differ")
    reads = Reads(packet["resources"]["metadata_read_bytes"], packet["resources"]["preflight_seconds"])
    need(Path(packet["sources"]["parent"]["path"]).resolve() == Path(__file__).resolve(), "actual parent origin")
    for ref in packet["sources"].values():
        reads.checked(ref)
    for ref in packet["gates"].values():
        reads.checked(ref)
    reads.checked(packet["resources"]["accounting_source"])
    review = json.loads(reads.checked(review_ref))
    need(type(review) is dict and set(review) == {"schema", "packet", "sources", "gates", "action", "findings", "expires_unix", "outer"},
         "closed independent action review required")
    need(review["schema"] == "PR1110_FINITE_ACTION_REVIEW_V1" and review["packet"] == packet_ref
         and review["sources"] == packet["sources"] and review["gates"] == packet["gates"]
         and review["action"] == "ONE_PRIVATE_BT4_CORRECTNESS_CLOSED_PAUSED"
         and review["findings"] == [] and review["expires_unix"] == packet["expires_unix"], "exact action review differs")
    need(review["outer"] == outer_contract(packet, packet_ref, review_ref),
         "exact reviewed outer without custody-parent kill required")
    actual_outer = proc_text("/proc/self/cmdline").rstrip("\0").split("\0")
    expected_outer = [review_ref["sha256"] if value == "ACTION_REVIEW_SELF_SHA256" else value
                      for value in review["outer"]["argv_template"]]
    need(actual_outer == expected_outer, "actual isolated parent command differs from reviewed outer")
    for relative, digest in packet["runtime_sources"].items():
        reads.checked({"path": str(RUNTIME / relative), "sha256": digest})
    compose = load_file(packet["sources"]["mechanical_binding"], "_pr1110_composition", reads)
    adapter = {"path": str(RUNTIME / "scripts/bt4_queue_consumer_v2.py"),
               "sha256": packet["runtime_sources"]["scripts/bt4_queue_consumer_v2.py"]}
    inherited = {"path": str(RUNTIME / "scripts/bt4_inherited_owner_v2.py"),
                 "sha256": packet["runtime_sources"]["scripts/bt4_inherited_owner_v2.py"]}
    need(reads.checked(packet["sources"]["bound_custody"]) == compose.compose_source(
        reads.checked(packet["sources"]["retained_custody"]), adapter=adapter, inherited=inherited), "nonmechanical custody change")
    q = load_q(reads)
    custody_module = load_file(packet["sources"]["bound_custody"], "_pr1110_bound_custody", reads)
    need(str(custody_module.INTEGRATED_RUNTIME) == str(RUNTIME)
         and custody_module.ADAPTER_SHA256 == adapter["sha256"]
         and custody_module.INHERITED_SHA256 == inherited["sha256"], "actual bound custody constants")
    h = custody_module.load_owner_helper()
    before = preserved(packet, h, reads)
    free_canonical(h)
    resources = packet["resources"]
    memory = next(int(line.split()[1]) * 1024 for line in Path("/proc/meminfo").read_text().splitlines()
                  if line.startswith("MemAvailable:"))
    root = Path(packet["outputs"]["root"])
    disk = os.statvfs(root.parent)
    need(memory >= resources["min_memory_bytes"] and disk.f_bavail * disk.f_frsize >= resources["min_disk_bytes"], "headroom")
    need(not os.path.lexists(root) and root.resolve() == root
         and not os.path.lexists(CHILD_ROOT) and CHILD_ROOT.resolve() == CHILD_ROOT,
         "absent canonical private roots")
    need(time.time() + 240 < packet["expires_unix"], "expiry before one-use intent")
    root.mkdir(mode=0o700)
    h.write(root / "ONE-USE.json", {"packet": packet_ref, "review": review_ref, "attempt": packet["attempt"]})
    original_handlers = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM)}

    def interrupted(_sig, _frame):
        raise KeyboardInterrupt("finite parent interrupted; retained settlement owns cleanup")

    process_code = None
    error = None
    accounting = None
    started = time.monotonic()
    try:
        for sig in original_handlers:
            signal.signal(sig, interrupted)
        with custody_module.FiniteAllThreeCustody(q, tuple(packet["exclusion_paths"]), root) as custody:
            preserved(packet, h, Reads(resources["metadata_read_bytes"], resources["preflight_seconds"]))
            launch_reads = Reads(resources["metadata_read_bytes"], resources["preflight_seconds"])
            for ref in packet["sources"].values():
                launch_reads.checked(ref)
            for relative, digest in packet["runtime_sources"].items():
                launch_reads.checked({"path": str(RUNTIME / relative), "sha256": digest})
            need(time.time() + 240 < packet["expires_unix"], "expiry under custody")
            need(not any(os.path.lexists(path) for path in packet["abort_paths"]), "private finite STOP before spawn")
            need(not os.path.lexists(CHILD_ROOT), "private child root appeared before spawn")
            need(list(resource.getrlimit(resource.RLIMIT_AS)) == resources["inherited_as_limit"],
                 "received AS limit changed before spawn")
            need(received_rlimits() == resources["received_parent_rlimits"], "received parent rlimits changed before spawn")
            with (root / "stdout").open("xb") as stdout, (root / "stderr").open("xb") as stderr:
                launch_started = time.monotonic()
                parent_claim = custody.claim()
                actual_argv = Path("/proc/self/cmdline").read_bytes().rstrip(b"\0").decode().split("\0")
                bound = deadline_claim(packet, parent_claim, actual_argv, time.time(), launch_started)
                bound_path = root / "BOUND-PARENT-CLAIM.json"
                h.write(bound_path, bound)
                bound_raw = Reads(1 << 20, 1).raw(bound_path, 1 << 20)
                need(json.loads(bound_raw) == bound, "created parent claim readback")
                command = packet["child_argv"] + ["--parent-claim", str(bound_path),
                          "--parent-claim-sha256", hashlib.sha256(bound_raw).hexdigest()]
                accounting = FamilyAccounting(resources, q, parent_claim["parent"], launch_started)
                accounting.sample()
                claim = custody.spawn(command, packet["child_env"], stdout, stderr)
                need(claim == parent_claim, "held parent claim changed at spawn")
                h.write(root / "PARENT-CLAIM.json", claim)
                while custody.process.poll() is None:
                    need(time.monotonic() < bound["active_deadline_monotonic"]
                         and time.time() < bound["active_deadline_unix"]
                         and time.time() < packet["expires_unix"], "active deadline")
                    need(not any(os.path.lexists(path) for path in packet["abort_paths"]), "private finite STOP")
                    need(sum((root / name).stat().st_size for name in ("stdout", "stderr")) <= resources["max_stream_bytes"], "stream cap")
                    need(q.output_size(root) + q.output_size(CHILD_ROOT) <= resources["max_output_bytes"], "private output cap")
                    accounting.sample()
                    time.sleep(resources["sample_interval_ms"] / 1000)
                process_code = custody.process.returncode
        # Exact retained __exit__ performs settle_native and final kernel ECHILD
        # before releasing OFDs. Never replace it with poll()/EOF evidence.
    except BaseException as caught:
        error = caught
    finally:
        for sig, handler in original_handlers.items():
            signal.signal(sig, handler)
    need(sum((root / name).stat().st_size for name in ("stdout", "stderr")
             if (root / name).exists()) <= resources["max_stream_bytes"], "final stream cap")
    need(q.output_size(root) + q.output_size(CHILD_ROOT) <= resources["max_output_bytes"], "final private output cap")
    if accounting is not None:
        accounting.final_cpu()
    after = preserved(packet, h, Reads(resources["metadata_read_bytes"], resources["preflight_seconds"]))
    free_canonical(h)
    try:
        os.waitpid(-1, os.WNOHANG)
    except ChildProcessError:
        pass
    else:
        raise RuntimeError("post-settlement kernel child state not ECHILD")
    need(before == after, "CLOSED+PAUSED restoration differs")
    h.write(root / "CLOSED-PAUSED.json", {
        "packet": packet_ref, "review": review_ref, "kernel_ECHILD": True,
        "canonical_lock_rows": [], "before": before, "after": after,
        "returncode": process_code, "elapsed_seconds": time.monotonic() - started,
        "failure": None if error is None else repr(error), "native_admission": False, "training_credit": 0,
        "accounting": None if accounting is None else accounting.report(),
        "stream_transport": "regular files; EOF is not a custody or child-completion proof",
        "cleanup_seconds_is_unknown_hold_release_deadline": False,
    })
    if error is not None:
        raise error
    need(process_code == 0, "finite child failed; no retry/adoption")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--packet", required=True)
    parser.add_argument("--packet-sha256", required=True)
    parser.add_argument("--action-review", required=True)
    parser.add_argument("--action-review-sha256", required=True)
    args = parser.parse_args()
    run({"path": args.packet, "sha256": args.packet_sha256},
        {"path": args.action_review, "sha256": args.action_review_sha256})


if __name__ == "__main__":
    main()
