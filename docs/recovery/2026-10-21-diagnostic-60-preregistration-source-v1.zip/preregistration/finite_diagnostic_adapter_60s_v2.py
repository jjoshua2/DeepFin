"""SOURCE-ONLY, UNBOUND60s diagnostic caller; no launch/custody acquisition.

One unchanged128-game/64-actor production roster API. This diagnostic adapter
never invokes or changes the old full128 qualification predicate. Root alone
may bind/review a distinct source closure, packet, custody and one-use decision.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import stat
import time

from finite_roster_adapter_v3 import (GENERATION, GEOMETRY, NAME, ORIGINAL_EXPIRY,
                                     ProductionQuiescence, call_with_diagnostics)

PRIVATE_ROOT = Path("/home/josh/chess-artifacts/operations/bt4-pr1110-correctness-private-20261021-v4")
ACTIVE_SECONDS = 60
HELPER4_SHA256 = "998061bfe81aaf49eca04a71dbf5bdf1fe573f2877da340d4c143bce71249993"  # Source pin only; CPU/runtime/action gates remain separate.
STATUS = "APPROVED_EXACT_PRIVATE_60S_DIAGNOSTIC_ONLY"


def need(ok, message):
    if not ok:
        raise ValueError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def finite_authorizer(expected, expected_sha256, expires_unix):
    """Pure exact private-v4 roster binding, not a scheduler or grant."""
    frozen = json.loads(json.dumps(expected, allow_nan=False))
    need(digest(frozen) == expected_sha256 and type(expires_unix) in (int, float)
         and math.isfinite(expires_unix) and 0 < expires_unix <= ORIGINAL_EXPIRY,
         "exact diagnostic descriptor/expiry")
    def authorize(roster, out):
        now = time.time()
        need(type(now) in (int, float) and math.isfinite(now) and 0 < now < expires_unix,
             "unchanged absolute diagnostic authority")
        need(dict(roster) == {NAME: frozen} and out == PRIVATE_ROOT / "coordinator",
             "exact private-v4 one-unit diagnostic roster")
        need(frozen["unit"] == 0 and frozen["attempt"] == 0 and frozen["prior_roots"] == []
             and frozen["external_root"] == str(PRIVATE_ROOT)
             and frozen["generation"] == GENERATION and frozen["block_seconds"] == ACTIVE_SECONDS,
             "fresh unchanged128x400/64actor science; lower60s diagnostic bound")
    return authorize


def run_prepared(packet, *, entry, consumer, recovery, guard, parent, leases, priority_module):
    need(type(HELPER4_SHA256) is str and len(HELPER4_SHA256) == 64,
         "SOURCE-ONLY unbound helper/runtime draft")
    need(packet.get("status") == STATUS and packet.get("operational_ready") is True
         and all(packet.get(name) is not None for name in (
             "independent_action_review_ref", "root_resource_decision_ref", "paused_restoration_plan_ref")),
         "distinct reviewed diagnostic admission required")
    now = time.time()
    expires = packet["expires_unix"]
    need(type(expires) in (int, float) and math.isfinite(expires) and now < expires <= ORIGINAL_EXPIRY,
         "original expiry never renews")
    need(set(leases) == {"gpu", "io", "supervisor"} and guard.output_root == PRIVATE_ROOT
         and PRIVATE_ROOT.resolve() == PRIVATE_ROOT, "actual all-three/private-v4 guard")
    metadata = PRIVATE_ROOT.lstat()
    need(stat.S_ISDIR(metadata.st_mode) and not stat.S_ISLNK(metadata.st_mode),
         "authenticated child-prepared diagnostic root")
    need(now < guard.limits["deadline_unix"] <= min(expires, now + ACTIVE_SECONDS),
         "actual parent60s deadline, never reset after import/model")
    descriptor = packet["descriptor"]
    authorize = finite_authorizer(descriptor, packet["descriptor_sha256"], expires)
    out = PRIVATE_ROOT / "coordinator"
    authorize({NAME: descriptor}, out)
    root = Path(entry.__file__).resolve().parents[1]
    need(descriptor["source_pins"].get("targeted_diagnostics_v4.py") == HELPER4_SHA256
         and packet["runtime_closure_ref"] == {
             "path": str(root / "scripts/bt4_runtime_closure_v1.json"),
             "sha256": descriptor["source_pins"]["scripts/bt4_runtime_closure_v1.json"]},
         "helper identity and actual child-authenticated closure join")
    # The new child must independently join this packet ref to runtime.closure_ref
    # before imports. Closure SHA is packet data, never embedded in its own source.

    from scripts.shared_teacher_owner import run_owned_roster
    from scripts import bt4_root_policy_worker as worker
    from scripts.bt4_generation_evaluator import BT4OnnxEvaluator
    from targeted_diagnostics_v4 import TargetedDiagnostics

    root = Path(entry.__file__).resolve().parents[1]
    quiescent = ProductionQuiescence()
    trace = TargetedDiagnostics(worker.BT4GamePool, entry.Checkpoint, BT4OnnxEvaluator,
        PRIVATE_ROOT / "diagnostic-partial-60s.json", expected_origins={
            "pool": root / "scripts/shared_teacher_generation.py",
            "checkpoint": root / "scripts/bt4_longblock_checkpoint_v2.py",
            "evaluator": root / "scripts/bt4_generation_evaluator.py"}, quiescent=quiescent)
    def actual_call():
        return run_owned_roster({NAME: descriptor}, entry=entry, consumer=consumer, recovery=recovery,
            guard=guard, parent=parent, leases=leases, out=out, priority_module=priority_module,
            authorize=authorize, deadline_seconds=min(float(ACTIVE_SECONDS),
                guard.limits["deadline_unix"] - now), fake_cpu=False, **GEOMETRY)
    # A primary guard deadline/error propagates unchanged. Diagnostic helper must
    # preserve entered/firstexecute/cadence files and unknown ownership until reap.
    result = call_with_diagnostics(trace, quiescent, actual_call)
    return {"status": "DIAGNOSTIC_CALL_RETURNED_NOT_UNIT_QUALIFICATION", "result": result,
            "diagnostic": trace.snapshot(), "full_unit_qualification": False,
            "native_admission": False, "training_credit": 0, "speed_claim": False}
