"""Source-only all-three custody seam for a future reviewed finite pilot.

This is not an entry point or an authorization. A separate reviewed parent must
validate its packet, existing queue drain, STOP controls, runtime closure and
finite budget before constructing this context. No code here selects a queue
job, starts a service, or changes an existing owner.
"""
from __future__ import annotations

import ast
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import time
from typing import Any

WORKSPACE = Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-08/task')
INTEGRATED_RUNTIME = Path('/tmp/deepfin-pr1110-production-20261021-v1/runtime-v5')
ADAPTER_SHA256 = '5e622271057694f9545b83067c0cd17c6ac5b95f5a4ca854e5fb0a7d6de43a77'
OWNER_SOURCE = WORKSPACE / 'bt4-user-only-resume-20261017-v4/bt4_only_native_owner.py'
OWNER_SHA256 = 'b52f2b180e08af28e65c1ce414926f9fe7a176fd7fd5522cea836a6c127febba'
SETTLE_SOURCE = WORKSPACE / 'rolling64-finite-qualification-20261018-v3/finite_controller_frozen_packet_v4.py'
SETTLE_SHA256 = 'b480d1a3291d10ad88d248d7174080f9a11c5e76f45604dc7a60241dd7a5a98b'
INHERITED_SHA256 = 'cfcae5b3d75e7926e5ce1a39e7d17c0d6ad2c468aa2057bbea7b894ebf0b9c59'
NAMES = ('gpu', 'io', 'supervisor')
CLAIM_ENV = 'DEEPFIN_FINITE_ALL_THREE_CLAIM'


def need(value: bool, why: str) -> None:
    if not value:
        raise ValueError(why)


def pinned(path: Path, digest: str) -> bytes:
    """Read one regular, unchanged, named source file; never import by name."""
    need(path.is_absolute() and not path.is_symlink(), 'pinned source path')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= 1 << 20, 'bounded source')
        raw = os.read(fd, (1 << 20) + 1)
        after = os.fstat(fd)
        key = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
        need(key(before) == key(after) == key(path.lstat()), 'source changed during read')
        need(hashlib.sha256(raw).hexdigest() == digest, 'pinned source changed')
        return raw
    finally:
        os.close(fd)


def load_owner_helper() -> Any:
    raw = pinned(OWNER_SOURCE, OWNER_SHA256)
    spec = importlib.util.spec_from_file_location('_finite_pilot_owner_helper', OWNER_SOURCE)
    need(spec is not None, 'owner helper spec')
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(OWNER_SOURCE), 'exec'), module.__dict__)
    return module


def load_exact_settlement(h: Any) -> Any:
    """Extract the reviewed function, without running the old controller body."""
    tree = ast.parse(pinned(SETTLE_SOURCE, SETTLE_SHA256), filename=str(SETTLE_SOURCE))
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'settle_native']
    need(len(nodes) == 1, 'unique reviewed settlement function')
    namespace = {'os': os, 'signal': signal, 'time': time, 'write': h.write}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SETTLE_SOURCE), 'exec'), namespace)
    return namespace['settle_native']


def _fixed(h: Any) -> dict[str, tuple[str, tuple[int, int]]]:
    paths = {path: identity for path, identity in h.CANONICAL}
    need(len(paths) == 3, 'exactly three reviewed canonical paths')
    fixed = {
        'gpu': '/home/josh/projects/chess/scratchpad/gpu0_experiment.lock',
        'io': '/tmp/chess-physical-heavy-io-exclusive.lock',
        'supervisor': '/home/josh/chess-artifacts/operations/deepfin-ceres-reserve38-recovery-queue-20261004-v5/supervisor.lock',
    }
    need(set(paths) == set(fixed.values()), 'canonical roster changed')
    return {name: (path, tuple(paths[path])) for name, path in fixed.items()}


class FiniteAllThreeCustody:
    """Acquired parent FDs remain held until reviewed native ECHILD settlement.

    The caller supplies the already reviewed q module and exact exclusion paths.
    Constructing this class does not grant admission; the later finite runner must
    prove and record that separately before calling enter/spawn.
    """

    def __init__(self, q: Any, exclusion_paths: tuple[str, ...], receipt: Path):
        self.q, self.exclusion_paths, self.receipt = q, exclusion_paths, receipt
        self.h = None
        self.held: list[int] = []
        self.canonical: dict[str, int] = {}
        self.process: subprocess.Popen[Any] | None = None
        self._settle = None
        self._entered = False

    def __enter__(self) -> 'FiniteAllThreeCustody':
        need(not self._entered and self.receipt.is_dir(), 'fresh reviewed receipt directory required')
        self.h = load_owner_helper()
        self._settle = load_exact_settlement(self.h)
        fixed = _fixed(self.h)
        reserved = {path for path, _identity in fixed.values()} | {str(self.h.ROOT / 'supervisor.lock')}
        need(len(set(self.exclusion_paths)) == len(self.exclusion_paths)
             and not (set(self.exclusion_paths) & reserved), 'distinct exclusion OFDs required')
        try:
            for path in self.exclusion_paths:
                self.held.append(self.h.lock(path))
            self.held.append(self.h.lock(self.h.ROOT / 'supervisor.lock'))
            for name in NAMES:
                path, identity = fixed[name]
                fd = self.h.lock(path)
                self.canonical[name] = fd
                info = os.fstat(fd)
                need((info.st_dev, info.st_ino) == identity, 'canonical named inode changed')
            need(ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0, 'native subreaper required')
            self._entered = True
            return self
        except BaseException:
            for fd in reversed(tuple(self.canonical.values()) + tuple(self.held)):
                os.close(fd)
            self.canonical.clear(); self.held.clear()
            raise

    def claim(self) -> dict[str, Any]:
        need(self._entered and self.h is not None and set(self.canonical) == set(NAMES), 'all-three parent custody required')
        parent = self.h.birth(os.getpid())
        need(parent is not None and self.h.birth(os.getpid()) == parent, 'parent birth changed')
        leases = {}
        for name, (path, identity) in _fixed(self.h).items():
            fd = self.canonical[name]
            s = os.fstat(fd)
            need((s.st_dev, s.st_ino) == identity, 'parent canonical FD changed')
            leases[name] = {'path': path, 'identity': list(identity), 'parent_fd': fd}
        return {'parent': parent, 'leases': leases,
                'profile': 'all_three', 'integrated_runtime': str(INTEGRATED_RUNTIME),
                'adapter_sha256': ADAPTER_SHA256}

    def spawn(self, command: list[str], env: dict[str, str], stdout: Any, stderr: Any) -> dict[str, Any]:
        """Only the reviewed outer runner may call this after packet admission."""
        need(self._entered and self.process is None and set(self.canonical) == set(NAMES), 'one child under all-three custody')
        claim = self.claim()
        need(all(isinstance(x, str) for x in command) and command and isinstance(env, dict), 'explicit child command')
        need(CLAIM_ENV not in env, 'caller cannot replace canonical claim')
        child_env = dict(env)
        child_env[CLAIM_ENV] = json.dumps(claim, sort_keys=True, separators=(',', ':'))
        mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
        try:
            self.process = subprocess.Popen(command, env=child_env, stdin=subprocess.DEVNULL,
                                            stdout=stdout, stderr=stderr,
                                            pass_fds=tuple(self.canonical.values()), close_fds=True,
                                            start_new_session=True)
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, mask)
        need(self.h.birth(self.process.pid) is not None, 'native child birth required')
        return claim

    def __exit__(self, _kind: Any, _value: Any, _traceback: Any) -> None:
        need(self._entered and self.h is not None and self._settle is not None, 'entered custody required')
        # If a child exists, any diagnostic, timeout, signal or exception must
        # first run the exact reviewed descendant cleanup. It does not return
        # while completion is unknown; therefore no FD can be released then.
        try:
            should_settle = self.process is not None or bool(self.q.children(os.getpid()))
        except BaseException:
            should_settle = True  # an uncertain child census cannot release custody
        if should_settle:
            self._settle(self.q, self.process, self.receipt)
        while True:
            try:
                os.waitpid(-1, os.WNOHANG)
            except ChildProcessError:
                break
            except OSError:
                pass
            # The exact reviewed settlement never returns while any native
            # descendant or kernel child remains. Re-enter it if a fresh child
            # appears between its return and this final handback check.
            self._settle(self.q, self.process, self.receipt)
        for fd in reversed(tuple(self.canonical.values()) + tuple(self.held)):
            os.close(fd)
        self.canonical.clear(); self.held.clear(); self._entered = False


def check_child_claim(claim: dict[str, Any], adapter_path: Path) -> dict[str, int]:
    """Child-side OFD and parent-birth check before opening any CUDA session."""
    need(claim['profile'] == 'all_three' and claim['integrated_runtime'] == str(INTEGRATED_RUNTIME)
         and claim['adapter_sha256'] == ADAPTER_SHA256, 'finite profile/runtime/adapter binding')
    need(adapter_path.resolve().is_relative_to(INTEGRATED_RUNTIME)
         and hashlib.sha256(pinned(adapter_path, ADAPTER_SHA256)).hexdigest() == ADAPTER_SHA256,
         'matched adapter source binding')
    helper = INTEGRATED_RUNTIME / 'scripts/bt4_inherited_owner_v2.py'
    raw = pinned(helper, INHERITED_SHA256)
    spec = importlib.util.spec_from_file_location('_finite_inherited_owner', helper)
    need(spec is not None, 'inherited helper spec')
    module = importlib.util.module_from_spec(spec)
    exec(compile(raw, str(helper), 'exec'), module.__dict__)
    need(set(claim['leases']) == set(NAMES), 'three inherited OFDs required')
    fixed = module.canonical_profile('all_three')
    for name, (path, identity) in fixed.items():
        descriptor = claim['leases'][name]
        need(descriptor['path'] == path and tuple(descriptor['identity']) == identity,
             'canonical lease identity override')
    return module.inherited(claim['parent'], claim['leases'])


def check_inherited_child(adapter_path: Path) -> dict[str, int]:
    """First child-entry call, before any model, CUDA or worker import.

    The finite parent blocks SIGINT/SIGTERM across Popen. The child inherits
    that mask, so explicitly unblock both before doing anything expensive.
    A reviewed future entry must invoke this function as its first action.
    """
    signal.pthread_sigmask(signal.SIG_UNBLOCK, {signal.SIGINT, signal.SIGTERM})
    raw = os.environ.get(CLAIM_ENV)
    need(raw is not None and len(raw) <= 4096, 'bounded inherited canonical claim required')
    claim = json.loads(raw)
    need(type(claim) is dict, 'canonical claim object required')
    return check_child_claim(claim, adapter_path)
