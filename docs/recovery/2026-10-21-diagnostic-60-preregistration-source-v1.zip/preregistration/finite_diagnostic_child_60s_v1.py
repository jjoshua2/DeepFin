"""Inactive finite BT4 child draft; no authority is conveyed by this source.

Only stdlib imports occur before authenticated inherited all-three custody.
No lease acquisition, scheduler, queue phase, ordinary-owner restart or CLI
fallback exists. Root must bind/review a distinct armed packet and parent claim.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import importlib.util
import json
import math
import os
from pathlib import Path
import signal
import stat
import sys
import time
from typing import Any

EXPIRY = 1792649011.575
ACTIVE = 60
CLEANUP = 180
MODEL = "809db9c3c8063683bf8e7c08de8fec92ea4e37ad8c68c8b1befbde4bd1958961"
PRECISION = "ba3f35e768a9e64c1417856b176526e463b466898b1d3b42f80734d150cc4af4"
PROVISIONAL_AUTHORITY = "c769ceef3cf2abfb95185c0db2b79fe01b8e6ff171572c19ac5b65f3f5d5c6e3"
PRIVATE = Path("/home/josh/chess-artifacts/operations/bt4-pr1110-correctness-private-20261021-v4")
# Exact retained cfcae5b3 canonical profile. Fresh identity/OFD evidence is still
# mandatory; a stale/replaced named lock is a refusal, never a replacement.
CANONICAL = {
    "gpu": ("/home/josh/projects/chess/scratchpad/gpu0_experiment.lock", (2096, 81348917)),
    "io": ("/tmp/chess-physical-heavy-io-exclusive.lock", (2096, 18503149)),
    "supervisor": ("/home/josh/chess-artifacts/operations/deepfin-ceres-reserve38-recovery-queue-20261004-v5/supervisor.lock", (2096, 18835410)),
}
MODULES = {
    "entry": "scripts.bt4_queue_worker_entry_v3",
    "consumer": "scripts.bt4_queue_consumer_v2",
    "recovery": "scripts.bt4_raw_recovery_v2",
    "priority": "scripts.comparison_priority",
    "inherited": "scripts.bt4_inherited_owner_v2",
    "model_binding": "scripts.bt4_provisional_model_binding_v1",
}
REQUIRED_ORIGINS = {"numpy", "chess", "onnxruntime", "chess_anti_engine.encoding._lc0_ext",
                    "scripts.bt4_root_policy_worker", "targeted_diagnostics_v1", "targeted_diagnostics_v2",
                    "finite_roster_adapter_v3", "finite_roster_adapter_v4",
                    "targeted_diagnostics_v4", "finite_diagnostic_adapter_60s_v2"}
DIAGNOSTIC_PINS = {
    "targeted_diagnostics_v1": "48dc44768aabdc4e18c4314abeeaefdb255e65ea54150c6b0d04285d36332a22",
    "targeted_diagnostics_v2": "444bf23fcd1850efcacd55bb888e7d275e3a02bde3846c80bf0813cecc336bb3",
    "finite_roster_adapter_v3": "e9eef16db86884dc7399566b094ae00a272580cdd390b2a397f231bcd5a5e3f1",
    "finite_roster_adapter_v4": "6b7632488c6c079bb287d4887937c212ad024dce757b3e6a6c4821eb1eabaa5a",
    "targeted_diagnostics_v4": "998061bfe81aaf49eca04a71dbf5bdf1fe573f2877da340d4c143bce71249993",
    "finite_diagnostic_adapter_60s_v2": "79b1c8dc6c24d038c9609b574376eb2455b237867a30da3176fd6a0560b8edb3",
}
CLAIM_FIELDS = {
    "schema", "packet_sha256", "parent", "parent_argv", "child_program_sha256",
    "started_unix", "started_monotonic", "active_deadline_unix",
    "active_deadline_monotonic", "cleanup_deadline_monotonic", "canonical_leases",
    "resources",
}
PACKET_FIELDS = {
    "schema", "status", "operational_ready", "adapter_packet", "runtime",
    "controls", "guard_limits", "binding_refs",
}
RUNTIME_FIELDS = {
    "source_root", "interpreter", "child", "adapter", "custody", "model", "precision_ref",
    "provisional_authority_ref", "closure_ref", "provider_pins", "native_pins", "python_paths", "origin_pins",
    "read_bytes",
}
BINDINGS = {"source_review", "action_review", "resource_decision", "paused_restoration_plan"}


def need(ok: Any, why: str) -> None:
    if not ok:
        raise ValueError(why)


def positive(value: Any) -> bool:
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def reference(ref: Any) -> Path:
    need(type(ref) is dict and set(ref) == {"path", "sha256"}, "closed source reference")
    need(type(ref["path"]) is str and Path(ref["path"]).is_absolute(), "absolute reference")
    sha = ref["sha256"]
    need(type(sha) is str and len(sha) == 64 and set(sha) <= set("0123456789abcdef"), "SHA256 reference")
    return Path(ref["path"])


class Reads:
    """Bounded streaming verification; never follows a final symlink/FIFO."""

    def __init__(self, cap: int) -> None:
        need(type(cap) is int and 0 < cap <= 8 << 30, "reviewed finite read cap")
        self.remaining = cap

    def checked(self, ref: dict[str, Any], *, metadata: bool = False) -> bytes:
        path = reference(ref)
        need(path.resolve() == path, "canonical reference without symlinks")
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            before = os.fstat(fd)
            need(stat.S_ISREG(before.st_mode) and before.st_size <= self.remaining, "regular bounded read")
            need(not metadata or before.st_size <= 2 << 20, "bounded metadata")
            self.remaining -= before.st_size
            sha = hashlib.sha256()
            chunks = []
            size = 0
            while True:
                raw = os.read(fd, min(1 << 20, before.st_size - size + 1))
                if not raw:
                    break
                size += len(raw)
                need(size <= before.st_size, "file grew while hashing")
                sha.update(raw)
                if metadata:
                    chunks.append(raw)
            after = os.fstat(fd)
            stable = lambda value: (value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns)
            need(size == before.st_size and stable(before) == stable(after) == stable(path.lstat()), "file changed while hashing")
            need(sha.hexdigest() == ref["sha256"], "exact authenticated bytes required")
            return b"".join(chunks)
        finally:
            os.close(fd)


def read_json(ref: dict[str, Any]) -> dict[str, Any]:
    value = json.loads(Reads(2 << 20).checked(ref, metadata=True))
    need(type(value) is dict, "metadata object required")
    return value


def birth(pid: int) -> dict[str, Any]:
    raw = Path(f"/proc/{pid}/stat").read_text()
    tail = raw[raw.rfind(")") + 2:].split()
    return {"pid": pid, "start_ticks": int(tail[19]),
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip()}


def flock_line(pid: int, fd: int) -> str:
    locks = [line.split("lock:", 1)[1].strip()
             for line in Path(f"/proc/{pid}/fdinfo/{fd}").read_text().splitlines()
             if line.startswith("lock:") and " FLOCK " in line and " WRITE " in line]
    need(len(locks) == 1, "inherited exclusive FLOCK evidence required")
    return locks[0]


def validate_claim(claim: dict[str, Any], packet_sha256: str, child_sha256: str,
                   now_unix: float, now_monotonic: float) -> None:
    """Pure envelope/deadline gate, followed separately by real kernel checks."""
    need(set(claim) == CLAIM_FIELDS and claim["schema"] == "PR1110_FINITE_PARENT_CLAIM_V1", "closed parent claim")
    need(claim["packet_sha256"] == packet_sha256 and claim["child_program_sha256"] == child_sha256, "claim packet/child mismatch")
    parent = claim["parent"]
    need(type(parent) is dict and set(parent) == {"pid", "start_ticks", "boot_id"}
         and type(parent["pid"]) is int and parent["pid"] > 1
         and type(parent["start_ticks"]) is int and parent["start_ticks"] > 0
         and type(parent["boot_id"]) is str and parent["boot_id"], "actual finite parent identity")
    need(type(claim["parent_argv"]) is list and claim["parent_argv"]
         and all(type(value) is str and value for value in claim["parent_argv"]), "exact parent argv")
    times = [claim[key] for key in ("started_unix", "started_monotonic", "active_deadline_unix",
                                  "active_deadline_monotonic", "cleanup_deadline_monotonic")]
    need(all(positive(value) for value in (*times, now_unix, now_monotonic)), "finite positive parent clocks")
    started, mono, deadline, active, cleanup = times
    need(started <= now_unix < deadline <= EXPIRY and mono <= now_monotonic < active,
         "parent active deadline expired")
    need(0 < deadline - started <= ACTIVE and 0 < active - mono <= ACTIVE
         and 0 < cleanup - active <= CLEANUP and started + cleanup - mono <= EXPIRY,
         "parent bound60+180 diagnostic authority required")
    need(abs((deadline - started) - (active - mono)) <= 0.01
         and abs((now_unix - started) - (now_monotonic - mono)) <= 1.0,
         "parent clock correspondence changed")
    resources = claim["resources"]
    need(type(resources) is dict and set(resources) == {
        "child_cpu_seconds", "child_as_bytes", "inherited_as_limit", "child_file_bytes", "max_stream_bytes", "max_output_bytes"}
         and resources["child_as_bytes"] is None
         and all(type(resources[key]) is int and resources[key] > 0
                 for key in ("child_cpu_seconds", "child_file_bytes", "max_stream_bytes", "max_output_bytes"))
         and resources["child_file_bytes"] <= resources["max_output_bytes"],
         "closed exact child resource limits")
    inherited_as = resources["inherited_as_limit"]
    need(type(inherited_as) is list and len(inherited_as) == 2
         and all(type(value) is int and value >= -1 for value in inherited_as),
         "exact inherited address-space tuple required")
    leases = claim["canonical_leases"]
    need(type(leases) is dict and set(leases) == set(CANONICAL), "all-three canonical claim")
    for name, (path, identity) in CANONICAL.items():
        lease = leases[name]
        need(type(lease) is dict and set(lease) == {"path", "identity", "parent_fd"}
             and lease["path"] == path and lease["identity"] == list(identity)
             and type(lease["parent_fd"]) is int and lease["parent_fd"] >= 0,
             "closed exact canonical lease")


def inherited_before_import(claim: dict[str, Any]) -> None:
    """Same OFD check as retained cfcae5b3, before importing any target source."""
    parent = claim["parent"]
    need(os.getppid() == parent["pid"] and birth(parent["pid"]) == parent, "actual parent changed")
    argv = Path(f"/proc/{parent['pid']}/cmdline").read_bytes().split(b"\0")
    need([value.decode() for value in argv if value] == claim["parent_argv"], "actual parent argv differs")
    for name, (path, identity) in CANONICAL.items():
        info = Path(path).lstat()
        need(stat.S_ISREG(info.st_mode) and (info.st_dev, info.st_ino) == identity, "named canonical identity changed")
        expected = flock_line(parent["pid"], claim["canonical_leases"][name]["parent_fd"])
        matches = []
        for candidate in Path("/proc/self/fd").iterdir():
            try:
                info = os.fstat(int(candidate.name))
            except OSError:
                continue
            if (info.st_dev, info.st_ino) == identity:
                matches.append(int(candidate.name))
        need(matches and all(flock_line(os.getpid(), fd) == expected for fd in matches),
             "missing inherited locked parent OFD")
    need(os.getppid() == parent["pid"] and birth(parent["pid"]) == parent, "parent changed during custody check")
    for path, identity in CANONICAL.values():
        info = Path(path).lstat()
        need(stat.S_ISREG(info.st_mode) and (info.st_dev, info.st_ino) == identity, "canonical identity changed after custody check")


def retained_env_matches(packet: dict[str, Any], claim: dict[str, Any]) -> None:
    raw = os.environ.get("DEEPFIN_FINITE_ALL_THREE_CLAIM")
    need(type(raw) is str and len(raw.encode()) <= 4096, "retained custody environment claim")
    retained = json.loads(raw)
    need(type(retained) is dict and set(retained) == {
        "parent", "leases", "profile", "integrated_runtime", "adapter_sha256"}
         and retained["parent"] == claim["parent"]
         and retained["leases"] == claim["canonical_leases"]
         and retained["profile"] == "all_three"
         and retained["integrated_runtime"] == packet["runtime"]["source_root"]
         and retained["adapter_sha256"] == packet["adapter_packet"]["descriptor"]["source_pins"]["scripts/bt4_queue_consumer_v2.py"],
         "retained and hashed claim bindings differ")


def lower_limits(resources: dict[str, Any]) -> None:
    """Per-process limits only; aggregate sampling/reaping belongs to parent."""
    import resource

    need(resources["child_as_bytes"] is None, "GPU address space must remain inherited/unchanged")
    need(list(resource.getrlimit(resource.RLIMIT_AS)) == resources["inherited_as_limit"],
         "inherited address-space tuple differs; no raise permitted")
    for kind, requested in ((resource.RLIMIT_CPU, resources["child_cpu_seconds"]),
                            (resource.RLIMIT_FSIZE, resources["child_file_bytes"])):
        soft, hard = resource.getrlimit(kind)
        ceiling = requested if hard == resource.RLIM_INFINITY else min(hard, requested)
        lowered = ceiling if soft == resource.RLIM_INFINITY else min(soft, ceiling)
        resource.setrlimit(kind, (lowered, ceiling))


def controls_unchanged(controls: dict[str, Any]) -> None:
    need(type(controls) is dict and set(controls) == {"preserved", "ordinary_pause", "evaluation_stops", "abort_paths"}, "closed controls")
    records = controls["preserved"]
    need(type(records) is list and 7 <= len(records) <= 1024, "bounded preservation roster")
    paths = [record["path"] for record in records]
    need(len(set(paths)) == len(paths), "unique preserved controls")
    stops = controls["evaluation_stops"]
    need(type(stops) is list and len(stops) == 6 and len(set(stops)) == 6
         and set(stops + [controls["ordinary_pause"]]) <= set(paths), "ordinary PAUSE and six evalSTOP bindings")
    reads = Reads(2 << 20)
    for record in records:
        need(type(record) is dict and set(record) == {"path", "present", "sha256"}
             and type(record["present"]) is bool and Path(record["path"]).is_absolute(), "closed marker state")
        if record["path"] in stops + [controls["ordinary_pause"]]:
            need(record["present"], "ordinary PAUSE/evalSTOP must remain present")
        if record["present"]:
            reads.checked({"path": record["path"], "sha256": record["sha256"]}, metadata=True)
        else:
            need(record["sha256"] is None and not os.path.lexists(record["path"]), "absent marker changed")
    aborts = controls["abort_paths"]
    need(type(aborts) is list and len(aborts) == len(set(aborts)) and 4 <= len(aborts) <= 16
         and all(Path(path).is_absolute() for path in aborts)
         and not set(aborts) & set(stops + [controls["ordinary_pause"]]), "private/global abort scope must preserve ordinary PAUSE")
    need(not any(os.path.lexists(path) for path in aborts), "private/global abort marker")


def preimport(packet: dict[str, Any], claim: dict[str, Any], packet_sha256: str) -> None:
    need(set(packet) == PACKET_FIELDS and packet["schema"] == "PR1110_FINITE_CHILD_PACKET_V1"
         and packet["status"] == "APPROVED_EXACT_PRIVATE_60S_DIAGNOSTIC_ONLY"
         and packet["operational_ready"] is True, "inactive child packet")
    runtime = packet["runtime"]
    need(type(runtime) is dict and set(runtime) == RUNTIME_FIELDS, "closed runtime binding")
    validate_claim(claim, packet_sha256, runtime["child"]["sha256"], time.time(), time.monotonic())
    retained_env_matches(packet, claim)
    inherited_before_import(claim)  # MUST precede source/model/library hash reads and target imports.
    lower_limits(claim["resources"])
    reads = Reads(runtime["read_bytes"])
    need(type(packet["binding_refs"]) is dict and set(packet["binding_refs"]) == BINDINGS,
         "closed source/action/resource/restoration bindings")
    for ref in packet["binding_refs"].values():
        reads.checked(ref, metadata=True)
    root = Path(runtime["source_root"])
    need(root.is_absolute() and root.resolve() == root and root.is_dir(), "exact materialized source root")
    adapter_packet = packet["adapter_packet"]
    need(adapter_packet["status"] == "APPROVED_EXACT_PRIVATE_60S_DIAGNOSTIC_ONLY"
         and adapter_packet["operational_ready"] is True
         and positive(adapter_packet["expires_unix"])
         and claim["started_unix"] + claim["cleanup_deadline_monotonic"] - claim["started_monotonic"]
             <= adapter_packet["expires_unix"] <= EXPIRY,
         "exact adapter authority must cover parent active/cleanup window")
    for name, field in (("action_review", "independent_action_review_ref"),
                        ("resource_decision", "root_resource_decision_ref"),
                        ("paused_restoration_plan", "paused_restoration_plan_ref")):
        need(adapter_packet[field] == packet["binding_refs"][name], "adapter/child authority join differs")
    descriptor = adapter_packet["descriptor"]
    need(type(descriptor["source_pins"]) is dict, "dict source pins required")
    need(adapter_packet["runtime_closure_ref"] == runtime["closure_ref"]
         and descriptor["source_pins"].get("scripts/bt4_runtime_closure_v1.json") == runtime["closure_ref"]["sha256"],
         "exact diagnostic adapter/child actual closure join before target/model source reads and imports")
    need({module.replace(".", "/") + ".py" for module in MODULES.values()}
         <= set(descriptor["source_pins"]), "exact retained source-module pins required")
    for relative, sha in descriptor["source_pins"].items():
        path = root / relative
        need(path.is_relative_to(root) and path.resolve() == path, "canonical source pin")
        reads.checked({"path": str(path), "sha256": sha})
    need(Path(sys.executable).resolve() == reference(runtime["interpreter"]), "actual interpreter origin")
    need(Path(__file__).resolve() == reference(runtime["child"]), "actual child origin")
    for name in ("interpreter", "child", "adapter", "custody", "model", "precision_ref", "provisional_authority_ref", "closure_ref"):
        reads.checked(runtime[name], metadata=name.endswith("ref"))
    need(runtime["model"]["sha256"] == MODEL, "exact qualified809 model")
    need(runtime["precision_ref"]["sha256"] == PRECISION
         and runtime["provisional_authority_ref"]["sha256"] == PROVISIONAL_AUTHORITY,
         "retained exact precision and provisional artifact authority")
    for name in ("provider_pins", "native_pins", "origin_pins"):
        need(type(runtime[name]) is dict and runtime[name], "complete provider/native/import pins")
        for ref in runtime[name].values():
            reads.checked(ref)
    need(len(runtime["origin_pins"]) == 43 and REQUIRED_ORIGINS <= set(runtime["origin_pins"]),
         "all43 real library/native/diagnostic origins")
    for name, digest in DIAGNOSTIC_PINS.items():
        expected = {"path": str(root / (name + ".py")), "sha256": digest}
        need(runtime["origin_pins"][name] == expected and descriptor["source_pins"].get(name + ".py") == digest,
             "normal diagnostic/helper source identity")
    need(runtime["adapter"] == runtime["origin_pins"]["finite_diagnostic_adapter_60s_v2"],
         "actual normal adapter is exact runtime origin")
    controls_unchanged(packet["controls"])
    need(set(descriptor["stop_paths"]) == set(packet["controls"]["abort_paths"]), "actual private/global guard scope differs")
    limits = packet["guard_limits"]
    need(type(limits) is dict and set(limits) == {"physical_io_bytes", "minimum_disk_bytes", "output_bytes"}
         and all(positive(value) for value in limits.values())
         and limits["physical_io_bytes"] == 1 and limits["output_bytes"] <= 512 << 20,
         "unchanged measured IO and private output guard")
    need(limits["output_bytes"] == claim["resources"]["max_output_bytes"], "parent/child output limit differs")
    # Pre-import verification consumes active time. Never reset either clock.
    validate_claim(claim, packet_sha256, runtime["child"]["sha256"], time.time(), time.monotonic())
    inherited_before_import(claim)


def output_bytes() -> int:
    total = count = 0
    for parent, directories, filenames in os.walk(PRIVATE, followlinks=False):
        for name in (*directories, *filenames):
            path = Path(parent) / name
            info = path.lstat()
            need(stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode), "private output symlink/special file")
            count += 1
            need(count <= 4096, "bounded private output tree")
            if stat.S_ISREG(info.st_mode):
                total += info.st_size
    return total


def prepare_private() -> None:
    """Only after authenticated preflight; preserve any failed partial tree."""
    need(PRIVATE.parent.resolve() == PRIVATE.parent and PRIVATE.parent.is_dir()
         and not os.path.lexists(PRIVATE), "fresh private external anchor required")
    PRIVATE.mkdir(mode=0o700)
    unit = PRIVATE / "unit-000000000000"
    unit.mkdir(mode=0o700)
    (unit / "attempt-00").mkdir(mode=0o700)


class ParentDeadlineGuard:
    """Retained OwnerGuard plus the exact inherited monotonic deadline."""

    def __init__(self, retained: Any, claim: dict[str, Any], controls: dict[str, Any]) -> None:
        self.retained, self.claim, self.controls = retained, claim, controls
        self.output_root, self.stop_paths, self.limits = retained.output_root, retained.stop_paths, retained.limits

    def check(self) -> None:
        need(time.monotonic() < self.claim["active_deadline_monotonic"], "parent monotonic deadline")
        controls_unchanged(self.controls)
        self.retained.check()

    def charge(self, count: int) -> None:
        self.check()
        self.retained.charge(count)
        self.check()


def load_and_run(packet: dict[str, Any], claim: dict[str, Any]) -> dict[str, Any]:
    """Only entered after stdlib custody, identity, controls and byte checks."""
    runtime = packet["runtime"]
    root = Path(runtime["source_root"])
    custody_spec = importlib.util.spec_from_file_location("pr1110_bound_custody", runtime["custody"]["path"])
    need(custody_spec is not None and custody_spec.loader is not None, "pinned retained custody loader")
    custody = importlib.util.module_from_spec(custody_spec)
    custody_spec.loader.exec_module(custody)
    # Actual retained API, same consumer adapter5e622 and mechanical binding.
    # The child entry has its own independent parent/argv/source pin.
    custody.check_inherited_child(root / "scripts/bt4_queue_consumer_v2.py")
    paths = runtime["python_paths"]
    need(type(paths) is list and len(paths) == len(set(paths)) and len(paths) <= 8
         and all(Path(path).is_absolute() and Path(path).resolve() == Path(path) for path in paths), "explicit qualified import paths")
    sys.path[:0] = [str(root), *paths]
    loaded = {name: importlib.import_module(module) for name, module in MODULES.items()}
    for name, module in loaded.items():
        expected = root / (MODULES[name].replace(".", "/") + ".py")
        need(Path(module.__file__).resolve() == expected, "loaded retained module origin differs")
    need(loaded["inherited"].canonical_profile("all_three") == CANONICAL, "retained canonical profile differs")
    loaded["inherited"].inherited(claim["parent"], claim["canonical_leases"])
    binding = loaded["model_binding"].require_bound()
    need(binding["model_path"] == runtime["model"]["path"]
         and loaded["entry"].MODEL == runtime["model"]["path"]
         and binding["model_sha256"] == MODEL and binding["arithmetic_precision"] == "fp16"
         and binding["raw_sanity_ref"] == runtime["precision_ref"]
         and binding["provisional_authority_ref"] == runtime["provisional_authority_ref"],
         "actual loaded model/precision binding differs")
    adapter = importlib.import_module("finite_diagnostic_adapter_60s_v2")
    need(Path(adapter.__file__).resolve() == reference(runtime["adapter"]),
         "normal runtime adapter origin differs")
    entry, consumer = loaded["entry"], loaded["consumer"]
    # No ordinary owner_limits(): it requires a real live queue phase which this
    # private unit does not possess. The absolute deadline is already parent-bound.
    limits = {**packet["guard_limits"], "deadline_unix": claim["active_deadline_unix"]}
    retained = consumer.OwnerGuard(claim["parent"], claim["canonical_leases"], limits,
                                   entry.physical_io(), entry.physical_io, output_bytes,
                                   packet["controls"]["abort_paths"], PRIVATE)
    guard = ParentDeadlineGuard(retained, claim, packet["controls"])
    guard.check()
    entry.verify_runtime_closure()
    # Force only the actual worker import; no session/model is opened here.
    importlib.import_module("scripts.bt4_root_policy_worker")
    importlib.import_module("onnxruntime")  # identity only; no session/model construction
    for name, ref in runtime["origin_pins"].items():
        module = sys.modules.get(name)
        need(module is not None and Path(module.__file__).resolve() == reference(ref), "actual loaded import origin differs")
    guard.check()
    result = adapter.run_prepared(packet["adapter_packet"], entry=entry, consumer=consumer,
                                  recovery=loaded["recovery"], guard=guard,
                                  parent=claim["parent"], leases=claim["canonical_leases"],
                                  priority_module=loaded["priority"])
    controls_unchanged(packet["controls"])
    return result


def execute(packet_ref: dict[str, Any], claim_ref: dict[str, Any]) -> dict[str, Any]:
    # Retained spawn blocks these across Popen; restore delivery immediately,
    # before metadata/hash work. No custom handler or signal is installed/sent.
    signal.pthread_sigmask(signal.SIG_UNBLOCK, {signal.SIGINT, signal.SIGTERM})
    packet, claim = read_json(packet_ref), read_json(claim_ref)
    preimport(packet, claim, packet_ref["sha256"])
    prepare_private()
    return load_and_run(packet, claim)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument("--packet", required=True)
    parser.add_argument("--packet-sha256", required=True)
    parser.add_argument("--parent-claim", required=True)
    parser.add_argument("--parent-claim-sha256", required=True)
    args = parser.parse_args()
    result = execute({"path": args.packet, "sha256": args.packet_sha256},
                     {"path": args.parent_claim, "sha256": args.parent_claim_sha256})
    raw = json.dumps(result, sort_keys=True, allow_nan=False)
    need(len(raw.encode()) <= 512 << 10, "bounded child correctness result")
    print(raw, flush=True)


if __name__ == "__main__":
    main()
