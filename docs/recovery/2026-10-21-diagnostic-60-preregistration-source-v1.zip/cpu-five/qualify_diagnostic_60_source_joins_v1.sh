#!/bin/bash
set -euo pipefail
umask 077
helper=/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-sixty-second-diagnostic-draft-v1/qualify_diagnostic_60_source_joins_v1.py
 test ! -e /tmp/pr1110-diagnostic-60-source-joins-20261021-v1
 test "$(sha256sum "$helper" | cut -d ' ' -f1)" = 57ad31ba49d6feacfb3f048ea549294c89384631645ee175d943e46070fcb578
exec /usr/bin/python3.10 -I -S -B "$helper"
