"""UNRUN five-case pure source-join gate. No target module-body/native/model import.

Whole exact modules loaded; not AST extraction. Source module imports are stdlib
only except adapter's existing pure baseV3. No main/launcher function is invoked.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import stat
import sys
import time
import unittest

SOURCE = Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5/bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake')
DRAFT = SOURCE / 'pr1110-sixty-second-diagnostic-draft-v1'
REPORT = Path('/tmp/pr1110-diagnostic-60-source-joins-20261021-v1')
PINS = {
    'parent': (DRAFT / 'parent_diagnostic_60s_v1.py', '2a465f8ecb1948e6bd8fc00038208b9cee3cdee95cdfc5182b2fc0e2fb28275b'),
    'child': (DRAFT / 'finite_diagnostic_child_60s_v1.py', 'd96826ca415b35fbcdb43317b6a8b96f668cd655f099b407122bcbcb9658991e'),
    'base': (SOURCE.parents[2] / 'worktree-affinity/docs/intake/pr1110-targeted-diagnostics-v1/finite_roster_adapter_v3.py',
             'e9eef16db86884dc7399566b094ae00a272580cdd390b2a397f231bcd5a5e3f1'),
    'adapter': (DRAFT / 'finite_diagnostic_adapter_60s_v2.py', '79b1c8dc6c24d038c9609b574376eb2455b237867a30da3176fd6a0560b8edb3'),
    'tests': (DRAFT / 'test_diagnostic_60_source_joins_v1.py', '73842153482210a50cd34f5a9e69bef45ae22f3b42a156cbf836b24bd2dc88e1'),
}
NAMES = [
    'test_actual_parent_claim_and_child_accept60_240',
    'test_actual_child_and_parent_refuse_old300_and_cleanup181',
    'test_wrong_closure_refuses_before_source_or_model_reads',
    'test_matching_closure_reaches_first_source_boundary',
    'test_actual_adapter_primary_error_no_old_complete_predicate',
]
started = time.monotonic()


def need(ok, why):
    if not ok:
        raise ValueError(why)


def pinned(path, digest):
    need(path.resolve() == path and not path.is_symlink(), 'canonical pinned source')
    before = path.stat()
    need(stat.S_ISREG(before.st_mode) and before.st_size <= 1 << 20, 'bounded whole source')
    raw = path.read_bytes()
    after = path.stat()
    stamp = lambda info: (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)
    need(stamp(before) == stamp(after) and hashlib.sha256(raw).hexdigest() == digest, 'whole module source changed')


def owned(path, directory_fd=None):
    if not isinstance(path, (str, bytes, os.PathLike)):
        return False
    target = Path(os.fsdecode(path))
    if not target.is_absolute():
        target = (Path(os.readlink('/proc/self/fd/' + str(directory_fd)))
                  if isinstance(directory_fd, int) and directory_fd >= 0 else Path.cwd()) / target
    return target.resolve(strict=False).is_relative_to(REPORT)


def audit(event, args):
    if event in {'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn', 'socket.connect',
                 'socket.bind', 'fcntl.flock', 'fcntl.lockf', 'os.link', 'os.symlink', 'sqlite3.connect'}:
        raise RuntimeError('source joins forbid child/network/lease/link/SQLite')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        name, mode, flags = os.fsdecode(args[0]), args[1], args[2]
        need(not name.endswith(('.onnx', '.pt', '.pth', '.safetensors'))
             and not name.startswith(('/home/josh/projects/chess/', '/tmp/deepfin-pr1110-production-')),
             'no actual project/model payload reads')
        writing = ((isinstance(mode, str) and any(char in mode for char in 'wax+'))
                   or bool(isinstance(flags, int) and flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC)))
        need(not writing or owned(name), 'no external source-join write')
    if event in {'os.mkdir', 'os.rmdir', 'os.remove', 'os.chmod'}:
        need(owned(args[0], args[2] if event in {'os.mkdir', 'os.chmod'} else args[1]), 'private source-join mutation')
    if event == 'os.rename':
        need(owned(args[0], args[2]) and owned(args[1], args[3]), 'private source-join rename')


for kind, bound in ((resource.RLIMIT_CPU, 10), (resource.RLIMIT_AS, 512 << 20)):
    soft, hard = resource.getrlimit(kind)
    resource.setrlimit(kind, (min(v for v in (soft, bound) if v >= 0), min(v for v in (hard, bound) if v >= 0)))
need(sys.version_info[:2] == (3, 10) and sys.flags.isolated and sys.flags.no_site
     and sys.flags.dont_write_bytecode and sys.flags.optimize == 0, 'isolated CP310 source-only gate')
need(os.environ.get('CUDA_VISIBLE_DEVICES') == '' and sorted(os.sched_getaffinity(0)) == [29, 30], 'CPU-only affinity')
need(hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest() ==
     'a2f33a6e006989270f4340528eb61f8f97366e00a5d1b602ac8672ea44fc56ae', 'qualified interpreter')
need(not os.path.lexists(REPORT), 'fresh create-only source-join report')
for path, digest in PINS.values():
    pinned(path, digest)
REPORT.mkdir(mode=0o700)
sys.addaudithook(audit)
loaded = {}
for role in ('parent', 'child', 'base', 'adapter', 'tests'):
    path, digest = PINS[role]
    name = 'finite_roster_adapter_v3' if role == 'base' else '_pr1110_join_' + role
    spec = importlib.util.spec_from_file_location(name, path)
    need(spec is not None and spec.loader is not None and name not in sys.modules, 'exact whole source loader')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    need(Path(module.__file__).resolve() == path, 'actual loaded source identity')
    loaded[role] = module
for role in ('parent', 'child', 'base', 'adapter'):
    setattr(loaded['tests'], role, loaded[role])
loaded['tests'].REPORT = REPORT
suite = unittest.TestSuite(loaded['tests'].JoinControls(name) for name in NAMES)
result = unittest.TextTestRunner(verbosity=2).run(suite)
for path, digest in PINS.values():
    pinned(path, digest)
need(result.wasSuccessful() and result.testsRun == 5 and not result.skipped, 'exact five source-join controls')
need(not any(name.split('.')[0] in {'torch', 'numpy', 'onnxruntime', 'chess_anti_engine', 'scripts'}
             for name in sys.modules), 'no actual target/project/native module body loaded')
files = [path for path in REPORT.rglob('*') if path.is_file()]
need(len(files) <= 64 and sum(path.stat().st_size for path in files) <= 1 << 20, 'small private report postcheck')
actual = {'status': 'FIVE_SOURCE_JOIN_CONTROLS_PASS', 'tests': NAMES, 'tests_run': result.testsRun,
          'whole_module_sources': {role: {'path': str(path), 'sha256': digest} for role, (path, digest) in PINS.items()},
          'scope': 'Pure source functions and explicit environment/OFD/read/project-caller doubles only; no actual custody, runtime import, model/GPU or full-unit qualification.',
          'actual_project_module_bodies_loaded': False, 'children_authorized': False,
          'elapsed_seconds': time.monotonic() - started, 'cpu_seconds': sum(resource.getrusage(resource.RUSAGE_SELF)[:2]),
          'training_credit': 0, 'product_credit': 0,
          'bounds': 'CPU10/AS512MiB lower-only; outer30+5; output postcheck only, not hard aggregate read/RSS/pipe quotas'}
with (REPORT / 'actual.json').open('x') as stream:
    json.dump(actual, stream, sort_keys=True)
    stream.write('\n')
print(json.dumps(actual, sort_keys=True), flush=True)
