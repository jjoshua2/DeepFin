"""Five stdlib source-join controls; no runtime/native/model qualification.

Runner injects exact hash-authenticated whole modules parent/child/adapter/base.
Environment/OFD/limit seams in preimport-only cases are explicit CPU doubles;
there is no claim of real custody or actual target source reads in these cases.
"""
import copy
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

parent = child = adapter = base = REPORT = None  # Supplied by pinned source-only runner.


class SourceReadBoundary(Exception):
    pass


def claim_fixture():
    resources = {"child_cpu_seconds": 300, "child_as_bytes": None,
                 "inherited_as_limit": [-1, -1], "child_file_bytes": 32 << 20,
                 "max_stream_bytes": 1 << 20, "max_output_bytes": 512 << 20}
    packet = {"expires_unix": 1000.0, "sources": {
        "child_packet": {"sha256": "a" * 64}, "child": {"sha256": "b" * 64}},
        "resources": resources}
    leases = {name: {"path": path, "identity": list(identity), "parent_fd": 3 + i}
              for i, (name, (path, identity)) in enumerate(child.CANONICAL.items())}
    custody = {"parent": {"pid": 12345, "start_ticks": 54321, "boot_id": "CPU-DOUBLE-NOT-LIVE"},
               "leases": leases}
    return packet, custody


class JoinControls(unittest.TestCase):
    def test_actual_parent_claim_and_child_accept60_240(self):
        packet, custody = claim_fixture()
        claim = parent.deadline_claim(packet, custody, ["CPU-DOUBLE-ARGV"], 100.0, 1000.0)
        self.assertEqual((claim["active_deadline_unix"], claim["active_deadline_monotonic"],
                          claim["cleanup_deadline_monotonic"]), (160.0, 1060.0, 1240.0))
        child.validate_claim(claim, "a" * 64, "b" * 64, 101.0, 1001.0)

    def test_actual_child_and_parent_refuse_old300_and_cleanup181(self):
        packet, custody = claim_fixture()
        claim = parent.deadline_claim(packet, custody, ["CPU-DOUBLE-ARGV"], 100.0, 1000.0)
        for changed in ({"active_deadline_unix": 400.0, "active_deadline_monotonic": 1300.0,
                         "cleanup_deadline_monotonic": 1480.0},
                        {"cleanup_deadline_monotonic": 1241.0}):
            with self.subTest(changed=changed), self.assertRaisesRegex(ValueError, "60.*180"):
                child.validate_claim({**claim, **changed}, "a" * 64, "b" * 64, 101.0, 1001.0)
        old_packet = dict.fromkeys(parent.PACKET_KEYS)
        old_packet.update(schema="PR1110_FINITE_CORRECTNESS_PARENT_PACKET_V1", attempt="cpu-negative",
                          issued_unix=90.0, expires_unix=1000.0,
                          geometry={**parent.GEOMETRY, "active_seconds": 300})
        with self.assertRaisesRegex(ValueError, "geometry"):
            parent.validate_packet(old_packet, 100.0)

    def preimport_boundary(self, *, mismatch):
        root = REPORT / ("mismatch" if mismatch else "matching")
        root.mkdir()
        closure = {"path": str(root / "scripts/bt4_runtime_closure_v1.json"), "sha256": "c" * 64}
        runtime = dict.fromkeys(child.RUNTIME_FIELDS)
        runtime.update(source_root=str(root), child={"sha256": "b" * 64}, read_bytes=1024,
                       closure_ref=closure)
        descriptor = {"source_pins": {"scripts/bt4_runtime_closure_v1.json": "c" * 64,
            **{name.replace(".", "/") + ".py": "d" * 64 for name in child.MODULES.values()}}}
        bindings = {name: {"path": str(root / (name + ".json")), "sha256": "e" * 64}
                    for name in child.BINDINGS}
        ap = {"status": adapter.STATUS, "operational_ready": True, "expires_unix": 1000.0,
              "descriptor": descriptor, "runtime_closure_ref": copy.deepcopy(closure),
              "independent_action_review_ref": bindings["action_review"],
              "root_resource_decision_ref": bindings["resource_decision"],
              "paused_restoration_plan_ref": bindings["paused_restoration_plan"]}
        if mismatch:
            ap["runtime_closure_ref"]["sha256"] = "f" * 64
        packet = dict.fromkeys(child.PACKET_FIELDS)
        packet.update(schema="PR1110_FINITE_CHILD_PACKET_V1", status=adapter.STATUS,
                      operational_ready=True, runtime=runtime, adapter_packet=ap, binding_refs=bindings)
        basic, custody = claim_fixture()
        claim = parent.deadline_claim(basic, custody, ["CPU-DOUBLE-ARGV"], 100.0, 1000.0)
        metadata_reads, target_reads = [], []
        class FakeReads:
            def __init__(self, cap):
                pass
            def checked(self, ref, metadata=False):
                if metadata:
                    metadata_reads.append(ref)
                    return b"{}"
                target_reads.append(ref)
                raise SourceReadBoundary("first target-source boundary; no payload read")
        clock = SimpleNamespace(time=lambda: 101.0, monotonic=lambda: 1001.0)
        with patch.object(child, "time", clock), patch.object(child, "Reads", FakeReads), \
             patch.object(child, "retained_env_matches"), patch.object(child, "inherited_before_import"), \
             patch.object(child, "lower_limits"):
            expected = ValueError if mismatch else SourceReadBoundary
            with self.assertRaises(expected) as caught:
                child.preimport(packet, claim, "a" * 64)
        self.assertEqual(len(metadata_reads), len(child.BINDINGS))
        self.assertEqual(len(target_reads), 0 if mismatch else 1)
        if mismatch:
            self.assertIn("closure join", str(caught.exception))

    def test_wrong_closure_refuses_before_source_or_model_reads(self):
        self.preimport_boundary(mismatch=True)

    def test_matching_closure_reaches_first_source_boundary(self):
        self.preimport_boundary(mismatch=False)

    def test_actual_adapter_primary_error_no_old_complete_predicate(self):
        root = REPORT / "adapter-private"
        root.mkdir()
        runtime = REPORT / "runtime-double"
        entry = SimpleNamespace(__file__=str(runtime / "scripts/bt4_queue_worker_entry_v3.py"), Checkpoint=object)
        descriptor = {"unit": 0, "attempt": 0, "prior_roots": [], "external_root": str(root),
                      "generation": adapter.GENERATION, "block_seconds": 60,
                      "source_pins": {"targeted_diagnostics_v4.py": adapter.HELPER4_SHA256,
                                      "scripts/bt4_runtime_closure_v1.json": "c" * 64}}
        packet = dict(status=adapter.STATUS, operational_ready=True, descriptor=descriptor,
            descriptor_sha256=adapter.digest(descriptor), expires_unix=200.0,
            independent_action_review_ref={}, root_resource_decision_ref={}, paused_restoration_plan_ref={},
            runtime_closure_ref={"path": str(runtime / "scripts/bt4_runtime_closure_v1.json"), "sha256": "c" * 64})
        primary = TimeoutError("CPU-double original guard deadline")
        calls = []
        def fail(roster, **kwargs):
            calls.append((roster, kwargs))
            self.assertEqual(kwargs["deadline_seconds"], 1.0)
            self.assertEqual(kwargs["max_live_games"], 64)
            self.assertIs(kwargs["fake_cpu"], False)
            raise primary
        class TraceDouble:
            def __init__(self, *args, **kwargs):
                self.exit_error = None
            def __enter__(self):
                return self
            def __exit__(self, typ, error, tb):
                self.exit_error = error
                return False
        scripts = ModuleType("scripts")
        scripts.__path__ = []
        owner = ModuleType("scripts.shared_teacher_owner")
        owner.run_owned_roster = fail
        worker = ModuleType("scripts.bt4_root_policy_worker")
        worker.BT4GamePool = object
        evaluator = ModuleType("scripts.bt4_generation_evaluator")
        evaluator.BT4OnnxEvaluator = object
        helper = ModuleType("targeted_diagnostics_v4")
        helper.TargetedDiagnostics = TraceDouble
        modules = {"scripts": scripts, owner.__name__: owner, worker.__name__: worker,
                   evaluator.__name__: evaluator, helper.__name__: helper}
        with patch.object(adapter, "PRIVATE_ROOT", root), patch.object(adapter.time, "time", lambda: 100.0), \
             patch.object(base, "verify_complete", side_effect=AssertionError("old full-unit predicate called")), \
             patch.dict(sys.modules, modules):
            authorize = adapter.finite_authorizer(descriptor, adapter.digest(descriptor), 200.0)
            authorize({adapter.NAME: descriptor}, root / "coordinator")
            with self.assertRaises(ValueError):
                authorize({adapter.NAME: descriptor}, root / "wrong")
            with self.assertRaises(TimeoutError) as caught:
                adapter.run_prepared(packet, entry=entry, consumer=object(), recovery=object(),
                    guard=SimpleNamespace(output_root=root, limits={"deadline_unix": 101.0}),
                    parent={}, leases={"gpu": {}, "io": {}, "supervisor": {}}, priority_module=object())
        self.assertIs(caught.exception, primary)
        self.assertEqual(len(calls), 1)
        self.assertIs(primary.targeted_diagnostics.exit_error, primary)
        self.assertIs(primary.targeted_quiescence.primary_error, primary)
