# Durability V4 — SOURCE ONLY, UNRUN

V3 files remain frozen and held; entry-only cadence did not guarantee durable
evidence of an early blocked first execute. V4 is a distinct helper requiring
frozen V1/V2 only. It adds one mandatory first-execute pre-call publication even
before20s, and one best-effort forced first-return/raise publication. Failed
first pre publication refuses original execution; subsequent calls cannot bypass
that failed mandatory gate. A target exception, once actually called, retains
identity even if post-publication fails. Existing owner/guard/custody/STOP/
deadline behavior remains unchanged. No thread, profiler or guard hook is added.

Initial entered and mandatory first-pre files each require exclusive staging,
file fsync, create-only link, stage unlink and directory fsync. First-pre state
records attempts1/inflight1/calls_entered0: it is pending at publication, not
evidence that inference ran. A normal first post records calls_entered1/returns1/
inflight0; exceptional post records raises1/inflight0. Timing is wall nanoseconds
around original execute only, excluding diagnostic IO; it is not GPU kernel
timing. Every snapshot labels state-at-publication, not current inflight at
closure, and stays PARTIAL_DIAGNOSTIC_ONLY/non-final/no-admission.

Fixed slot-attempt ceiling17 = entered + first pre + first post + at most14
opportunistic20s cadence attempts. Independent4MiB conservative byte budget
charges stage+final names for every during attempt and reserves V2 final/deferred
final stage+final capacity. Bytes may exhaust before17; maximum-size17 files do
not all fit. Snapshots run outside event/state locks under a nonblocking publish
lock. First post and cadence failures record bounded errors without replacing
target returns/errors. Mandatory pre failure is a diagnostic refusal before
target invocation. Long calls without callbacks guarantee no20/40s cadence; the
first durable pending record survives but wall duration cannot be finished
until the call returns. No cause/guard-share/full128/speed claim is introduced.

Stdlib API: run_source_controls(case_root) returns exactly these seven IDs:

1. initial_publication_failure_failclosed
2. first_execute_pre_and_post_before_cadence
3. first_execute_publication_failure_original_not_called
4. first_post_io_failure_preserves_original_exception
5. cadence_count_byte_bounds_and_restore
6. early_byte_exhaustion_preserves_prior_snapshot_and_return
7. nonquiescent_ownership_until_explicit_quiescence

run_termination_controls(case_root, run_owned_termination) returns exactly:

1. owned_SIGTERM_inside_first_execute_after_pending_ack
2. owned_SIGKILL_inside_first_execute_after_pending_ack

The sole runner callback takes pinned_child_source, snapshot_path, signum and
returns {ack:{durable_snapshot,sha256,pid},returncode,kernel_ECHILD}. Runner owns
exact Popen/PIDfd identity, bounded ACK wait/streams, signals only that child and
finally cleanup/reap. At most one child live; exactly two sequential fault cases.
Child normal imports only stdlib and pinned helpers from explicitly prefixed
private capsule. It enters the FIRST original evaluator method, verifies the
durable pending slot1, prints ACK and signal.pause loops inside that method.
Default SIGTERM/SIGKILL before first return/context exit must leave pending slot1
hash unchanged, no post slot2 and no normal final trace. There is no actual model,
project/native library or inference in these boundary doubles.

Runner author separately binds CP310/-I/-S/-B, source/helper origins and absent
private capsule,60+30/CPU60/AS512MiB lower-only,<=4MiB output/16MiB named reads/
1MiB streams. Source controls use no child; fault child has inherited lower
CPU10 and runner deadline. No gate/tests/imports/compilation/model/GPU/guest work
were executed during authoring. Source and fault cases require independent
review and root execution decision before any run. No finite retry authorized.
