Durability V4 passed eleven scoped CPU observations across three groups: seven
source controls, two owned-child SIGTERM/SIGKILL cases after a durable pending
snapshot acknowledgement, and two controller failure-retention controls. The
evidence establishes persistence for these boundary tests, including termination
inside the first evaluator call; saved pending state is not proof of model
inference or current work at closure. Frozen sources, exact runner/argv, reviews
and raw terminal streams are preserved in the accompanying durability archive
and manifest. The historical plan's CPU60 wording is corrected by a separate
CPU10-per-process supplement. No model/GPU, real roster/full128, speed, product,
training, adoption or future-execution credit follows from this CPU result.
