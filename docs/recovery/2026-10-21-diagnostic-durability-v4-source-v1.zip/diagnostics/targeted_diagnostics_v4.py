"""UNRUN V4 first-boundary durable diagnostics; no new threads, guards or scheduler."""
from functools import wraps
import json
import os
import threading
import time
from targeted_diagnostics_v2 import TargetedDiagnostics as _V2


class TargetedDiagnostics(_V2):
    CADENCE_SECONDS = 20
    MAX_DURING_ATTEMPTS = 17  # Entry + first pre + first post + at most14 cadence attempts.
    MAX_PAYLOAD_BYTES = 196608
    TOTAL_DIAGNOSTIC_BYTES = 4 << 20
    # Reserve worst-case final + deferred-final, each with a leftover hardlink.
    DURING_BYTE_BUDGET = TOTAL_DIAGNOSTIC_BYTES - 4 * MAX_PAYLOAD_BYTES

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._checkpoint_lock = threading.Lock()
        self._next_checkpoint = 0.0
        self._during_attempts = 0
        self._during_charged_bytes = 0
        self.last_durable_checkpoint = None
        self.execute_attempts = self.execute_returns = self.execute_raises = 0
        self.execute_wall_ns = 0
        self.execute_calls_entered = self.execute_pre_refused = 0
        self._first_execute_claimed = False
        self._first_pre_durable = False
        self._first_pre_attempted = self._first_post_attempted = False
        self._cadence_attempts = 0

    def snapshot(self):
        result = super().snapshot()
        with self.lock:
            result.update(execute_attempts=self.execute_attempts,
                execute_returns=self.execute_returns, execute_raises=self.execute_raises,
                execute_inflight=self.execute_attempts - self.execute_returns - self.execute_raises - self.execute_pre_refused,
                execute_calls_entered=self.execute_calls_entered, execute_pre_refused=self.execute_pre_refused,
                execute_wall_ns=self.execute_wall_ns,
                timing_semantics="execute Python boundary wall time, not GPU kernel time; includes original validation/dispatch",
                during_snapshot_attempts=self._during_attempts,
                during_snapshot_conservative_charged_bytes=self._during_charged_bytes)
        return result

    def checkpoint(self, *, entered=False, first_execute_pre=False, first_execute_post=False):
        """Best effort bounded create-only publication on an existing caller.

        No retries, blocking checkpoint lock, worker creation or final verdict.
        Existing event/timing locks must be released before this method is called.
        """
        if not self.active or not self._checkpoint_lock.acquire(blocking=False):
            return False
        try:
            now = time.monotonic()
            force = entered or first_execute_pre or first_execute_post
            if sum(map(int, (entered, first_execute_pre, first_execute_post))) > 1:
                return False
            if first_execute_pre and self._first_pre_attempted:
                return False
            if first_execute_post and self._first_post_attempted:
                return False
            if not force and self._cadence_attempts >= 14:
                return False
            if entered and self._during_attempts != 0:
                return False
            if self._during_attempts >= self.MAX_DURING_ATTEMPTS:
                return False
            if not force and now < self._next_checkpoint:
                return False
            self._first_pre_attempted |= first_execute_pre
            self._first_post_attempted |= first_execute_post
            if not force:
                self._cadence_attempts += 1
            slot = self._during_attempts
            self._during_attempts += 1
            self._next_checkpoint = now + self.CADENCE_SECONDS
            snapshot = self.snapshot()  # No event lock is held here.
            snapshot.update(snapshot_phase=("entered" if entered else "first_execute_pending" if first_execute_pre else
                                "first_execute_post" if first_execute_post else "during_work"),
                            state_at_publication_only_not_current_at_closure=True,
                            first_pending_is_not_inference_proof=True,
                            snapshot_monotonic_seconds=now, snapshot_pid=os.getpid(),
                            snapshot_thread=threading.get_ident(),
                            snapshot_thread_final=False, snapshot_slot=slot)
            raw = json.dumps(snapshot, sort_keys=True, allow_nan=False).encode()
            if len(raw) > self.MAX_PAYLOAD_BYTES:
                raise ValueError("during snapshot payload bound")
            charge = 2 * len(raw)
            if self._during_charged_bytes + charge > self.DURING_BYTE_BUDGET:
                self._during_attempts = self.MAX_DURING_ATTEMPTS
                with self.lock:
                    self._error("during snapshot byte budget exhausted")
                return False
            # Charge before filesystem operations even if an incomplete stage
            # survives. Stage+final may reference the same inode but count twice
            # in the existing output meter; never undercharge that possibility.
            self._during_charged_bytes += charge
            target = self.path.with_name(self.path.name + f".during-{slot:02d}.json")
            staging = target.with_name(target.name + ".partial")
            with staging.open("xb") as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.link(staging, target)
            staging.unlink()
            directory = os.open(self.path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            try:
                os.fsync(directory)
            finally:
                os.close(directory)
            self.last_durable_checkpoint = target
            return True
        except BaseException as error:
            with self.lock:
                self._error("during snapshot failed: " + type(error).__name__)
            return False
        finally:
            self._checkpoint_lock.release()

    def _event(self, *args, **kwargs):
        super()._event(*args, **kwargs)
        self.checkpoint()

    def _patch(self, cls, name, wrapper):
        if name == "execute":
            trace = self
            def timed(original):
                @wraps(original)
                def execute(instance, prepared):
                    if not trace.active:
                        return original(instance, prepared)
                    trace._batch(prepared)
                    with trace.lock:
                        trace.execute_attempts = min(2**63 - 1, trace.execute_attempts + 1)
                        first = not trace._first_execute_claimed
                        trace._first_execute_claimed = True
                    if first:
                        if not trace.checkpoint(first_execute_pre=True):
                            with trace.lock:
                                trace.execute_pre_refused = min(2**63 - 1, trace.execute_pre_refused + 1)
                            raise RuntimeError("durable first execute pending snapshot required")
                        trace._first_pre_durable = True
                    else:
                        if not trace._first_pre_durable:
                            with trace.lock:
                                trace.execute_pre_refused = min(2**63 - 1, trace.execute_pre_refused + 1)
                            raise RuntimeError("durable first execute pending snapshot required")
                        trace.checkpoint()
                    with trace.lock:
                        trace.execute_calls_entered = min(2**63 - 1, trace.execute_calls_entered + 1)
                    started = time.monotonic_ns()
                    returned = False
                    try:
                        result = original(instance, prepared)
                        returned = True
                        return result
                    finally:
                        # Observation cannot replace the original return/error.
                        try:
                            elapsed = max(0, time.monotonic_ns() - started)
                            with trace.lock:
                                ceiling = 2**63 - 1
                                trace.execute_returns = min(ceiling, trace.execute_returns + int(returned))
                                trace.execute_raises = min(ceiling, trace.execute_raises + int(not returned))
                                trace.execute_wall_ns = min(ceiling, trace.execute_wall_ns + elapsed)
                            trace.checkpoint(first_execute_post=first)
                        except BaseException as error:
                            trace._error("execute timing failed: " + type(error).__name__)
                return execute
            wrapper = timed
        return super()._patch(cls, name, wrapper)

    def __enter__(self):
        result = super().__enter__()
        if not self.checkpoint(entered=True):
            # No target body has run. Do not admit a model call without a durable
            # entered witness; retain V2 cleanup/ownership behavior on failure.
            error = RuntimeError("durable entered diagnostic snapshot required")
            self.__exit__(type(error), error, None)
            raise error
        return result
