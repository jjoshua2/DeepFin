"""UNRUN stdlib fault child; ACK inside first original execute, then block."""
import hashlib
import json
import os
from pathlib import Path
import signal
import sys
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parent))  # Pinned private capsule only.
from targeted_diagnostics_v4 import TargetedDiagnostics


class Pool:
    def __init__(self, *, commit, make_stepper):
        self.commit, self.make_stepper = commit, make_stepper


class Checkpoint:
    def record_game(self, attempt, game_id, receipt):
        return True


class Evaluator:
    def execute(self, prepared):
        durable = trace.last_durable_checkpoint
        raw = durable.read_bytes()
        saved = json.loads(raw)
        assert saved["snapshot_phase"] == "first_execute_pending"
        assert saved["execute_attempts"] == saved["execute_inflight"] == 1
        assert saved["execute_calls_entered"] == 0  # State at publication before this call.
        print(json.dumps({"durable_snapshot": str(durable),
            "sha256": hashlib.sha256(raw).hexdigest(), "pid": os.getpid()}), flush=True)
        while True:
            signal.pause()  # Default SIGTERM/SIGKILL occurs before return/context exit.


trace = TargetedDiagnostics(Pool, Checkpoint, Evaluator, Path(sys.argv[1]),
    expected_origins={key: __file__ for key in ("pool", "checkpoint", "evaluator")},
    quiescent=lambda: False)
with trace:
    Evaluator().execute(SimpleNamespace(inference=SimpleNamespace(feed=SimpleNamespace(shape=(32,)))))
