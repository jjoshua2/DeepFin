"""UNRUN seven stdlib source controls plus two actual owned-child fault cases."""
import hashlib
import json
from pathlib import Path
import signal
from types import SimpleNamespace
from unittest.mock import patch
from targeted_diagnostics_v4 import TargetedDiagnostics


class Pool:
    def __init__(self, *, commit, make_stepper):
        self.commit, self.make_stepper = commit, make_stepper


class Checkpoint:
    def record_game(self, attempt, game_id, receipt):
        return True


class Evaluator:
    calls = 0
    def execute(self, prepared):
        Evaluator.calls += 1
        if getattr(prepared, "effect", None):
            prepared.effect()
        return prepared


def new_trace(root, quiescent=lambda: True):
    root.mkdir()
    return TargetedDiagnostics(Pool, Checkpoint, Evaluator, root / "trace.json",
        expected_origins={key: __file__ for key in ("pool", "checkpoint", "evaluator")},
        quiescent=quiescent)


def prepared(effect=None):
    return SimpleNamespace(effect=effect, inference=SimpleNamespace(feed=SimpleNamespace(shape=(32,))))


def run_source_controls(case_root):
    results = []
    originals = Pool.__init__, Checkpoint.record_game, Evaluator.execute
    trace = new_trace(case_root / "entry-failure")
    body = False
    try:
        with patch("targeted_diagnostics_v4.os.link", side_effect=OSError("entry publish")):
            with trace:
                body = True
    except RuntimeError as error:
        assert str(error) == "durable entered diagnostic snapshot required"
    else:
        raise AssertionError("entry publication failure admitted body")
    assert not body and originals == (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
    results.append("initial_publication_failure_failclosed")

    trace = new_trace(case_root / "pre-post")
    with patch("targeted_diagnostics_v4.time.monotonic", return_value=100.0):
        with trace:
            entered = trace.last_durable_checkpoint
            def observe_original_entry():
                saved = json.loads(trace.last_durable_checkpoint.read_text())
                assert saved["snapshot_phase"] == "first_execute_pending"
                assert saved["execute_attempts"] == saved["execute_inflight"] == 1
                assert saved["execute_calls_entered"] == 0
            value = prepared(observe_original_entry)
            assert Evaluator().execute(value) is value
            saved = json.loads(trace.last_durable_checkpoint.read_text())
            assert saved["snapshot_phase"] == "first_execute_post"
            assert saved["execute_inflight"] == 0 and saved["execute_returns"] == 1
            assert saved["execute_calls_entered"] == 1 and saved["execute_wall_ns"] >= 0
            assert entered.name.endswith("during-00.json")
            assert trace.last_durable_checkpoint.name.endswith("during-02.json")
    results.append("first_execute_pre_and_post_before_cadence")

    trace = new_trace(case_root / "pre-failure")
    calls = Evaluator.calls
    with trace:
        with patch("targeted_diagnostics_v4.os.link", side_effect=OSError("first pre publish")):
            try:
                Evaluator().execute(prepared())
            except RuntimeError as error:
                assert str(error) == "durable first execute pending snapshot required"
            else:
                raise AssertionError("first pre publication failure admitted original")
        assert Evaluator.calls == calls
        assert trace.snapshot()["execute_pre_refused"] == 1
        assert trace.snapshot()["execute_inflight"] == 0
        try:
            Evaluator().execute(prepared())
        except RuntimeError:
            pass
        else:
            raise AssertionError("failed first publication silently retried original")
        assert Evaluator.calls == calls
    results.append("first_execute_publication_failure_original_not_called")

    trace = new_trace(case_root / "post-failure")
    primary = ValueError("original evaluator failure")
    patcher = patch("targeted_diagnostics_v4.os.link", side_effect=OSError("first post publish"))
    def fail_original():
        patcher.start()  # Pre publication succeeded; fail only post publication.
        raise primary
    with trace:
        try:
            Evaluator().execute(prepared(fail_original))
        except ValueError as caught:
            assert caught is primary
        else:
            raise AssertionError("original target exception lost")
        finally:
            patcher.stop()
        assert trace.snapshot()["execute_raises"] == 1 and trace.snapshot()["execute_inflight"] == 0
        assert any("during snapshot failed" in error for error in trace.errors)
    results.append("first_post_io_failure_preserves_original_exception")

    trace = new_trace(case_root / "cadence")
    clock = [100.0]
    with patch("targeted_diagnostics_v4.time.monotonic", side_effect=lambda: clock[0]):
        with trace:
            Evaluator().execute(prepared())
            assert not trace.checkpoint()
            for _ in range(30):
                clock[0] += 20
                trace.checkpoint()
            assert trace._during_attempts == 17 and trace._cadence_attempts == 14
            assert trace._during_charged_bytes <= trace.DURING_BYTE_BUDGET
    assert sum(path.stat().st_size for path in trace.path.parent.iterdir()) <= 4 << 20
    assert originals == (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
    results.append("cadence_count_byte_bounds_and_restore")

    trace = new_trace(case_root / "byte-exhaustion")
    clock = [100.0]
    with patch("targeted_diagnostics_v4.time.monotonic", side_effect=lambda: clock[0]):
        with trace:
            prior_path, prior = trace.last_durable_checkpoint, trace.last_durable_checkpoint.read_bytes()
            trace.DURING_BYTE_BUDGET = trace._during_charged_bytes + 1
            clock[0] += 20
            receipt = {"sha256": "a" * 64}
            pool = Pool(commit=lambda game: receipt, make_stepper=lambda game, rng: object())
            assert pool.commit(SimpleNamespace(slot_id=0)) is receipt
            assert trace._during_attempts == 17 and not trace.checkpoint()
            assert any("byte budget exhausted" in error for error in trace.errors)
            assert prior_path.read_bytes() == prior
    results.append("early_byte_exhaustion_preserves_prior_snapshot_and_return")

    quiet = [False]
    trace = new_trace(case_root / "retain", quiescent=lambda: quiet[0])
    with trace:
        pass
    assert trace.active and trace.ownership_retained and not trace.finalize_after_quiescence()
    quiet[0] = True
    assert trace.finalize_after_quiescence()
    assert originals == (Pool.__init__, Checkpoint.record_game, Evaluator.execute)
    results.append("nonquiescent_ownership_until_explicit_quiescence")
    return results


def run_termination_controls(case_root, run_owned_termination):
    results = []
    source = Path(__file__).with_name("diagnostic_termination_child_v4.py")
    for signum in (signal.SIGTERM, signal.SIGKILL):
        root = case_root / ("sigterm" if signum == signal.SIGTERM else "sigkill")
        root.mkdir()
        final_path = root / "trace.json"
        result = run_owned_termination(source, final_path, int(signum))
        assert result["returncode"] == -int(signum) and result["kernel_ECHILD"] is True
        ack = result["ack"]
        expected = final_path.with_name(final_path.name + ".during-01.json")
        assert ack["durable_snapshot"] == str(expected)
        raw = expected.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == ack["sha256"]
        saved = json.loads(raw)
        assert saved["snapshot_phase"] == "first_execute_pending"
        assert saved["execute_attempts"] == saved["execute_inflight"] == 1
        assert saved["execute_calls_entered"] == 0
        assert saved["status"] == "PARTIAL_DIAGNOSTIC_ONLY"
        assert saved["snapshot_thread_final"] is False
        assert not final_path.exists()
        assert not final_path.with_name(final_path.name + ".during-02.json").exists()
        assert sum(path.stat().st_size for path in root.iterdir()) <= 4 << 20
        results.append("owned_" + ("SIGTERM" if signum == signal.SIGTERM else "SIGKILL") + "_inside_first_execute_after_pending_ack")
    return results
