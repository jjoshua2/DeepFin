"""UNRUN pure lexical memo; dynamic mutable controls remain authoritative."""
from types import MappingProxyType

CONTROL_KEYS = frozenset(('preserved', 'ordinary_pause', 'evaluation_stops', 'abort_paths'))
MARKER_KEYS = frozenset(('path', 'present', 'sha256'))


def compile_lexical_memo(controls, path_type):
    """Optional pure preparation only; no validation authority or IO is cached.

    Capture exact builtin strings and boolean lexical results only. Never retain
    mutable records/lists, reject a later input, or update from a dynamic check.
    Invalid/unfamiliar preparation falls back to the original lexical expression.
    """
    values = []
    try:
        if type(controls) is dict and all(type(key) is str for key in controls):
            records = controls.get('preserved')
            if type(records) is not list or not 7 <= len(records) <= 1024:
                return MappingProxyType({})
            if type(records) is list:
                for record in records:
                    if type(record) is dict and all(type(key) is str for key in record):
                        value = record.get('path')
                        if type(value) is str:
                            values.append(value)
            aborts = controls.get('abort_paths')
            if type(aborts) is not list or not 4 <= len(aborts) <= 16:
                return MappingProxyType({})
            if type(aborts) is list:
                values.extend(value for value in aborts if type(value) is str)
        memo = {}
        for value in values:
            answer = path_type(value).is_absolute()
            if type(answer) is not bool:
                return MappingProxyType({})
            memo[value] = answer
        return MappingProxyType(memo)
    except Exception:
        return MappingProxyType({})


def lexical_is_absolute(value, memo, path_type):
    if type(value) is str and value in memo:
        return memo[value]
    return path_type(value).is_absolute()


def candidate_controls_unchanged(controls, memo, *, need, Reads, Path, lexists):
    # Exact original statement order; current aliases are re-read at each original
    # operation. Only constant RHS keysets and two PURE lexical expressions differ.
    need(type(controls) is dict and set(controls) == CONTROL_KEYS, 'closed controls')
    records = controls['preserved']
    need(type(records) is list and 7 <= len(records) <= 1024, 'bounded preservation roster')
    paths = [record['path'] for record in records]
    need(len(set(paths)) == len(paths), 'unique preserved controls')
    stops = controls['evaluation_stops']
    need(type(stops) is list and len(stops) == 6 and len(set(stops)) == 6
         and set(stops + [controls['ordinary_pause']]) <= set(paths), 'ordinary PAUSE and six evalSTOP bindings')
    reads = Reads(2 << 20)
    for record in records:
        need(type(record) is dict and set(record) == MARKER_KEYS
             and type(record['present']) is bool and lexical_is_absolute(record['path'], memo, Path), 'closed marker state')
        if record['path'] in stops + [controls['ordinary_pause']]:
            need(record['present'], 'ordinary PAUSE/evalSTOP must remain present')
        if record['present']:
            reads.checked({'path': record['path'], 'sha256': record['sha256']}, metadata=True)
        else:
            need(record['sha256'] is None and not lexists(record['path']), 'absent marker changed')
    aborts = controls['abort_paths']
    need(type(aborts) is list and len(aborts) == len(set(aborts)) and 4 <= len(aborts) <= 16
         and all(lexical_is_absolute(path, memo, Path) for path in aborts)
         and not set(aborts) & set(stops + [controls['ordinary_pause']]), 'private/global abort scope must preserve ordinary PAUSE')
    need(not any(lexists(path) for path in aborts), 'private/global abort marker')


def build_candidate(original_namespace, controls):
    """Build once outside measured checks; callable accepts CURRENT controls.

    Normal pinned imported Path is assumed unchanged. No arbitrary namespace
    monkeypatch equivalence is claimed. Reads and lexists are the actual originals
    or explicitly instrumented controller seams; their operations are unchanged.
    """
    path_type = original_namespace['Path']
    memo = compile_lexical_memo(controls, path_type)

    def check(current):
        return candidate_controls_unchanged(current, memo,
            need=original_namespace['need'], Reads=original_namespace['Reads'],
            Path=path_type, lexists=original_namespace['os'].path.lexists)

    check.lexical_memo = memo
    check.memo_entries = len(memo)
    return check
