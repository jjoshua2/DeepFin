"""UNRUN actual-original versus candidate synthetic control transcripts.

No duplicate original algorithm: controls_unchanged.__code__ comes from the pinned
child namespace supplied by the controller. Fake IO observes call order only;
actual filesystem/Reads semantics require the separately bounded paired scans.
"""
import copy
from types import FunctionType, SimpleNamespace


def fixture():
    paths = ['/controls/stop-%d' % index for index in range(6)]
    pause = '/controls/PAUSE'
    return {'preserved': [dict(path=path, present=True, sha256='a' * 64)
                          for path in paths + [pause]] + [
                              dict(path='/controls/absent-a', present=False, sha256=None),
                              dict(path='/controls/absent-b', present=False, sha256=None)],
            'ordinary_pause': pause, 'evaluation_stops': paths,
            'abort_paths': ['/abort/%d' % index for index in range(4)]}


def run_source_controls(original_namespace, candidate_namespace):
    receipts = []

    def one(name, setup=None, during=None, between=None, twice=False, fail_read=None, present=()):
        def run(candidate):
            controls = fixture()
            if setup is not None:
                setup(controls)
            events, results = [], []
            state = {'used': False, 'read_count': 0, 'present': set(present)}
            class FakeReads:
                def __init__(self, cap):
                    events.append(('Reads', cap))
                def checked(self, ref, *, metadata=False):
                    state['read_count'] += 1
                    events.append(('checked', dict(ref), metadata))
                    if during is not None:
                        during('checked', ref['path'], controls, state)
                    if fail_read == state['read_count']:
                        raise PermissionError('synthetic original read failure')
                    return b''
            def lexists(path):
                if during is not None:
                    during('lexists', path, controls, state)
                result = path in state['present']
                events.append(('lexists', path, result))
                return result
            namespace = dict(original_namespace)
            namespace.update(Reads=FakeReads, os=SimpleNamespace(path=SimpleNamespace(lexists=lexists)))
            original = original_namespace['controls_unchanged']
            check = (candidate_namespace['build_candidate'](namespace, controls) if candidate else
                     FunctionType(original.__code__, namespace, original.__name__, original.__defaults__, original.__closure__))
            for round_number in range(2 if twice else 1):
                events.append(('round', round_number))
                try:
                    result = check(controls)
                    results.append(('return', result))
                except BaseException as error:
                    results.append(('raise', type(error).__module__ + '.' + type(error).__qualname__, str(error)))
                if round_number == 0 and between is not None:
                    between(controls)
            return {'events': events, 'results': results}
        baseline, candidate = run(False), run(True)
        if candidate != baseline:
            raise AssertionError({'id': name, 'original': baseline, 'candidate': candidate})
        receipts.append({'id': name, 'original': baseline, 'candidate': candidate, 'equal': True})

    one('unchanged_valid')
    one('present_read_failure_same_prefix', fail_read=3)
    one('absent_marker_created', present=('/controls/absent-a',))
    for index in (0, 2, 3):
        one('abort_shortcircuit_%d' % index, present=('/abort/%d' % index,))
    one('invalid_absent_sha_skips_lexists', setup=lambda c: c['preserved'][7].update(sha256='bad'))
    one('invalid_record_schema_after_first_read', setup=lambda c: c['preserved'][1].pop('sha256'))
    one('invalid_abort_scope_after_preservation_reads', setup=lambda c: c['abort_paths'].append(c['abort_paths'][0]))
    one('abort_overlaps_pause_after_preservation_reads', setup=lambda c: c['abort_paths'].__setitem__(2, c['ordinary_pause']))

    def retarget(c):
        c['preserved'][0]['path'] = '/new/stop-zero'
        c['evaluation_stops'][0] = '/new/stop-zero'
    one('between_calls_nested_record_and_stop_retarget', between=retarget, twice=True)
    def relative(c):
        c['preserved'][0]['path'] = 'relative-stop'
        c['evaluation_stops'][0] = 'relative-stop'
    one('between_calls_relative_path_refusal', between=relative, twice=True)
    one('between_calls_nested_record_schema_refusal', between=lambda c: c['preserved'][1].pop('sha256'), twice=True)

    def during_checked(operation):
        def mutate(kind, _path, c, state):
            if kind == 'checked' and not state['used']:
                state['used'] = True
                operation(c)
        return mutate
    def future_retarget(c):
        c['preserved'][1]['path'] = '/new/future-stop'
        c['evaluation_stops'][1] = '/new/future-stop'
    one('during_checked_future_record_and_stop_retarget', during=during_checked(future_retarget))
    one('during_checked_mutable_stop_membership_refusal', during=during_checked(
        lambda c: c['evaluation_stops'].__setitem__(0, '/controls/absent-a')))
    one('during_checked_preserved_append_observed', during=during_checked(
        lambda c: c['preserved'].append(dict(path='/new/absent', present=False, sha256=None))))
    one('during_checked_abort_append_observed', during=during_checked(lambda c: c['abort_paths'].append('/abort/new')))
    def abort_retarget(kind, path, c, state):
        if kind == 'lexists' and path == '/abort/0' and not state['used']:
            state['used'] = True
            c['abort_paths'][1] = '/abort/retargeted'
            state['present'].add('/abort/retargeted')
    one('during_abort_lexists_next_path_retarget', during=abort_retarget)
    def abort_replace(kind, path, c, state):
        if kind == 'lexists' and path == '/abort/0' and not state['used']:
            state['used'] = True
            c['abort_paths'] = ['/replacement/%d' % index for index in range(4)]
            state['present'].add('/replacement/0')
    one('during_abort_lexists_container_replacement_keeps_original_alias', during=abort_replace)

    memo = candidate_namespace['compile_lexical_memo'](fixture(), original_namespace['Path'])
    try:
        memo['/injected'] = True
    except TypeError:
        pass
    else:
        raise AssertionError('lexical memo must be immutable')
    class HashPoisonText(str):
        def __hash__(self):
            raise AssertionError('subclass must not enter memo lookup')
    fallback = []
    def path_seam(value):
        fallback.append(value)
        return SimpleNamespace(is_absolute=lambda: True)
    if not candidate_namespace['lexical_is_absolute'](HashPoisonText('/known'), {'/known': False}, path_seam):
        raise AssertionError('exact-type fallback result')
    if len(fallback) != 1 or type(fallback[0]) is not HashPoisonText:
        raise AssertionError('original fallback value not preserved')
    receipts.append({'id': 'immutable_lexical_only_and_exact_builtin_type_lookup', 'equal': True,
                     'meaning': 'pure helper contract only, not full caller equivalence for monkeypatched Path'})
    return {'status': 'SYNTHETIC_TRANSCRIPTS_MATCH', 'controls': receipts,
            'count': len(receipts), 'actual_filesystem_or_original_Reads_executed': False,
            'compile_timing_excluded_from_transcript': True,
            'pure_lexical_Path_calls_intentionally_excluded_from_dynamic_IO_transcript': True}
