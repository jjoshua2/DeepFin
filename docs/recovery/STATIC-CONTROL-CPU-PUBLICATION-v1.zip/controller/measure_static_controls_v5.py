"""UNRUN V5 readonly static-control CPU screen; root sole operator after exact independent review."""
import hashlib
import json
import os
from pathlib import Path
import resource
import stat
import signal
import sys
import time
import traceback

BASE = Path('/mnt/c/Users/jjosh/Documents/Codex/2026-10-13/task-5')
ORIGINAL = BASE / 'bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-phase-diagnostic60-draft-v1/finite_phase_diagnostic_child_60s_v2.py'
ORIGINAL_SHA = '689b878c62647155247f7c5d04b467df3abaf53f3baf9c8c878589c7edef22f3'
PACKET = BASE / 'bt4-qualification-intake-root-20261021-v1/prepared-finite-phase-diagnostic60-20261021-v1/CHILD-PACKET.json'
PACKET_SHA = 'b1e10c9d10b30451cd924c443e8620a3c52ba9e0e8b5bde9136e8b9db0bb5432'
CANDIDATE = BASE / 'bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-static-control-plan-v1/static_control_lexical_candidate_v1.py'
CANDIDATE_SHA = '267d6326d27eb18426b2cd254536ce903854303dbb5d25b16369be23d1ce25e4'
TESTS = BASE / 'bt4-pr1110-recovery-20261021-v1/worktree-selfplay/docs/intake/pr1110-static-control-plan-v1/static_control_lexical_source_controls_v1.py'
TESTS_SHA = '1816a802ab1b560f4e6a270566ac839f0ba8f3c77a92f22f8d46dd0106cb8c1f'
PREREG = BASE / 'bt4-qualification-intake-root-20261021-v1/STATIC-CONTROL-CPU-MEASUREMENT-PREREG-v1.json'
PREREG_SHA = '0a134cc9ecb956032d30099b3d668711b901f56d5d8f6664c884e97d6cebfb63'
WITNESS = BASE / 'bt4-qualification-intake-root-20261021-v1/STATIC-CONTROL-CPU-ONE-USE-INTENT-v1.json'
BOOT = 'e34eff27-d1dc-49c0-bac2-e8525ea1b52f'
ABSENT = (224690,238033,238034,239144,239145,239631,239632,239811,239812,240331,240332,240486,240487)
READ_CAP = 16 << 20
OUT_CAP = 256 << 10
clock = time.monotonic
started = clock()
read_bytes = 0
raw_os_read = os.read
raw_lexists = os.path.lexists
trace = None
STATE = {}


def need(ok, message):
    if not ok:
        raise RuntimeError(message)


def checkpoint():
    need(clock() - started < 9, 'bounded CPU active deadline')


def counted_read(fd, count):
    global read_bytes
    checkpoint()
    need(type(count) is int and 0 <= count <= 1 << 20, 'bounded read request')
    # Reserve at most the remaining budget; refusal occurs before an excess read.
    need(count <= READ_CAP - read_bytes, 'global actual read budget')
    raw = raw_os_read(fd, count)
    read_bytes += len(raw)
    return raw


def stable(path, limit, sha=None, regular=True):
    checkpoint()
    path = Path(path)
    need(path.resolve() == path, 'canonical named input')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        need(not regular or stat.S_ISREG(before.st_mode), 'regular named input')
        need(not regular or before.st_size <= limit, 'named input size')
        parts = []
        size = 0
        while True:
            raw = counted_read(fd, min(65536, limit - size + 1))
            if not raw:
                break
            size += len(raw)
            need(size <= limit, 'bounded named input')
            parts.append(raw)
        if regular:
            stamp = lambda s: (s.st_dev,s.st_ino,s.st_mode,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
            need(size == before.st_size and stamp(before) == stamp(os.fstat(fd)) == stamp(path.lstat()), 'stable named bytes')
        raw = b''.join(parts)
        need(sha is None or hashlib.sha256(raw).hexdigest() == sha, 'source/data pin mismatch')
        return raw
    finally:
        os.close(fd)


def facts():
    boot = stable('/proc/sys/kernel/random/boot_id', 128, regular=False).decode().strip()
    need(boot == BOOT, 'fresh actual boot')
    mem = stable('/proc/meminfo',65536,regular=False).decode()
    available = int(next(x.split()[1] for x in mem.splitlines() if x.startswith('MemAvailable:'))) * 1024
    need(available >= 8 << 30, 'actual MemAvailable8GiB')
    for pid in ABSENT:
        need(not raw_lexists('/proc/' + str(pid)), 'closed PID must be absent even if reused')
    rows = stable('/proc/locks',1 << 20,regular=False).decode().splitlines()
    identities = {(os.major(2096),os.minor(2096),i) for i in (81348917,18835410,18503149)}
    identities.add((os.major(73),os.minor(73),1407374886384886))
    matched = []
    for row in rows:
        for token in row.split():
            parts = token.split(':')
            if len(parts) != 3:
                continue
            try:
                identity = (int(parts[0],16),int(parts[1],16),int(parts[2]))
            except ValueError:
                continue
            if identity in identities:
                matched.append(row)
    need(not matched, 'canonical4/original guard rows zero')
    return {'boot':boot,'MemAvailable':available,'absent_pids':list(ABSENT),'matching_lock_rows':matched}


def audit(event, args):
    if event == 'open':
        flags = args[2]
        need(not isinstance(flags,int) or flags & (os.O_WRONLY|os.O_RDWR|os.O_CREAT|os.O_TRUNC|os.O_APPEND) == 0, 'read-only open')
    need(event not in {'subprocess.Popen','os.system','os.fork','os.posix_spawn','os.exec','os.kill','os.killpg','os.remove','os.rename','os.mkdir','os.rmdir','os.link','os.symlink','os.truncate','fcntl.flock','fcntl.lockf','socket.__new__'}, 'no child/signals/guest writes')


def source_namespace(path, sha):
    raw = stable(path, 1 << 20, sha)
    namespace = {'__name__':'__qualification_source__','__file__':str(path)}
    exec(compile(raw,str(path),'exec'),namespace)
    return namespace


def main():
    need(sys.version_info[:2] == (3,10) and sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode and sys.flags.optimize == 0, 'CP310-I-S-B assertions enabled')
    need(len(sys.argv) == 3, 'exact self and fixed intent SHA arguments')
    def timed_out(signum, frame):
        raise TimeoutError('external10s active deadline; incomplete screen')
    signal.signal(signal.SIGTERM,timed_out)
    need(all(x is not None for x in (CANDIDATE,CANDIDATE_SHA,TESTS,TESTS_SHA)), 'UNBOUND author API/witness: not admitted')
    for key, value in ((resource.RLIMIT_CPU,10),(resource.RLIMIT_AS,512 << 20)):
        soft, hard = resource.getrlimit(key)
        cap = value if hard == resource.RLIM_INFINITY else min(value,hard)
        resource.setrlimit(key,(cap if soft == resource.RLIM_INFINITY else min(soft,cap),cap))
    sys.addaudithook(audit)
    stable(Path(__file__),1 << 20,sys.argv[1])
    before = facts()
    os.read = counted_read
    decision_raw = stable(WITNESS,65536,sys.argv[2])
    decision = json.loads(decision_raw)
    fields = {'schema','scope','program_sha256','packet_sha256','boot','issued_unix','expires_unix','native_single_use'}
    need(type(decision) is dict and set(decision) == fields, 'closed fresh CPU decision')
    need(decision['schema'] == 'PR1110_STATIC_CONTROL_CPU_ONE_USE_INTENT_V1' and decision['scope'] == 'ONE_EXACT_READONLY_STATIC_CONTROL_CPU_GATE', 'exact CPU-only decision')
    need(decision['program_sha256'] == sys.argv[1] and decision['packet_sha256'] == PACKET_SHA and decision['boot'] == BOOT and decision['native_single_use'] is True, 'decision source/data/boot/single-use binding')
    now = time.time()
    need(type(decision['issued_unix']) in (int,float) and type(decision['expires_unix']) in (int,float) and 0 < decision['expires_unix'] - decision['issued_unix'] <= 600 and decision['issued_unix'] <= now and decision['expires_unix'] - now >= 11, 'fresh600s decision remaining11s')

    stable(PREREG,65536,PREREG_SHA)
    STATE.update(facts_before=before,phase='source_and_pure_controls')
    original = source_namespace(ORIGINAL,ORIGINAL_SHA)
    candidate = source_namespace(CANDIDATE,CANDIDATE_SHA)
    tests = source_namespace(TESTS,TESTS_SHA)
    packet = json.loads(stable(PACKET,1 << 20,PACKET_SHA))
    controls = packet['controls']
    need(len(controls['preserved']) == 564, 'exact actual saved564 roster')
    pure = tests['run_source_controls'](original,candidate)
    expected_ids = ['unchanged_valid','present_read_failure_same_prefix','absent_marker_created','abort_shortcircuit_0','abort_shortcircuit_2','abort_shortcircuit_3','invalid_absent_sha_skips_lexists','invalid_record_schema_after_first_read','invalid_abort_scope_after_preservation_reads','abort_overlaps_pause_after_preservation_reads','between_calls_nested_record_and_stop_retarget','between_calls_relative_path_refusal','between_calls_nested_record_schema_refusal','during_checked_future_record_and_stop_retarget','during_checked_mutable_stop_membership_refusal','during_checked_preserved_append_observed','during_checked_abort_append_observed','during_abort_lexists_next_path_retarget','during_abort_lexists_container_replacement_keeps_original_alias','immutable_lexical_only_and_exact_builtin_type_lookup']
    need(type(pure) is dict and pure.get('status') == 'SYNTHETIC_TRANSCRIPTS_MATCH' and pure.get('count') == 20 and pure.get('actual_filesystem_or_original_Reads_executed') is False, 'exact pure semantic receipt')
    need(type(pure.get('controls')) is list and [r.get('id') for r in pure['controls']] == expected_ids and all(r.get('equal') is True for r in pure['controls']), 'all20 named synthetic negative/transcript controls PASS')
    STATE.update(pure_controls=pure,phase='actual_readonly_pairs')
    checkpoint()
    raw_reads = original['Reads']
    counters = {}
    def observe(kind,path,wall,cpu):
        group = 'mnt_c' if type(path) is str and path.startswith('/mnt/c/') else 'other'
        bucket = counters.setdefault(kind + '/' + group,{'count':0,'wall_ns':0,'thread_cpu_ns':0})
        bucket['count'] += 1
        bucket['wall_ns'] += wall
        bucket['thread_cpu_ns'] += cpu
    class TracedReads(raw_reads):
        def __init__(self,cap):
            need(cap == 2 << 20, 'fresh exact2MiB dynamic call budget')
            if trace is not None:
                trace.append(['Reads',cap])
            super().__init__(cap)
        def checked(self,ref,*,metadata=False):
            if trace is not None:
                trace.append(['checked',dict(ref),metadata])
            w,c = time.perf_counter_ns(),time.thread_time_ns()
            try:
                return super().checked(ref,metadata=metadata)
            finally:
                observe('checked_includes_resolve_open_read_hash_stamps',ref.get('path'),time.perf_counter_ns()-w,time.thread_time_ns()-c)
    def traced_lexists(path):
        if trace is not None:
            trace.append(['lexists',path])
        w,c = time.perf_counter_ns(),time.thread_time_ns()
        try:
            return raw_lexists(path)
        finally:
            observe('lexists_single_call',path,time.perf_counter_ns()-w,time.thread_time_ns()-c)
    original['Reads'] = TracedReads
    os.path.lexists = traced_lexists
    w,c = time.perf_counter_ns(),time.thread_time_ns()
    candidate_call = candidate['build_candidate'](original,controls)
    compile_cost = {'wall_ns':time.perf_counter_ns()-w,'thread_cpu_ns':time.thread_time_ns()-c,'outside_paired_measurements':True}
    rows = []
    STATE.update(compile_cost=compile_cost,pairs=rows)
    global trace
    for pair,order in enumerate(('AB','BA','AB'),1):
        receipts = {}
        transcripts = {}
        for arm in order:
            STATE.update(current_pair=pair,current_arm=arm)
            checkpoint()
            trace = []
            counters.clear()
            STATE['current_arm_per_path_class'] = counters
            rb = read_bytes
            w,c = time.perf_counter_ns(),time.thread_time_ns()
            result = original['controls_unchanged'](controls) if arm == 'A' else candidate_call(controls)
            elapsed = {'wall_ns':time.perf_counter_ns()-w,'thread_cpu_ns':time.thread_time_ns()-c}
            need(result is None, 'original/candidate exact success result')
            raw = json.dumps(trace,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
            receipts[arm] = dict(elapsed,read_bytes=read_bytes-rb,event_count=len(trace),transcript_sha256=hashlib.sha256(raw).hexdigest(),per_path_class={k:dict(v) for k,v in counters.items()})
            transcripts[arm] = trace
            trace = None
        need(transcripts['A'] == transcripts['B'], 'ordered original/candidate dynamic transcript mismatch')
        need(receipts['A']['read_bytes'] == receipts['B']['read_bytes'], 'paired dynamic read byte mismatch')
        rows.append({'pair':pair,'order':order,'A_original':receipts['A'],'B_candidate':receipts['B'],'paired_wall_reduction_fraction':1-receipts['B']['wall_ns']/receipts['A']['wall_ns']})
    os.path.lexists = raw_lexists
    original['Reads'] = raw_reads
    STATE['phase'] = 'final_facts_and_readbacks'
    after = facts()
    stable(WITNESS,65536,sys.argv[2])
    stable(PACKET,1 << 20,PACKET_SHA)
    stable(PREREG,65536,PREREG_SHA)
    for path,sha in ((ORIGINAL,ORIGINAL_SHA),(CANDIDATE,CANDIDATE_SHA),(TESTS,TESTS_SHA)):
        stable(path,1 << 20,sha)
    reductions = sorted(row['paired_wall_reduction_fraction'] for row in rows)
    gate = all(row['B_candidate']['wall_ns'] < row['A_original']['wall_ns'] for row in rows) and reductions[1] >= .10
    out = {'status':'COMPLETE_READONLY_CPU_SCREEN','pure_controls':pure,'compile_cost':compile_cost,'pairs':rows,'screening_gate':{'all_semantics_required':True,'candidate_wall_lower_all_three':all(row['B_candidate']['wall_ns'] < row['A_original']['wall_ns'] for row in rows),'median_paired_wall_reduction_fraction':reductions[1],'minimum_median_reduction':.10,'passes_numeric_screen':gate,'no_gpu_if_false':True,'three_pairs_not_confidence_claim':True,'grants_gpu_authority':False},'facts_before':before,'facts_after':after,'actual_read_bytes':read_bytes,'elapsed_seconds':clock()-started,'children_launched':0,'guest_writes':0,'source_origins':{str(p):h for p,h in ((ORIGINAL,ORIGINAL_SHA),(CANDIDATE,CANDIDATE_SHA),(TESTS,TESTS_SHA))}}
    raw = json.dumps(out,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    need(len(raw)+1 <= OUT_CAP,'bounded CPU stdout')
    sys.stdout.buffer.write(raw+b'\n')
    sys.stdout.buffer.flush()


if __name__ == '__main__':
    try:
        main()
    except BaseException as error:
        os.path.lexists = raw_lexists
        os.read = raw_os_read
        if trace is not None:
            traw = json.dumps(trace,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
            STATE.update(partial_current_arm_event_count=len(trace),partial_current_arm_transcript_sha256=hashlib.sha256(traw).hexdigest())
        STATE.update(status='FAILED_OR_INCOMPLETE_NO_GPU',primary_error_type=type(error).__module__+'.'+type(error).__qualname__,primary_error_message=str(error)[:2048],actual_read_bytes=read_bytes,elapsed_seconds=clock()-started,children_launched=0,guest_writes=0,grants_gpu_authority=False)
        raw = json.dumps(STATE,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        if len(raw)+1 > OUT_CAP:
            raw = json.dumps({'status':'FAILED_OR_INCOMPLETE_NO_GPU','primary_error_type':STATE['primary_error_type'],'primary_error_message':STATE['primary_error_message'],'detailed_failure_receipt_omitted_due_output_bound':True},sort_keys=True).encode()
        sys.stdout.buffer.write(raw+b'\n')
        sys.stdout.buffer.flush()
        traceback.print_exc()
        raise SystemExit(1)
