"""Synthetic fixed-N boundary fixtures against the pinned real arena estimator."""
from __future__ import annotations

import argparse
import math
import unittest
from pathlib import Path
from unittest.mock import patch

from ci_gate import classify_games, endpoint_decision, load_pinned_arena


def games_for_counts(counts: tuple[int, int, int, int, int]) -> list[float]:
    pair = ((1.0, 1.0), (1.0, 0.5), (0.5, 0.5), (0.5, 0.0), (0.0, 0.0))
    return [score for n, scores in zip(counts, pair) for _ in range(n) for score in scores]


class GateTests(unittest.TestCase):
    repo_root: Path

    def test_source_pin_and_pair_draw_mapping(self) -> None:
        arena = load_pinned_arena(self.repo_root)
        self.assertEqual(arena.game_scores_to_pair_scores([1.0, 0.0, 0.5, 0.5]),
                         [1.0, 1.0])
        self.assertEqual(arena.pentanomial_counts([2.0, 1.5, 1.0, 0.5, 0.0]),
                         (1, 1, 1, 1, 1))
        with patch("ci_gate.hashlib.sha256") as fake_hash:
            fake_hash.return_value.hexdigest.return_value = "0" * 64
            with self.assertRaisesRegex(RuntimeError, "source bytes differ"):
                load_pinned_arena(self.repo_root)

    def test_screen_upper_just_below_threshold_stops(self) -> None:
        out = classify_games(self.repo_root, "screen", games_for_counts((3, 24, 51, 24, 26)))
        self.assertEqual(out["status"], "STOP_GROSS_HARM")
        self.assertAlmostEqual(out["elo_ci95_unrounded"][1], -30.074981106355086, places=9)

    def test_screen_upper_just_above_threshold_does_not_promote(self) -> None:
        out = classify_games(self.repo_root, "screen", games_for_counts((5, 27, 41, 25, 30)))
        self.assertEqual(out["status"], "NONREJECTING_NO_PROMOTION")
        self.assertAlmostEqual(out["elo_ci95_unrounded"][1], -29.99205851585267, places=9)

    def test_confirmation_lower_just_above_threshold_advances_only_tested_size(self) -> None:
        out = classify_games(self.repo_root, "confirmation",
                             games_for_counts((63, 116, 197, 115, 85)))
        self.assertEqual(out["status"], "ADVANCE_TESTED_SIZE_ONLY")
        self.assertAlmostEqual(out["elo_ci95_unrounded"][0], -29.98245254550006, places=9)

    def test_confirmation_lower_just_below_threshold_holds(self) -> None:
        out = classify_games(self.repo_root, "confirmation",
                             games_for_counts((68, 89, 233, 103, 83)))
        self.assertEqual(out["status"], "HOLD_NONINFERIORITY")
        self.assertAlmostEqual(out["elo_ci95_unrounded"][0], -30.001306003673744, places=9)
        self.assertEqual(round(out["elo_ci95_unrounded"][0], 2), -30.0)

    def test_exact_threshold_is_strict_both_ways(self) -> None:
        self.assertEqual(endpoint_decision("screen", -50.0, -30.0, score_se=.01),
                         "NONREJECTING_NO_PROMOTION")
        self.assertEqual(endpoint_decision("confirmation", -30.0, 10.0, score_se=.01),
                         "HOLD_NONINFERIORITY")

    def test_undefined_endpoint_and_zero_width_hold(self) -> None:
        for stage in ("screen", "confirmation"):
            self.assertEqual(endpoint_decision(stage, None, 10.0, score_se=.01),
                             "HOLD_UNDEFINED_OR_DEGENERATE_CI")
            self.assertEqual(endpoint_decision(stage, -10.0, math.inf, score_se=.01),
                             "HOLD_UNDEFINED_OR_DEGENERATE_CI")
            self.assertEqual(endpoint_decision(stage, -30.0, -30.0, score_se=0),
                             "HOLD_UNDEFINED_OR_DEGENERATE_CI")
            n = 128 if stage == "screen" else 576
            all_draw = classify_games(self.repo_root, stage,
                                      games_for_counts((0, 0, n, 0, 0)))
            self.assertEqual(all_draw["status"], "HOLD_UNDEFINED_OR_DEGENERATE_CI")

    def test_fixed_panel_length_and_invalid_score_refuse(self) -> None:
        games = games_for_counts((0, 0, 128, 0, 0))
        with self.assertRaisesRegex(RuntimeError, "fixed paired panel"):
            classify_games(self.repo_root, "screen", games[:-1])
        games[0] = .3
        with self.assertRaisesRegex(ValueError, "per-game score"):
            classify_games(self.repo_root, "screen", games)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, required=True)
    args = parser.parse_args()
    GateTests.repo_root = args.repo_root.resolve()
    unittest.main(argv=[__file__], verbosity=2)
