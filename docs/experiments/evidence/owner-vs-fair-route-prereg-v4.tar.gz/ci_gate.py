"""CPU-only exact paired-Elo decision gate for the v3 preregistration.

This imports the existing pinned arena estimator; it does not play games, open
models/tablebases, or create a CUDA context. Raw PGN/game-log identity and
terminal validation remain separate launch/readback obligations.
"""
from __future__ import annotations

import hashlib
import importlib
import math
import sys
from pathlib import Path
from typing import Any

ARENA_SHA256 = "7089b09146096e218fdf900940dcee6b2f4100da3d2b4aaa1764cb16b0188513"
THRESHOLD_ELO = -30.0
PAIRS = {"screen": 128, "confirmation": 576}


def load_pinned_arena(repo_root: Path) -> Any:
    source = repo_root / "scripts" / "arena_standard.py"
    if not source.is_file() or hashlib.sha256(source.read_bytes()).hexdigest() != ARENA_SHA256:
        raise RuntimeError("pinned arena source bytes differ")
    sys.path.insert(0, str(repo_root))
    try:
        arena = importlib.import_module("scripts.arena_standard")
        if Path(arena.__file__).resolve() != source.resolve():
            raise RuntimeError("arena import path differs")
        return arena
    finally:
        sys.path.pop(0)


def endpoint_decision(stage: str, lo: float | None, hi: float | None,
                      *, score_se: float) -> str:
    if stage not in PAIRS:
        raise ValueError("unknown preregistered stage")
    if (lo is None or hi is None or not math.isfinite(lo) or not math.isfinite(hi)
            or lo >= hi or not math.isfinite(score_se) or score_se <= 0):
        return "HOLD_UNDEFINED_OR_DEGENERATE_CI"
    if stage == "screen":
        return "STOP_GROSS_HARM" if hi < THRESHOLD_ELO else "NONREJECTING_NO_PROMOTION"
    return ("ADVANCE_TESTED_SIZE_ONLY" if lo > THRESHOLD_ELO
            else "HOLD_NONINFERIORITY")


def classify_games(repo_root: Path, stage: str, game_scores: list[float]) -> dict[str, Any]:
    if stage not in PAIRS:
        raise ValueError("unknown preregistered stage")
    if len(game_scores) != 2 * PAIRS[stage]:
        raise RuntimeError("incomplete or enlarged fixed paired panel")
    arena = load_pinned_arena(repo_root)
    pair_scores = arena.game_scores_to_pair_scores(game_scores)
    counts = arena.pentanomial_counts(pair_scores)
    summary = arena.summarize_pentanomial(counts, z=1.96)
    if summary.pairs != PAIRS[stage] or summary.games != 2 * PAIRS[stage]:
        raise RuntimeError("pair count differs")
    lo, hi = summary.elo_ci95
    return {"stage": stage, "pair_count": summary.pairs, "counts": counts,
            "score": summary.score, "score_se": summary.score_se,
            "elo_ci95_unrounded": (lo, hi),
            "status": endpoint_decision(stage, lo, hi, score_se=summary.score_se)}
