"""Source-only exact-member verifier for the owner-route preregistration packet."""
from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path

EXPECTED = frozenset({
    "PACKET_MANIFEST.json", "ARITHMETIC.json", "PREREG.md", "REVIEW.md",
    "VALIDATION.json", "ci_gate.py", "test_ci_gate.py", "verify_packet.py",
    "test_verify_packet.py",
})
PARENT_V3 = "20610f078564559a60606e1d13ec856b142c8bef6da5987d822610d367a9bf25"
ARENA_SHA = "7089b09146096e218fdf900940dcee6b2f4100da3d2b4aaa1764cb16b0188513"
ARITHMETIC_SHA = "30815b773ba0d7d587e2af6ce78c9e033bb3f60433829921e9f160c03918a459"


def bounded_regular(path: Path, cap: int) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_mode & 0o111 or not 0 < st.st_size <= cap:
            raise RuntimeError(f"packet member has wrong regular/non-executable/size shape: {path.name}")
        raw = os.read(fd, cap + 1)
        after = os.fstat(fd)
        if len(raw) != st.st_size or (st.st_dev, st.st_ino, st.st_mtime_ns) != (
                after.st_dev, after.st_ino, after.st_mtime_ns):
            raise RuntimeError(f"packet member changed during bounded read: {path.name}")
        return raw
    finally:
        os.close(fd)


def verify_packet(root: Path) -> str:
    if root.is_symlink() or not root.is_dir():
        raise RuntimeError("packet root must be a direct directory")
    actual = {entry.name for entry in os.scandir(root)}
    if actual != EXPECTED:
        raise RuntimeError(f"unexpected or missing packet members: {sorted(actual ^ EXPECTED)}")
    manifest_raw = bounded_regular(root / "PACKET_MANIFEST.json", 65_536)
    manifest = json.loads(manifest_raw)
    if not isinstance(manifest, dict) or manifest.get("schema") != "owner_vs_fair_teacher_route_prereg_v4_source_packet" or manifest.get("status") != "SOURCE_ONLY_HOLD_LAUNCH_PENDING_INDEPENDENT_REVIEW" or manifest.get("parent_v3_manifest_sha256") != PARENT_V3 or manifest.get("arena_source_sha256") != ARENA_SHA or manifest.get("parent_v2_arithmetic_sha256") != ARITHMETIC_SHA:
        raise RuntimeError("packet schema/status/parent/source pin differs")
    members = manifest.get("members_sha256")
    if not isinstance(members, dict) or set(members) != EXPECTED - {"PACKET_MANIFEST.json"}:
        raise RuntimeError("packet manifest member allowlist differs")
    for name in sorted(members):
        raw = bounded_regular(root / name, 1 << 20)
        if hashlib.sha256(raw).hexdigest() != members[name]:
            raise RuntimeError(f"packet member digest differs: {name}")
    return hashlib.sha256(manifest_raw).hexdigest()


if __name__ == "__main__":
    print(verify_packet(Path(__file__).resolve().parent))
