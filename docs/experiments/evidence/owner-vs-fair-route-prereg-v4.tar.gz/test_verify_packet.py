"""Tiny synthetic refusal checks; never imports a model or queries GPU."""
from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path

from verify_packet import EXPECTED, verify_packet


class PacketTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory(prefix="owner-fair-v4-verify-")
        self.root = Path(self.temp.name) / "packet"
        self.root.mkdir()
        source = Path(__file__).resolve().parent
        for name in EXPECTED:
            shutil.copyfile(source / name, self.root / name)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_exact_members_pass(self) -> None:
        self.assertEqual(len(verify_packet(self.root)), 64)

    def test_unlisted_bytecode_directory_refuses(self) -> None:
        (self.root / "__pycache__").mkdir()
        with self.assertRaisesRegex(RuntimeError, "unexpected or missing"):
            verify_packet(self.root)

    def test_unlisted_executable_refuses(self) -> None:
        extra = self.root / "rogue.py"
        extra.write_text("pass\n")
        extra.chmod(0o755)
        with self.assertRaisesRegex(RuntimeError, "unexpected or missing"):
            verify_packet(self.root)

    def test_listed_executable_or_symlink_refuses(self) -> None:
        target = self.root / "ci_gate.py"
        target.chmod(0o755)
        with self.assertRaisesRegex(RuntimeError, "non-executable"):
            verify_packet(self.root)
        target.unlink()
        target.symlink_to(self.root / "test_ci_gate.py")
        with self.assertRaises(OSError):
            verify_packet(self.root)


if __name__ == "__main__":
    unittest.main()
